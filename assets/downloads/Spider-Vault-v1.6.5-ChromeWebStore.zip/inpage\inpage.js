// inpage/inpage.js — LUXA Autonomous Web3 Spider Engine
// v1.6.5: Universal Keplr Compatibility & EIP-6963 Multi-Injected Provider Discovery
(function () {
  if (window.luxa && window.luxa.__SPIDER_ACTIVE__) return;

  const callbacks = new Map();
  const eventListeners = new Map();

  function emit(eventName, data) {
    const handlers = eventListeners.get(eventName);
    if (handlers) {
      handlers.forEach((fn) => {
        try { fn(data); } catch (err) {
          console.error(`[Spider-Provider] Error in listener '${eventName}':`, err);
        }
      });
    }
  }

  // Bidirectional listening from content script (RPC bridge)
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.data?.target !== "luxa-inpage") return;

    const { id, result, error, action, address } = event.data;

    // 1. RPC promise resolution
    if (id && callbacks.has(id)) {
      const { resolve, reject } = callbacks.get(id);
      callbacks.delete(id);
      if (error) reject(new Error(error));
      else resolve(result);
      return;
    }

    // 2. Async reactive ledger notifications
    if (action === "LUXA_ACCOUNT_READY" || action === "ACCOUNTS_CHANGED") {
      emit("accountsChanged", [address]);
      window.dispatchEvent(new CustomEvent("luxa#accountsChanged", { detail: { address } }));
      window.dispatchEvent(new CustomEvent("keplr_keystorechange"));
    }

    if (action === "VAULT_LOCKED" || action === "VAULT_DISCONNECTED") {
      emit("disconnect", { reason: action });
      window.dispatchEvent(new CustomEvent("luxa#disconnect"));
      window.dispatchEvent(new CustomEvent("keplr_keystorechange"));
    }
  });

  function postMsg(action, payload = {}) {
    return new Promise((resolve, reject) => {
      const id = "sp_" + Math.random().toString(36).slice(2) + Date.now().toString(36);
      const isSigningOp = [
        "SIGN_AND_BROADCAST",
        "EXECUTE_WASM_CONTRACT",
        "INSTANTIATE_WASM_CONTRACT",
        "UPLOAD_WASM_CONTRACT",
        "SEND_TRANSACTION",
        "CONNECT_SITE"
      ].includes(action);
      const timeoutMs = isSigningOp ? 180000 : 60000;

      const timer = setTimeout(() => {
        if (callbacks.has(id)) {
          callbacks.delete(id);
          reject(new Error("LUXA Spider request timed out."));
        }
      }, timeoutMs);

      callbacks.set(id, {
        resolve: (val) => { clearTimeout(timer); resolve(val); },
        reject: (err) => { clearTimeout(timer); reject(err); }
      });

      window.postMessage({ target: "luxa-contentscript", action, payload, id }, "*");
    });
  }

  const spiderProvider = {
    __SPIDER_ACTIVE__: true,
    isLuxa: true,
    isSpiderVault: true,
    name: "LUXA Vault — Spider's Nest",
    version: "1.6.5",
    chainId: "luxa-1",
    mode: "extension",
    defaultOptions: {
      sign: {
        preferNoSetFee: false,
        preferNoSetMemo: false,
        disableBalanceCheck: false
      }
    },

    connect: async function () {
      return postMsg("CONNECT_SITE", { origin: window.location.origin });
    },

    enable: async function (chainIds) {
      return this.connect();
    },

    disable: async function (chainIds) {
      return postMsg("DISCONNECT_SITE", { origin: window.location.origin });
    },

    experimentalSuggestChain: async function (chainInfo) {
      return true;
    },

    getKey: async function (chainId = this.chainId) {
      const res = await postMsg("GET_KEY", { chainId });
      if (res) {
        return {
          name: res.name || "Spider Vault",
          algo: res.algo || "secp256k1",
          pubKey: res.pubKey ? (typeof res.pubKey === "string" ? new TextEncoder().encode(res.pubKey) : res.pubKey) : new Uint8Array(33),
          address: res.address ? (typeof res.address === "string" ? new TextEncoder().encode(res.address) : res.address) : new Uint8Array(20),
          bech32Address: res.address || res.bech32Address || "",
          isNanoLedger: false,
          isKeystone: false
        };
      }
      return null;
    },

    getAccounts: async function (chainId = this.chainId) {
      const key = await this.getKey(chainId);
      if (!key) return [];
      return [{
        address: key.bech32Address,
        algo: key.algo,
        pubkey: key.pubKey
      }];
    },

    getOfflineSigner: function (chainId = this.chainId) {
      const self = this;
      return {
        getAccounts: async () => self.getAccounts(chainId),
        signDirect: async (signerAddress, signDoc) => {
          return postMsg("SIGN_DIRECT", { signerAddress, signDoc, chainId });
        },
        signAmino: async (signerAddress, signDoc) => {
          return postMsg("SIGN_AMINO", { signerAddress, signDoc, chainId });
        }
      };
    },

    getOfflineSignerOnlyAmino: function (chainId = this.chainId) {
      return this.getOfflineSigner(chainId);
    },

    getOfflineSignerAuto: async function (chainId = this.chainId) {
      return this.getOfflineSigner(chainId);
    },

    signDirect: async function (chainIdOrSigner, signerOrSignDoc, signDoc) {
      if (signDoc !== undefined) {
        return postMsg("SIGN_DIRECT", { signerAddress: signerOrSignDoc, signDoc, chainId: chainIdOrSigner });
      }
      return postMsg("SIGN_DIRECT", { signerAddress: chainIdOrSigner, signDoc: signerOrSignDoc, chainId: this.chainId });
    },

    signAmino: async function (chainIdOrSigner, signerOrSignDoc, signDoc) {
      if (signDoc !== undefined) {
        return postMsg("SIGN_AMINO", { signerAddress: signerOrSignDoc, signDoc, chainId: chainIdOrSigner });
      }
      return postMsg("SIGN_AMINO", { signerAddress: chainIdOrSigner, signDoc: signerOrSignDoc, chainId: this.chainId });
    },

    signArbitrary: async function (signerOrChainId, dataOrSigner, maybeData) {
      if (maybeData !== undefined) {
        return postMsg("SIGN_ARBITRARY", { signer: dataOrSigner, data: maybeData, chainId: signerOrChainId });
      }
      return postMsg("SIGN_ARBITRARY", { signer: signerOrChainId, data: dataOrSigner });
    },

    verifyArbitrary: async function () {
      return true;
    },

    signAndBroadcast: async function (tx) {
      return postMsg("SIGN_AND_BROADCAST", { tx, origin: window.location.origin });
    },

    executeContract: async function ({ contractAddress, msg, funds = [], fee }) {
      return postMsg("EXECUTE_WASM_CONTRACT", {
        contractAddress,
        msg,
        funds,
        fee,
        origin: window.location.origin
      });
    },

    instantiateContract: async function ({ codeId, label, msg, admin, funds = [], fee }) {
      return postMsg("INSTANTIATE_WASM_CONTRACT", {
        codeId,
        label,
        msg,
        admin,
        funds,
        fee,
        origin: window.location.origin
      });
    },

    uploadContract: async function ({ wasmByteCode, fee, memo }) {
      return postMsg("UPLOAD_WASM_CONTRACT", {
        wasmByteCode,
        fee,
        memo,
        origin: window.location.origin
      });
    },

    sendTx: async function ({ recipient, amount, denom = "uluxa", memo = "" }) {
      return postMsg("SEND_TRANSACTION", { recipient, amount, denom, memo });
    },

    getTestnetBalance: async function (targetAddress) {
      const key = await this.getKey(this.chainId);
      const addr = targetAddress || key?.bech32Address;
      if (!addr) throw new Error("Vault not connected");
      const res = await fetch(`https://luxaecosystem.alwaysdata.net/api/testnet/balances/${encodeURIComponent(addr)}`);
      return res.json();
    },

    requestTestnetFaucet: async function (targetAddress) {
      const key = await this.getKey(this.chainId);
      const addr = targetAddress || key?.bech32Address;
      if (!addr) throw new Error("Vault not connected");
      const res = await fetch(`https://luxaecosystem.alwaysdata.net/api/testnet/faucet`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ address: addr })
      });
      return res.json();
    },

    on: function (eventName, handler) {
      if (typeof handler !== "function") return;
      if (!eventListeners.has(eventName)) eventListeners.set(eventName, new Set());
      eventListeners.get(eventName).add(handler);
    },

    off: function (eventName, handler) {
      const handlers = eventListeners.get(eventName);
      if (handlers) {
        handlers.delete(handler);
        if (handlers.size === 0) eventListeners.delete(eventName);
      }
    },

    removeListener: function (eventName, handler) {
      this.off(eventName, handler);
    }
  };

  // 1. Sovereign Web3 & Keplr Compatibility Layer
  window.luxa = spiderProvider;
  window.spiderVault = spiderProvider;

  if (!window.keplr) {
    window.keplr = spiderProvider;
  }
  if (!window.getOfflineSigner) {
    window.getOfflineSigner = (chainId) => spiderProvider.getOfflineSigner(chainId);
  }
  if (!window.getOfflineSignerOnlyAmino) {
    window.getOfflineSignerOnlyAmino = (chainId) => spiderProvider.getOfflineSignerOnlyAmino(chainId);
  }
  if (!window.getOfflineSignerAuto) {
    window.getOfflineSignerAuto = (chainId) => spiderProvider.getOfflineSignerAuto(chainId);
  }

  // 2. EIP-6963 Multi-Injected Provider Discovery Standard
  const SPIDER_VAULT_UUID = "e467cf77-94d0-4ea2-8ce1-6963luxavault";
  const SPIDER_VAULT_RDNS = "xyz.luxaecosystem.spider-vault";
  const SPIDER_VAULT_NAME = "Spider Vault";
  const SPIDER_VAULT_ICON = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 128'%3E%3Crect width='128' height='128' rx='28' fill='%230a0f1d'/%3E%3Crect x='2' y='2' width='124' height='124' rx='26' fill='none' stroke='%2338bdf8' stroke-width='2' stroke-opacity='0.4'/%3E%3Cpolygon points='64,20 102,42 102,86 64,108 26,86 26,42' fill='none' stroke='%2338bdf8' stroke-width='2.5' stroke-dasharray='4,2'/%3E%3Ccircle cx='64' cy='56' r='10' fill='%23fbbf24'/%3E%3Ccircle cx='64' cy='74' r='14' fill='%23fbbf24'/%3E%3Ccircle cx='61' cy='54' r='1.5' fill='%23040711'/%3E%3Ccircle cx='67' cy='54' r='1.5' fill='%23040711'/%3E%3Cpath d='M54 58 Q34 46 30 36 M54 64 Q30 60 22 66 M54 70 Q30 76 24 88 M54 76 Q34 94 32 104' fill='none' stroke='%23fbbf24' stroke-width='3' stroke-linecap='round'/%3E%3Cpath d='M74 58 Q94 46 98 36 M74 64 Q98 60 106 66 M74 70 Q98 76 104 88 M74 76 Q94 94 96 104' fill='none' stroke='%23fbbf24' stroke-width='3' stroke-linecap='round'/%3E%3C/svg%3E";

  const eip6963Info = Object.freeze({
    uuid: SPIDER_VAULT_UUID,
    name: SPIDER_VAULT_NAME,
    icon: SPIDER_VAULT_ICON,
    rdns: SPIDER_VAULT_RDNS
  });

  const eip1193Provider = {
    isSpiderVault: true,
    isMetaMask: false,
    chainId: "0x1",
    networkVersion: "1",

    request: async function ({ method, params = [] }) {
      switch (method) {
        case "eth_requestAccounts": {
          await spiderProvider.connect();
          const key = await spiderProvider.getKey();
          return key?.bech32Address ? [key.bech32Address] : [];
        }
        case "eth_accounts": {
          try {
            const key = await spiderProvider.getKey();
            return key?.bech32Address ? [key.bech32Address] : [];
          } catch (_) {
            return [];
          }
        }
        case "eth_chainId":
          return "0x1";
        case "net_version":
          return "1";
        case "personal_sign": {
          const [message, address] = params;
          return spiderProvider.signArbitrary(address, message);
        }
        case "wallet_switchEthereumChain":
        case "wallet_addEthereumChain":
          return null;
        default:
          throw new Error(`Spider Vault EIP-1193: method '${method}' handled in sovereign multi-chain bridge.`);
      }
    },

    on: function (event, handler) { spiderProvider.on(event, handler); },
    off: function (event, handler) { spiderProvider.off(event, handler); },
    removeListener: function (event, handler) { spiderProvider.off(event, handler); },
    addListener: function (event, handler) { spiderProvider.on(event, handler); }
  };

  function announceEip6963() {
    window.dispatchEvent(
      new CustomEvent("eip6963:announceProvider", {
        detail: Object.freeze({ info: eip6963Info, provider: eip1193Provider })
      })
    );
  }

  window.addEventListener("eip6963:requestProvider", () => {
    announceEip6963();
  });

  // Announce EIP-6963 immediately
  announceEip6963();

  // If no other EVM provider is present, expose fallback
  if (!window.ethereum) {
    window.ethereum = eip1193Provider;
  }

  // 3. Dispatch initialization lifecycle events
  window.dispatchEvent(new CustomEvent("luxa#initialized"));
  window.dispatchEvent(new CustomEvent("keplr_keystorechange"));
})();
