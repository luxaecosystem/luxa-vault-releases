// background/background.js
let cosmJsLoadError = null;
try {
  importScripts("/libs/cosmjs.bundle.js");
  console.log("[LUXA Background] CosmJS bundle loaded successfully:", Boolean(globalThis.CosmJS));
} catch (err) {
  cosmJsLoadError = err;
  console.error("[LUXA Background] Error loading cosmjs.bundle.js:", err);
}

// Opens an independent approval window for the CONNECT_SITE handshake.
// DO NOT use chrome.action.openPopup() here: it requires a user gesture recognized
// by Chrome, and called from onMessage/onMessageExternal after an async tick
// errors from chrome.storage are intentionally ignored because no popup is opened.
function isOriginAuthorized(data, origin) {
  const approved = Array.from(new Set([...(data?.approved_origins || []), ...(data?.connected_sites || [])]));
  if (approved.includes(origin)) return true;
  if (Boolean(data?.white_card_authorized) || approved.includes("*.luxaecosystem.xyz")) {
    try {
      const u = new URL(origin);
      if (u.hostname === "luxaecosystem.xyz" || u.hostname.endsWith(".luxaecosystem.xyz")) {
        return true;
      }
    } catch (_) {}
  }
  return false;
}

function openApprovalWindow(reqId, origin) {
  chrome.windows.create({
    url: chrome.runtime.getURL(`popup/popup.html?mode=approve&reqId=${reqId}&origin=${encodeURIComponent(origin)}`),
    type: "popup",
    width: 380,
    height: 600
  });
}

chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
  const isAllowedOrigin = (orig) => {
    if (!orig) return false;
    try {
      const url = new URL(orig);
      const host = url.hostname;
      return (
        host === "localhost" ||
        host === "127.0.0.1" ||
        host === "luxaecosystem.xyz" ||
        host.endsWith(".luxaecosystem.xyz") ||
        host === "frontend-studio-phi.vercel.app"
      );
    } catch {
      return false;
    }
  };

  if (request.action === "PING_VAULT") {
    chrome.storage.local.get(["luxa_vault", "is_unlocked"], (data) => {
      sendResponse({
        status: "ready",
        isUnlocked: Boolean(data.is_unlocked),
        address: data.is_unlocked ? data.luxa_vault?.address : null
      });
    });
    return true;
  }

  if (request.action === "EXECUTE_WASM_CONTRACT") {
    const { contractAddress, msg, funds, mnemonic } = request;
    const origin = sender?.origin || "";
    if (!isAllowedOrigin(origin)) {
      sendResponse({ success: false, error: "Origin not allowed." });
      return false;
    }

    (async () => {
      try {
        const wallet = await globalThis.CosmJS.DirectSecp256k1HdWallet.fromMnemonic(mnemonic, {
          prefix: "luxa"
        });
        const client = await globalThis.CosmJS.SigningCosmWasmClient.connectWithSigner(
          "https://rpc.luxaecosystem.xyz",
          wallet,
          { gasPrice: globalThis.CosmJS.GasPrice.fromString("0.0025uluxa") }
        );

        const [account] = await wallet.getAccounts();
        const result = await client.execute(
          account.address,
          contractAddress,
          msg,
          "auto",
          "LUXA DEX Execution",
          funds || []
        );

        sendResponse({ success: true, result: serializeTransactionResult(result) });
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  return false;
});

const LUXA_RPC = "https://rpc.luxaecosystem.xyz";
const BACKEND_API = "https://luxaecosystem.alwaysdata.net/api";
const CHAIN_PREFIX = "luxa";
const DENOM = "uluxa";
const LUXA_HD_PATH = "m/44'/118'/0'/0/0";

const pendingAuthRequests = new Map();
const pendingRequests = new Map();

function serializeTransactionResult(result) {
  return {
    txHash: String(result?.transactionHash || ""),
    height: String(result?.height || ""),
    gasUsed: Number(result?.gasUsed || 0),
    codeId: result?.codeId != null ? Number(result.codeId) : undefined,
    contractAddress: result?.contractAddress ? String(result.contractAddress) : undefined
  };
}

async function finalizeSignedRequest(request) {
  const { txData, mnemonic } = request;
  if (!mnemonic) throw new Error("Vault is locked: mnemonic is missing.");
  if (cosmJsLoadError || !globalThis.CosmJS) {
    throw new Error(`CosmJS engine offline: ${cosmJsLoadError?.message || "unknown error"}`);
  }

  const hdPath = globalThis.CosmJS.stringToPath
    ? globalThis.CosmJS.stringToPath(LUXA_HD_PATH)
    : undefined;
  const wallet = await globalThis.CosmJS.DirectSecp256k1HdWallet.fromMnemonic(mnemonic, {
    prefix: CHAIN_PREFIX,
    ...(hdPath ? { hdPaths: [hdPath] } : {})
  });
  const [account] = await wallet.getAccounts();

  if (txData.action === "UPLOAD_WASM_CONTRACT" || txData.wasmByteCode) {
    const client = await globalThis.CosmJS.SigningCosmWasmClient.connectWithSigner(
      LUXA_RPC,
      wallet,
      { gasPrice: globalThis.CosmJS.GasPrice.fromString("0.0025uluxa") }
    );
    let wasmBytes = txData.wasmByteCode;
    if (typeof wasmBytes === "string") {
      const binStr = atob(wasmBytes);
      const len = binStr.length;
      wasmBytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        wasmBytes[i] = binStr.charCodeAt(i);
      }
    } else if (wasmBytes && typeof wasmBytes === "object" && !ArrayBuffer.isView(wasmBytes)) {
      const keys = Object.keys(wasmBytes).map(Number).sort((a, b) => a - b);
      const arr = new Uint8Array(keys.length);
      for (let i = 0; i < keys.length; i++) {
        arr[i] = wasmBytes[keys[i]];
      }
      wasmBytes = arr;
    }
    const requestedGas = txData.fee?.gas ? Number(txData.fee.gas) : 0;
    const gasLimit = Math.max(requestedGas, 6000000).toString();
    const feeAmount = txData.fee?.amount && txData.fee.amount.length > 0 && Number(txData.fee.amount[0].amount) >= 30000
      ? txData.fee.amount
      : [{ denom: DENOM, amount: "30000" }];
    const fee = {
      amount: feeAmount,
      gas: gasLimit
    };
    const result = await client.upload(
      account.address,
      wasmBytes,
      fee,
      txData.memo || "LUXA Store CW20 Contract"
    );
    await client.disconnect();
    return result;
  }

  if (txData.action === "INSTANTIATE_WASM_CONTRACT" || (txData.codeId && !txData.contractAddress && !txData.tx)) {
    const client = await globalThis.CosmJS.SigningCosmWasmClient.connectWithSigner(
      LUXA_RPC,
      wallet,
      { gasPrice: globalThis.CosmJS.GasPrice.fromString("0.0025uluxa") }
    );
    const result = await client.instantiate(
      account.address,
      Number(txData.codeId),
      txData.msg || {},
      txData.label || "Contract",
      txData.fee || "auto",
      {
        admin: txData.admin || account.address,
        funds: txData.funds || []
      }
    );
    await client.disconnect();
    return {
      success: true,
      contractAddress: result.contractAddress,
      transactionHash: result.transactionHash,
      txHash: result.transactionHash,
      hash: result.transactionHash,
      ...result
    };
  }

  if (txData.action === "EXECUTE_WASM_CONTRACT" || txData.contractAddress) {
    if (!txData.contractAddress) throw new Error("Contract address is required.");
    const client = await globalThis.CosmJS.SigningCosmWasmClient.connectWithSigner(
      LUXA_RPC,
      wallet,
      { gasPrice: globalThis.CosmJS.GasPrice.fromString("0.0025uluxa") }
    );
    const result = await client.execute(
      account.address,
      txData.contractAddress,
      txData.msg,
      txData.fee || "auto",
      "LUXA DEX Execution",
      txData.funds || []
    );
    await client.disconnect();
    return {
      success: true,
      transactionHash: result.transactionHash,
      txHash: result.transactionHash,
      hash: result.transactionHash,
      ...result
    };
  }

  const tx = txData.tx?.tx || txData.tx || {};
  const messages = tx.messages || txData.messages || [];
  if (!Array.isArray(messages) || messages.length === 0) {
    throw new Error("Transaction must contain at least one message.");
  }
  if (messages.some((message) => !message?.typeUrl || !message?.value)) {
    throw new Error("Transaction contains an invalid message.");
  }

  // Restore Uint8Array for any byte fields (e.g. msg in MsgMigrateContract) that were converted to plain objects by Chrome messaging
  for (const m of messages) {
    if (m?.value?.msg && typeof m.value.msg === "object" && !ArrayBuffer.isView(m.value.msg)) {
      const keys = Object.keys(m.value.msg).map(Number).sort((a, b) => a - b);
      const arr = new Uint8Array(keys.length);
      for (let i = 0; i < keys.length; i++) arr[i] = m.value.msg[keys[i]];
      m.value.msg = arr;
    }
    // Harmonize delegator address with active signing address
    if (m?.value?.delegatorAddress && account?.address) {
      m.value.delegatorAddress = account.address;
    }
  }

  const hasWasm = messages.some((m) => m?.typeUrl && m.typeUrl.includes("wasm"));

  const client = (hasWasm && globalThis.CosmJS?.SigningCosmWasmClient)
    ? await globalThis.CosmJS.SigningCosmWasmClient.connectWithSigner(
        LUXA_RPC,
        wallet,
        { gasPrice: globalThis.CosmJS.GasPrice.fromString("0.0025uluxa") }
      )
    : await globalThis.CosmJS.SigningStargateClient.connectWithSigner(
        LUXA_RPC,
        wallet,
        { gasPrice: globalThis.CosmJS.GasPrice.fromString("0.0025uluxa") }
      );

  const fee = tx.fee || txData.fee || {
    amount: [{ denom: DENOM, amount: "200" }],
    gas: "200000"
  };
  const memo = tx.memo || txData.memo || "LUXA Spider's Nest transaction";
  const result = await client.signAndBroadcast(account.address, messages, fee, memo);
  await client.disconnect();

  if (result.code !== 0) {
    throw new Error(`Transaction failed on-chain (code ${result.code}): ${result.rawLog || "Validation failed"}`);
  }

  return result;
}

// Helper to notify all open tabs in real time
function broadcastToTabs(payload) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((tab) => {
      if (tab.id) {
        chrome.tabs.sendMessage(tab.id, payload).catch(() => {});
      }
    });
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // Background Live Oracle Proxy (Bypasses popup CORS restrictions)
  if (msg.action === "FETCH_PRICE_ORACLE") {
    fetch("https://api.coingecko.com/api/v3/simple/price?ids=cosmos,celestia,osmosis,usd-coin&vs_currencies=usd,eur,gbp&include_24hr_change=true")
      .then(r => {
        if (!r.ok) throw new Error("CoinGecko HTTP " + r.status);
        return r.json();
      })
      .then(data => sendResponse({ success: true, source: "coingecko", data }))
      .catch(err => {
        fetch("https://api.binance.com/api/v3/ticker/24hr?symbols=[%22ATOMUSDT%22,%22TIAUSDT%22,%22OSMOUSDT%22,%22USDCUSDT%22]")
          .then(r => {
            if (!r.ok) throw new Error("Binance HTTP " + r.status);
            return r.json();
          })
          .then(binanceData => sendResponse({ success: true, source: "binance", binanceData }))
          .catch(bErr => sendResponse({ success: false, error: err.message || bErr.message }));
      });
    return true; // Keep async response channel open
  }


  // ============================================================
  // 1. VAULT STATE SYNCHRONIZATION -> TABS
  // ============================================================
  if (msg.action === "BROADCAST_VAULT_UNLOCKED" || msg.action === "VAULT_READY_BROADCAST") {
    broadcastToTabs({
      action: "ON_VAULT_UNLOCKED",
      address: msg.address
    });
    sendResponse({ ok: true });
    return false;
  }

  if (msg.action === "BROADCAST_VAULT_LOCKED") {
    broadcastToTabs({ action: "ON_VAULT_LOCKED" });
    sendResponse({ ok: true });
    return false;
  }

  if (msg.action === "BROADCAST_VAULT_REVOKED") {
    broadcastToTabs({
      action: "ON_VAULT_DISCONNECTED",
      origin: msg.origin || null
    });
    sendResponse({ ok: true });
    return false;
  }

  // ============================================================
  // 2. COSMOS SDK KEY DERIVATION (IDENTICAL TO MINI APP)
  // ============================================================
  if (msg.action === "DERIVE_WALLET_FROM_MNEMONIC") {
    (async () => {
      let cleanMnemonic = (msg.mnemonic || "").trim().toLowerCase().replace(/\s+/g, " ");
      try {
        if (cosmJsLoadError || !globalThis.CosmJS) {
          throw new Error(`CosmJS bundle not loaded in background: ${cosmJsLoadError?.message || "unknown error"}`);
        }

        const hdPath = globalThis.CosmJS.stringToPath
          ? globalThis.CosmJS.stringToPath(LUXA_HD_PATH)
          : undefined;
        const walletOptions = { prefix: CHAIN_PREFIX };
        if (hdPath) walletOptions.hdPaths = [hdPath];

        const wallet = await globalThis.CosmJS.DirectSecp256k1HdWallet.fromMnemonic(cleanMnemonic, walletOptions);
        const [account] = await wallet.getAccounts();
        
        cleanMnemonic = null;
        sendResponse({ address: account.address });
      } catch (err) {
        cleanMnemonic = null;
        sendResponse({ error: err.message });
      }
    })();
    return true;
  }

  // ============================================================
  // 3. GENERAZIONE NUOVO WALLET (24 PAROLE + HD PATH STANDARD)
  // ============================================================
  if (msg.action === "GENERATE_NEW_WALLET") {
    (async () => {
      try {
        if (cosmJsLoadError || !globalThis.CosmJS) {
          throw new Error(cosmJsLoadError ? cosmJsLoadError.message : "CosmJS is not initialized");
        }

        const hdPath = globalThis.CosmJS.stringToPath
          ? globalThis.CosmJS.stringToPath(LUXA_HD_PATH)
          : undefined;
        const walletOptions = { prefix: CHAIN_PREFIX };
        if (hdPath) walletOptions.hdPaths = [hdPath];

        const wallet = await globalThis.CosmJS.DirectSecp256k1HdWallet.generate(24, walletOptions);
        const [account] = await wallet.getAccounts();

        sendResponse({ mnemonic: wallet.mnemonic, address: account.address });
      } catch (err) {
        sendResponse({ error: err.message });
      }
    })();
    return true;
  }

  if (msg.action === "SIGN_AND_BROADCAST" || msg.action === "EXECUTE_WASM_CONTRACT" || msg.action === "INSTANTIATE_WASM_CONTRACT" || msg.action === "UPLOAD_WASM_CONTRACT") {
    const origin = sender.origin || (sender.tab && new URL(sender.tab.url).origin) || "unknown";
    chrome.storage.local.get(["approved_origins", "connected_sites", "white_card_authorized"], (data) => {
      if (!isOriginAuthorized(data, origin)) {
        sendResponse({ error: "UNAUTHORIZED_ORIGIN" });
        return;
      }

      const reqId = "sign_" + Date.now() + "_" + Math.random().toString(36).slice(2);
      pendingRequests.set(reqId, { sendResponse, txData: { ...msg, origin } });
      chrome.windows.create({
        url: chrome.runtime.getURL(`popup/popup.html?mode=sign&reqId=${reqId}`),
        type: "popup",
        width: 380,
        height: 640
      });
    });
    return true;
  }

  // ============================================================
  
const INBOUND_IBC_CHAINS = {
  cosmoshub: {
    chainName: "Cosmos Hub",
    prefix: "cosmos",
    channel: "channel-1941",
    denom: "uatom",
    gasPrice: "0.025uatom",
    feeAmount: "5000",
    rpcs: ["https://cosmos-rpc.publicnode.com:443", "https://rpc.cosmos.directory/cosmoshub"]
  },
  cosmos: {
    chainName: "Cosmos Hub",
    prefix: "cosmos",
    channel: "channel-1941",
    denom: "uatom",
    gasPrice: "0.025uatom",
    feeAmount: "5000",
    rpcs: ["https://cosmos-rpc.publicnode.com:443", "https://rpc.cosmos.directory/cosmoshub"]
  },
  celestia: {
    chainName: "Celestia",
    prefix: "celestia",
    channel: "channel-709",
    denom: "utia",
    gasPrice: "0.02utia",
    feeAmount: "5000",
    rpcs: ["https://celestia-rpc.publicnode.com:443", "https://rpc.cosmos.directory/celestia"]
  },
  osmosis: {
    chainName: "Osmosis",
    prefix: "osmo",
    channel: "channel-111100",
    denom: "uosmo",
    gasPrice: "0.025uosmo",
    feeAmount: "6000",
    rpcs: ["https://osmosis-rpc.publicnode.com:443", "https://rpc.cosmos.directory/osmosis"]
  },
  noble: {
    chainName: "Noble",
    prefix: "noble",
    channel: "channel-640",
    denom: "uusdc",
    gasPrice: "0.025uusdc",
    feeAmount: "5000",
    rpcs: ["https://noble-rpc.polkachu.com:443", "https://rpc.cosmos.directory/noble"]
  }
};

  // 4. SIGN AND BROADCAST ON-CHAIN TRANSACTION (100% LOCAL)
  // ============================================================
  if (msg.action === "SEND_TRANSACTION" || msg.action === "SEND_TX") {
    (async () => {
      let rawMnemonic = (msg.mnemonic || "").trim();
      const recipient = (msg.recipient || "").trim().toLowerCase();
      const numAmount = Number(msg.amount);
      const fromChain = (msg.fromChain || "").trim().toLowerCase();
      const transferDenom = (msg.denom && typeof msg.denom === "string" && msg.denom.trim()) ? msg.denom.trim() : DENOM;

      try {
        const isIbcTransfer = (
          recipient.startsWith("celestia1") ||
          recipient.startsWith("cosmos1") ||
          recipient.startsWith("noble1") ||
          recipient.startsWith("osmo1")
        );

        if (!isIbcTransfer && (!recipient.startsWith("luxa1") || recipient.length < 38)) {
          throw new Error("Recipient address format is invalid. Must be luxa1... or an IBC address (celestia1, cosmos1, noble1, osmo1).");
        }
        if (isNaN(numAmount) || numAmount <= 0) {
          throw new Error("Transfer amount is invalid.");
        }

        const storageData = await new Promise((resolve) => {
          chrome.storage.local.get(["active_network", "luxa_vault"], resolve);
        });
        const isTestnet = storageData.active_network === "testnet";

        if (isTestnet) {
          const senderAddress = storageData.luxa_vault?.address;
          if (!senderAddress) throw new Error("Vault is inactive or locked.");

          const testnetRes = await fetch(`${BACKEND_API}/testnet/transfer`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              senderAddress,
              recipientAddress: recipient,
              amount: numAmount,
              currency: transferDenom === "ushard" ? "shards" : "luxa"
            })
          });
          const testnetData = await testnetRes.json();
          if (!testnetRes.ok || !testnetData.success) {
            throw new Error(testnetData.error || "Testnet transfer failed.");
          }

          rawMnemonic = null;
          return sendResponse({
            result: {
              success: true,
              txHash: testnetData.txHash,
              height: testnetData.height,
              sender: senderAddress,
              recipient,
              amount: numAmount,
              network: "luxa-testnet"
            }
          });
        }

        if (cosmJsLoadError || !globalThis.CosmJS) {
          throw new Error(`CosmJS engine offline: ${cosmJsLoadError?.message || "unknown error"}`);
        }
        if (!rawMnemonic) throw new Error("Vault is locked: mnemonic is missing.");

        // ============================================================
        // 4A. CROSS-CHAIN INBOUND IBC (Cosmos Hub, Celestia, Osmosis, Noble -> LUXA Network)
        // ============================================================
        if (fromChain && INBOUND_IBC_CHAINS[fromChain]) {
          const cfg = INBOUND_IBC_CHAINS[fromChain];
          if (!recipient.startsWith("luxa1")) {
            throw new Error(`When bridging tokens to LUXA Network, recipient must be your luxa1... address.`);
          }

          const chainWallet = await globalThis.CosmJS.DirectSecp256k1HdWallet.fromMnemonic(rawMnemonic, { prefix: cfg.prefix });
          const [chainAcc] = await chainWallet.getAccounts();
          const chainSender = chainAcc.address;

          let chainClient = null;
          let lastErr = null;
          for (const rpc of cfg.rpcs) {
            try {
              chainClient = await globalThis.CosmJS.SigningStargateClient.connectWithSigner(
                rpc,
                chainWallet,
                { gasPrice: globalThis.CosmJS.GasPrice.fromString(cfg.gasPrice) }
              );
              if (chainClient) break;
            } catch (e) {
              lastErr = e;
            }
          }

          if (!chainClient) {
            throw new Error(`Could not connect to ${cfg.chainName} RPC node: ${lastErr?.message || lastErr}`);
          }

          const microAmount = BigInt(Math.round(numAmount * 1000000)).toString();
          const cosmosFee = {
            amount: [{ denom: cfg.denom, amount: cfg.feeAmount }],
            gas: "220000"
          };
          const timeoutTimestamp = Math.floor(Date.now() / 1000) + 900; // 15 mins timeout

          const ibcResult = await chainClient.sendIbcTokens(
            chainSender,
            recipient,
            { denom: cfg.denom, amount: microAmount },
            "transfer",
            cfg.channel,
            undefined,
            timeoutTimestamp,
            cosmosFee,
            `LUXA Spider Vault Cross-Chain Inbound IBC from ${cfg.chainName}`
          );

          await chainClient.disconnect();
          rawMnemonic = null;

          if (ibcResult.code !== 0) {
            throw new Error(ibcResult.rawLog || `${cfg.chainName} rejected transaction with code ${ibcResult.code}`);
          }

          return sendResponse({
            result: {
              success: true,
              txHash: ibcResult.transactionHash,
              sender: chainSender,
              recipient,
              amount: numAmount,
              network: cfg.chainName,
              channel: cfg.channel
            }
          });
        }

        // Derivation consistent with standard HD path m/44'/118'/0'/0/0
        const hdPath = globalThis.CosmJS.stringToPath
          ? globalThis.CosmJS.stringToPath(LUXA_HD_PATH)
          : undefined;
        const walletOptions = { prefix: CHAIN_PREFIX };
        if (hdPath) walletOptions.hdPaths = [hdPath];

        const wallet = await globalThis.CosmJS.DirectSecp256k1HdWallet.fromMnemonic(rawMnemonic, walletOptions);
        const [account] = await wallet.getAccounts();
        const senderAddress = account.address;

        const client = await globalThis.CosmJS.SigningStargateClient.connectWithSigner(
          LUXA_RPC,
          wallet,
          { gasPrice: globalThis.CosmJS.GasPrice.fromString("0.0025uluxa") }
        );

        const microAmount = BigInt(Math.round(numAmount * 1000000)).toString();
        const fee = {
          amount: [{ denom: DENOM, amount: "200" }],
          gas: "200000"
        };

        let result;
        if (isIbcTransfer) {
          let sourceChannel = "channel-3";
          if (recipient.startsWith("celestia1")) sourceChannel = "channel-3";
          else if (recipient.startsWith("cosmos1")) sourceChannel = "channel-2";
          else if (recipient.startsWith("noble1")) sourceChannel = "channel-4";
          else if (recipient.startsWith("osmo1")) sourceChannel = "channel-1";

          const timeoutTimestamp = Math.floor(Date.now() / 1000) + 600;

          result = await client.sendIbcTokens(
            senderAddress,
            recipient,
            { denom: transferDenom, amount: microAmount },
            "transfer",
            sourceChannel,
            undefined,
            timeoutTimestamp,
            fee,
            "LUXA Spider Vault Cross-Chain Transfer"
          );
        } else {
          result = await client.sendTokens(
            senderAddress,
            recipient,
            [{ denom: transferDenom, amount: microAmount }],
            fee,
            "LUXA Spider's Nest Transfer"
          );
        }

        await client.disconnect();
        rawMnemonic = null;

        if (result.code !== 0) {
          throw new Error(result.rawLog || `Chain rejected transaction with code ${result.code}`);
        }

        fetch(`${BACKEND_API}/ecosystem/chain/record-public-tx`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            txHash: result.transactionHash,
            sender: senderAddress,
            recipient: recipient,
            amount: numAmount,
            height: result.height
          })
        }).catch(() => {});

        sendResponse({
          result: {
            success: true,
            txHash: result.transactionHash,
            height: result.height,
            sender: senderAddress,
            recipient: recipient,
            amount: numAmount,
            network: "luxa-1"
          }
        });
      } catch (err) {
        rawMnemonic = null;
        sendResponse({ error: err.message });
      }
    })();
    return true;
  }

  // ============================================================
  // 5. WEB3 HANDSHAKE (WINDOW.LUXA CONNECT & KEY)
  // ============================================================
  if (msg.action === "CONNECT_SITE") {
    const origin = sender.origin || (sender.tab && new URL(sender.tab.url).origin) || "unknown";

    chrome.storage.local.get(["luxa_vault", "luxa_vaults", "is_unlocked", "approved_origins", "connected_sites", "white_card_authorized", "active_network"], (data) => {
      const hasVaults = (data.luxa_vaults && data.luxa_vaults.length > 0) || Boolean(data.luxa_vault?.address);
      const chainId = data.active_network === "testnet" ? "luxa-testnet" : "luxa-1";

      // If the vault is not ready, still open the vault window
      // ("no wallet" or "unlock" screen) so the user can fix it;
      // the dapp receives the error immediately and just needs to retry
      // "Connect" once the vault is ready.
      if (!hasVaults || !data.is_unlocked) {
        chrome.windows.create({
          url: chrome.runtime.getURL("popup/popup.html"),
          type: "popup",
          width: 380,
          height: 600
        });

        return sendResponse({
          error: !hasVaults ? "NO_WALLET_FOUND" : "VAULT_LOCKED"
        });
      }

      if (isOriginAuthorized(data, origin)) {
        return sendResponse({
          result: {
            connected: true,
            address: data.luxa_vault.address,
            chainId
          }
        });
      }

      // If not approved or revoked, create the request and open the approval window
      const reqId = "req_" + Math.random().toString(36).slice(2);
      pendingAuthRequests.set(reqId, { origin, sendResponse });

      chrome.storage.local.set({ pending_connect_req: { reqId, origin } });

      openApprovalWindow(reqId, origin);

      setTimeout(() => {
        if (pendingAuthRequests.has(reqId)) {
          pendingAuthRequests.delete(reqId);
          try {
            sendResponse({ error: "AUTHORIZATION_TIMEOUT" });
          } catch (_) {}
        }
      }, 120000);
    });
    return true;
  }

  if (msg.action === "RESOLVE_CONNECT_REQUEST") {
    const { reqId, approved } = msg;
    const pending = pendingAuthRequests.get(reqId);

    chrome.storage.local.remove("pending_connect_req");

    if (pending) {
      pendingAuthRequests.delete(reqId);
      if (approved) {
        chrome.storage.local.get(["approved_origins", "connected_sites", "white_card_authorized", "luxa_vault", "active_network"], (data) => {
          const origins = Array.isArray(data.approved_origins) ? [...data.approved_origins] : [];
          const sites = Array.isArray(data.connected_sites) ? [...data.connected_sites] : [];
          const chainId = data.active_network === "testnet" ? "luxa-testnet" : "luxa-1";
          const isWildcard = msg.scope === "wildcard" || msg.authScope === "wildcard";
          if (isWildcard) {
            if (!origins.includes("*.luxaecosystem.xyz")) origins.push("*.luxaecosystem.xyz");
            if (!sites.includes("*.luxaecosystem.xyz")) sites.push("*.luxaecosystem.xyz");
          }
          if (pending.origin) {
            if (!origins.includes(pending.origin)) origins.push(pending.origin);
            if (!sites.includes(pending.origin)) sites.push(pending.origin);
          }
          const patch = { approved_origins: origins, connected_sites: sites };
          if (isWildcard) patch.white_card_authorized = true;
          chrome.storage.local.set(patch);
          pending.sendResponse({
            result: {
              connected: true,
              address: data.luxa_vault?.address,
              chainId
            }
          });
          broadcastToTabs({
            action: "ON_VAULT_UNLOCKED",
            address: data.luxa_vault?.address
          });
        });
      } else {
        pending.sendResponse({ error: "Connection request rejected by user." });
      }
    }
    sendResponse({ ok: true });
    return false;
  }

  if (msg.action === "GET_PENDING_SIGN_REQUEST") {
    const req = pendingRequests.get(msg.reqId);
    sendResponse({ txData: req ? req.txData : null });
    return false;
  }

  if (msg.action === "RESOLVE_SIGN_REQUEST") {
    const req = pendingRequests.get(msg.reqId);
    if (req) {
      pendingRequests.delete(msg.reqId);
      (async () => {
        try {
          if (msg.error) {
            req.sendResponse({ error: msg.error });
            return;
          }
          const result = await finalizeSignedRequest({ txData: req.txData, mnemonic: msg.mnemonic });
          req.sendResponse({ result: serializeTransactionResult(result) });
        } catch (err) {
          req.sendResponse({ error: err.message });
        }
      })();
    }
    sendResponse({ ok: true });
    return false;
  }

  if (msg.action === "GET_KEY" || msg.action === "GET_ACCOUNTS") {
    const origin = sender.origin || (sender.tab && new URL(sender.tab.url).origin) || "unknown";

    chrome.storage.local.get(["luxa_vault", "is_unlocked", "approved_origins", "active_network"], (data) => {
      if (!data.luxa_vault?.address || !data.is_unlocked) {
        return sendResponse({ error: "VAULT_LOCKED" });
      }

      const approved = data.approved_origins || [];
      if (!approved.includes(origin)) {
        return sendResponse({ error: "UNAUTHORIZED_ORIGIN" });
      }

      sendResponse({
        result: {
          address: data.luxa_vault.address,
          name: data.luxa_vault.name || "Vault",
          algo: "secp256k1",
          chainId: data.active_network === "testnet" ? "luxa-testnet" : "luxa-1"
        }
      });
    });
    return true;
  }

  return false;
});