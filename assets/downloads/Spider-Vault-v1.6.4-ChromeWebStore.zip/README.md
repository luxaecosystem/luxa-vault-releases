# LUXA Vault - Spider's Nest

Browser extension source package for the LUXA Vault sovereign cards.

## Project Root

The project root contains the following files and assets:

```text
.
├── background/
│   └── background.js
├── content/
│   └── content.js
├── icons/
│   ├── LUX_Vault.svg
│   ├── icon48.png
│   ├── LUX_Vault.svg
│   └── logo-lock.png
├── inpage/
│   └── inpage.js
├── libs/
│   └── cosmjs.bundle.js
├── menu_ui/
│   ├── boosts.png
│   ├── browser.png
│   ├── market.png
│   ├── mining.png
│   ├── nft.png
│   ├── rank.png
│   ├── rewards.png
│   ├── shop.png
│   ├── wallet.png
│   └── web-link.png
├── Nft_Images/
│   ├── Chrono-Key_Master.jpeg
│   ├── Cyber-Shadow_Node.jpeg
│   ├── Grandmaster_of_Servers.jpeg
│   └── Neon_Data_Valkyrie.jpeg
├── popup/
│   ├── background.png
│   ├── btn-disconnect.png
│   ├── popup.css
│   ├── popup.html
│   ├── popup.js
│   └── SPIDER'S_NEST.jpeg
├── bundle-entry.js
├── manifest.json
├── package.json
├── package-lock.json
└── README.md
```

## Requirements

- Operating system: Windows, macOS, or Linux
- Node.js 18 or newer
- npm 9 or newer

## Installation

From the project root, install the dependencies:

```bash
npm install
```

## Build

Build the CosmJS bundle for offline browser execution:

```bash
npm run build
```

The build uses `bundle-entry.js` and writes the generated bundle to
`libs/cosmjs.bundle.js`.

## Loading the Extension

1. Open the browser extensions page.
2. Enable Developer mode.
3. Choose **Load unpacked**.
4. Select this project root, the folder containing `manifest.json`.
