# Spider Vault — Chrome Web Store Official Listing Description (v1.6.4)

## Short Description (max 132 chars)
The official sovereign Web3 wallet for the LUXA Ecosystem and luxa-1 chain. Non-custodial, multi-vault, IBC & AMM liquidity.

---

## Detailed Description (Store Listing)

Spider Vault is the official sovereign Web3 wallet designed specifically for the LUXA Ecosystem and the high-speed luxa-1 chain. Engineered with military-grade client-side encryption, high-frequency execution, and absolute decentralization, Spider Vault provides users with total non-custodial sovereignty over their digital assets, identities, and smart contracts.

WHAT’S NEW IN VERSION 1.6.4:

• Privacy, Security & Recovery Center (Keplr Parity): Comprehensive self-custody support center directly integrated into the unlock screen, reset prompts, and settings. Access step-by-step wallet recovery guides, scam protection protocols, and zero-knowledge seed backup documentation.
• Revamped AMM Liquidity Pools & LP NFT Certificates: Redesigned Pools dashboard featuring real-time multi-pool telemetry, dynamic asset badge resolution for native and cross-chain liquidity pairs, responsive pool reserves, and interactive LUXA Sovereign LP NFT Certificate visualizer.
• Full Cross-Chain IBC Transfer Engine: Seamless bidirectional IBC transfers and balance monitoring across major interconnected Cosmos networks with automated channel negotiation.
• Live On-Chain Staking & Validator Telemetry: Real-time validator set synchronization directly from the bonded consensus state. Delegate, redelegate, unbond, and track live validator monikers and staking rewards directly in-wallet.
• In-Vault AMM Token Swap: Execute decentralized swaps directly inside the extension popup powered by constant-product liquidity pools (x · y = k) with real-time price quotes, slippage safeguards, and automated reserve telemetry.
• CosmWasm Smart Contract Engine: Full on-chain CosmWasm execution, deployment, instantiation, and migration support on luxa-1 across isolated browser extension IPC threads.
• CW20 Token Registry & Asset Telemetry: Automatic token logo resolution and on-chain CW20 balance queries via the official LUXA Token Registry and on-chain marketing metadata.
• Biometric & Native Mobile Synchronization (v1.6.4): Full feature parity between the Chrome Extension and the official Spider Vault Android APK with native fingerprint authentication and OTA updates.
• High-Speed Decentralized RPC Endpoints: Redundant fallback pipeline across verified SSL/TLS RPC, REST, and gRPC endpoints with optimized CORS preflight negotiation.

KEY CAPABILITIES:

• True Non-Custodial Enclave: Your 24-word secret recovery phrase (BIP-39) and cryptographic keys are encrypted locally using AES-256-GCM and PBKDF2 key derivation. Your sensitive private credentials never touch external servers, Google servers, or third parties.
• Zero-Knowledge Cloud Backup: Securely backup your encrypted vaults to your private Google Drive enclave with one click. Restoring your vaults on a new machine is instantaneous without compromising cryptographic security.
• CosmWasm Smart Contract Engine: Full on-chain CosmWasm execution, deployment, and instantiation support on luxa-1. Seamlessly trigger and verify smart contract calls with automated gas calculation and simulation.
• In-Vault AMM Token Swap: Execute decentralized swaps directly inside the extension popup powered by constant-product liquidity pools (x · y = k). Enjoy real-time price quotes, slippage safeguards, and automated reserve telemetry.
• Active Web3 Firewall & Site Manager: Full control over your on-chain visibility. Monitor active dApp sessions with visual connection indicators and instantly revoke permissions site-by-site.
• Optical QR Code Scanner: Integrated camera viewfinder and instant QR image file picker for lightning-fast, zero-error recipient address scanning.
• Multi-Token Transfer Engine: Send LUXA, SHARD, and CW20 tokens instantly with dynamic fee calculations, gas safeguards, and transaction status broadcast.
• Sovereign NFT & Relic Registry: Track on-chain Genesis Relics and protocol authority licenses directly within the built-in NFT visualizer.
• Real-Time CometBFT Sync: Direct RPC consensus validation (/tx_search) for immediate transfer history reflection and real-time ledger events.
• Cybernetic Reactive HUD: Minimalist, high-performance interface with dark cyberpunk styling, instant wallet switching, and multi-currency display.

OFFICIAL ECOSYSTEM LINKS:
• Website: https://luxaecosystem.xyz
• Support & Recovery Guide: https://luxaecosystem.xyz/support-recovery
• Block Explorer: https://explorer.luxaecosystem.xyz
• Decentralized Exchange (LDEX): https://ldex.luxaecosystem.xyz
• DEX Studio & Liquidity Hub: https://studio.luxaecosystem.xyz
• Validator & Staking Guide: https://luxaecosystem.xyz/validator-guide
• GitHub: https://github.com/luxaecosystem
• Official Facebook: https://www.facebook.com/luxaecosystem/
• Telegram Community: https://t.me/LuxaCommunity
• Telegram Announcements: https://t.me/LuxaToken_Official

---

## Chrome Web Store — Privacy & Permissions Justifications

### 1. Singolo scopo (Single Purpose Description)
Spider Vault is a sovereign, non-custodial Web3 wallet designed exclusively to manage cryptographic keys and execute blockchain transactions on the sovereign LUXA L1 blockchain (luxa-1) and connected Cosmos IBC networks. Its single purpose is to provide users with a secure local client-side enclave to generate and store encrypted keystores (BIP-39 / AES-256-GCM), view real-time account balances across native and cross-chain assets, manage AMM liquidity positions, stake with network validators, and sign transactions requested by authorized decentralized applications (dApps).

---

### 2. Motivazione per `storage`
The "storage" permission (chrome.storage.local) is essential to persist the user's client-side encrypted wallet keystores (AES-256-GCM ciphertext), local settings (active network RPC/LCD endpoints, fiat currency preference), and approved dApp connection permissions. Plaintext seed phrases and private keys never touch storage; only user-encrypted data blobs are retained locally on the device to maintain wallet state between sessions without external servers.

---

### 3. Motivazione per `clipboardWrite`
The "clipboardWrite" permission is strictly utilized to allow users to copy their public Bech32 wallet addresses (e.g., luxa1..., cosmos1...) and transaction hashes directly to the system clipboard with a single click. This prevents manual typing errors when transferring assets or looking up transactions on the block explorer. It is triggered solely by explicit user interaction on dedicated "Copy" buttons.

---

### 4. Motivazione per `identity`
The "identity" permission (chrome.identity.getAuthToken) is required exclusively for the optional zero-knowledge cloud backup feature. It enables users to authenticate directly with Google to securely backup and restore their client-side encrypted keystore file into their own isolated Google Drive private appDataFolder. Sensitive cryptographic credentials remain encrypted with AES-256-GCM prior to synchronization, ensuring total non-custodial privacy.

---

### 5. Motivazione per Autorizzazione host (Host permissions)
Host permissions are strictly required to interact with decentralized blockchain nodes, market data, and sync encrypted backups:
• luxaecosystem.xyz, *.luxaecosystem.xyz, ailuxa.alwaysdata.net: Official and fallback RPC/REST LCD endpoints for the luxa-1 chain to query account balances, estimate gas, and broadcast signed transactions.
• *.cosmos.directory, *.polkachu.com, *.publicnode.com: Public Cosmos RPC/REST endpoints to query multi-chain IBC asset balances across connected sovereign networks.
• raw.githubusercontent.com: Fetches verified CW20 token registry metadata, asset logos, and Cosmos Chain Registry configurations.
• api.coingecko.com, api.binance.com: Real-time price feeds for currency valuation in the wallet dashboard.
• www.googleapis.com, accounts.google.com: Authenticates and uploads user-encrypted keystores to the user's private Google Drive appDataFolder.

