// @ts-nocheck
const { DirectSecp256k1HdWallet } = require('@cosmjs/proto-signing');
const { SigningStargateClient, GasPrice } = require('@cosmjs/stargate');
const { SigningCosmWasmClient } = require('@cosmjs/cosmwasm-stargate');
const { stringToPath } = require('@cosmjs/crypto');

globalThis.CosmJS = {
  DirectSecp256k1HdWallet,
  SigningStargateClient,
  SigningCosmWasmClient,
  GasPrice,
  stringToPath
};