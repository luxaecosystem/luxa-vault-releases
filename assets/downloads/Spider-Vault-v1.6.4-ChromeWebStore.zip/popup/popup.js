
// ============================================================
// SOVEREIGN MULTI-CHAIN BECH32 CONVERTER & IBC REGISTRY
// ============================================================
const BECH32_ALPHABET = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';

function decodeBech32(address) {
  const pos = address.lastIndexOf('1');
  if (pos < 1) throw new Error('Invalid bech32');
  const prefix = address.slice(0, pos);
  const words = [];
  for (let i = pos + 1; i < address.length; i++) {
    const c = BECH32_ALPHABET.indexOf(address[i]);
    if (c === -1) throw new Error('Invalid char');
    words.push(c);
  }
  const data = words.slice(0, -6);
  return { prefix, data };
}

function bech32Polymod(values) {
  let chk = 1;
  for (let p = 0; p < values.length; ++p) {
    const top = chk >> 25;
    chk = ((chk & 0x1ffffff) << 5) ^ values[p];
    if ((top >> 0) & 1) chk ^= 0x3b6a57b2;
    if ((top >> 1) & 1) chk ^= 0x26508e6d;
    if ((top >> 2) & 1) chk ^= 0x1ea119fa;
    if ((top >> 3) & 1) chk ^= 0x3d4233dd;
    if ((top >> 4) & 1) chk ^= 0x2a1462b3;
  }
  return chk;
}

function hrpExpand(hrp) {
  const ret = [];
  for (let p = 0; p < hrp.length; ++p) ret.push(hrp.charCodeAt(p) >> 5);
  ret.push(0);
  for (let p = 0; p < hrp.length; ++p) ret.push(hrp.charCodeAt(p) & 31);
  return ret;
}

function createBech32Checksum(hrp, data) {
  const values = hrpExpand(hrp).concat(data).concat([0, 0, 0, 0, 0, 0]);
  const mod = bech32Polymod(values) ^ 1;
  const ret = [];
  for (let p = 0; p < 6; ++p) ret.push((mod >> (5 * (5 - p))) & 31);
  return ret;
}

function encodeBech32(prefix, data) {
  const combined = data.concat(createBech32Checksum(prefix, data));
  let ret = prefix + '1';
  for (let p = 0; p < combined.length; ++p) {
    ret += BECH32_ALPHABET.charAt(combined[p]);
  }
  return ret;
}

function convertCosmosAddress(address, targetPrefix) {
  try {
    if (!address || typeof address !== 'string' || !address.includes('1')) return address;
    const { data } = decodeBech32(address.trim().toLowerCase());
    return encodeBech32(targetPrefix, data);
  } catch (e) {
    return address;
  }
}

const IBC_ASSETS_MAP = {
  TIA: { chain: "Celestia", prefix: "celestia", channel: "channel-3", denom: "ibc/BF28D9C17E0306B194D50F51C3B2590BEAD15E04E03ADD34C3A26E62D85C9676", baseDenom: "utia", rest: "https://celestia-api.polkachu.com" },
  ATOM: { chain: "Cosmos Hub", prefix: "cosmos", channel: "channel-2", denom: "ibc/9117A26BA81E29FA4F78F57DC2BD90CD3D26848101BA880445F119B22A1E254E", baseDenom: "uatom", rest: "https://cosmos-rest.publicnode.com" },
  USDC: { chain: "Noble", prefix: "noble", channel: "channel-4", denom: "ibc/BFF0D3805B50D93E2FA5C0B2DDF7E0B30A631076CD80BC12A48C0E95404B4A41", baseDenom: "uusdc", rest: "https://noble-api.polkachu.com" },
  OSMO: { chain: "Osmosis", prefix: "osmo", channel: "channel-1", denom: "ibc/0471F1C4E7AFD3F07702BEF6DC365268D64570F7C1FDC98EA6098DD6DE59817B", baseDenom: "uosmo", rest: "https://osmosis-rest.publicnode.com" }
};


// ============================================================
// SOVEREIGN REAL-TIME PRICE & 24H CHANGE ORACLE (CoinGecko Live API)
// ============================================================
const LIVE_ORACLE = {
  atom:  { usd: 0, eur: 0, gbp: 0, change24h: 0, live: false, source: null },
  tia:   { usd: 0, eur: 0, gbp: 0, change24h: 0, live: false, source: null },
  osmo:  { usd: 0, eur: 0, gbp: 0, change24h: 0, live: false, source: null },
  usdc:  { usd: 1.00, eur: 0.89, gbp: 0.74, change24h: 0, live: true, source: "peg" },
  luxa:  { usd: 0, eur: 0, gbp: 0, change24h: 0, live: false, source: "pre-listing" },
  shard: { usd: 0, eur: 0, gbp: 0, change24h: 0, live: false, source: "pre-listing" },
  shards:{ usd: 0, eur: 0, gbp: 0, change24h: 0, live: false, source: "pre-listing" }
};

let lastPriceUpdate = 0;
let isPriceCached = false;

// Initialize cached oracle prices if available
try {
  chrome.storage.local.get(["cached_live_oracle"], (stored) => {
    if (stored?.cached_live_oracle?.prices) {
      const cached = stored.cached_live_oracle.prices;
      const ts = stored.cached_live_oracle.timestamp || 0;
      if (Date.now() - ts < 86400000) {
        if (cached.atom?.usd > 0) Object.assign(LIVE_ORACLE.atom, cached.atom, { live: true });
        if (cached.tia?.usd > 0) Object.assign(LIVE_ORACLE.tia, cached.tia, { live: true });
        if (cached.osmo?.usd > 0) Object.assign(LIVE_ORACLE.osmo, cached.osmo, { live: true });
        if (cached.usdc) Object.assign(LIVE_ORACLE.usdc, cached.usdc, { live: true });
        lastPriceUpdate = ts;
        isPriceCached = true;
        updatePortfolioTotalUI();
        updateOracleStatusUI();
      }
    }
  });
} catch (_) {}

function getFreshVaultBalances() {
  return {
    luxa: "0.000000",
    shards: "0",
    tia: "0.000000",
    usdc: "0.000000",
    atom: "0.000000",
    osmo: "0.000000",
    tia_ext: "0.000000",
    atom_ext: "0.000000",
    osmo_ext: "0.000000",
    usdc_ext: "0.000000"
  };
}

function getFreshMultiChainHoldings() {
  return {
    luxa_external: { celestia: "0.000000", cosmoshub: "0.000000", noble: "0.000000", osmosis: "0.000000" },
    external_natives: { tia: "0.000000", atom: "0.000000", osmo: "0.000000", usdc: "0.000000" },
    luxa_total: "0.00"
  };
}

let vaultBalances = getFreshVaultBalances();
let multiChainHoldings = getFreshMultiChainHoldings();

let priceFetchInProgress = false;

function updateOracleStatusUI() {
  const pill = document.getElementById("portfolio-oracle-status");
  if (!pill) return;

  if (lastPriceUpdate > 0) {
    const mins = Math.floor((Date.now() - lastPriceUpdate) / 60000);
    if (isPriceCached && mins > 0) {
      pill.className = "portfolio-oracle-status is-cached";
      pill.innerHTML = `<span class="pulse-dot"></span> Cached (${mins}m fa)`;
      pill.title = `Prezzi oracolo salvati in locale (${mins} min fa)`;
    } else {
      pill.className = "portfolio-oracle-status";
      pill.innerHTML = `<span class="pulse-dot"></span> Live Oracle`;
      pill.title = `Prezzi in tempo reale aggiornati`;
    }
  } else {
    pill.className = "portfolio-oracle-status is-offline";
    pill.innerHTML = `<span class="pulse-dot"></span> Prezzi non disp.`;
    pill.title = `Oracolo prezzi non raggiungibile`;
  }
}

async function fetchLiveCoinGeckoPrices() {
  if (priceFetchInProgress) return;
  priceFetchInProgress = true;
  try {
    let oracleData = null;
    let binanceData = null;

    // 1. Primary: Use background service worker proxy (bypasses CORS in Manifest V3)
    try {
      const resp = await new Promise((resolve) => {
        const timer = setTimeout(() => resolve(null), 3500);
        try {
          chrome.runtime.sendMessage({ action: "FETCH_PRICE_ORACLE" }, (r) => {
            clearTimeout(timer);
            if (chrome.runtime.lastError || !r || !r.success) {
              resolve(null);
            } else {
              resolve(r);
            }
          });
        } catch (_) {
          clearTimeout(timer);
          resolve(null);
        }
      });
      if (resp?.data) oracleData = resp.data;
      if (resp?.binanceData) binanceData = resp.binanceData;
    } catch (_) {}

    // 2. Direct fetch fallback if background was unreachable
    if (!oracleData && !binanceData) {
      try {
        const res = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=cosmos,celestia,osmosis,usd-coin&vs_currencies=usd,eur,gbp&include_24hr_change=true", {
          signal: AbortSignal.timeout(5000)
        });
        if (res.ok) {
          oracleData = await res.json();
        }
      } catch (_) {}
    }

    if (oracleData) {
      if (oracleData.cosmos && typeof oracleData.cosmos.usd === "number") {
        LIVE_ORACLE.atom.usd = oracleData.cosmos.usd;
        LIVE_ORACLE.atom.eur = oracleData.cosmos.eur || oracleData.cosmos.usd * 0.89;
        LIVE_ORACLE.atom.gbp = oracleData.cosmos.gbp || oracleData.cosmos.usd * 0.74;
        LIVE_ORACLE.atom.change24h = oracleData.cosmos.usd_24h_change || 0;
        LIVE_ORACLE.atom.live = true;
      }
      if (oracleData.celestia && typeof oracleData.celestia.usd === "number") {
        LIVE_ORACLE.tia.usd = oracleData.celestia.usd;
        LIVE_ORACLE.tia.eur = oracleData.celestia.eur || oracleData.celestia.usd * 0.89;
        LIVE_ORACLE.tia.gbp = oracleData.celestia.gbp || oracleData.celestia.usd * 0.74;
        LIVE_ORACLE.tia.change24h = oracleData.celestia.usd_24h_change || 0;
        LIVE_ORACLE.tia.live = true;
      }
      if (oracleData.osmosis && typeof oracleData.osmosis.usd === "number") {
        LIVE_ORACLE.osmo.usd = oracleData.osmosis.usd;
        LIVE_ORACLE.osmo.eur = oracleData.osmosis.eur || oracleData.osmosis.usd * 0.89;
        LIVE_ORACLE.osmo.gbp = oracleData.osmosis.gbp || oracleData.osmosis.usd * 0.74;
        LIVE_ORACLE.osmo.change24h = oracleData.osmosis.usd_24h_change || 0;
        LIVE_ORACLE.osmo.live = true;
      }
      if (oracleData["usd-coin"] && typeof oracleData["usd-coin"].usd === "number") {
        LIVE_ORACLE.usdc.usd = oracleData["usd-coin"].usd;
        LIVE_ORACLE.usdc.eur = oracleData["usd-coin"].eur || 0.89;
        LIVE_ORACLE.usdc.gbp = oracleData["usd-coin"].gbp || 0.74;
        LIVE_ORACLE.usdc.change24h = oracleData["usd-coin"].usd_24h_change || 0;
        LIVE_ORACLE.usdc.live = true;
      }
      lastPriceUpdate = Date.now();
      isPriceCached = false;
    } else if (Array.isArray(binanceData)) {
      for (const t of binanceData) {
        if (t.symbol === "ATOMUSDT") {
          const u = parseFloat(t.lastPrice || 0);
          LIVE_ORACLE.atom.usd = u;
          LIVE_ORACLE.atom.eur = u * 0.89;
          LIVE_ORACLE.atom.gbp = u * 0.74;
          LIVE_ORACLE.atom.change24h = parseFloat(t.priceChangePercent || 0);
          LIVE_ORACLE.atom.live = true;
        } else if (t.symbol === "TIAUSDT") {
          const u = parseFloat(t.lastPrice || 0);
          LIVE_ORACLE.tia.usd = u;
          LIVE_ORACLE.tia.eur = u * 0.89;
          LIVE_ORACLE.tia.gbp = u * 0.74;
          LIVE_ORACLE.tia.change24h = parseFloat(t.priceChangePercent || 0);
          LIVE_ORACLE.tia.live = true;
        } else if (t.symbol === "OSMOUSDT") {
          const u = parseFloat(t.lastPrice || 0);
          LIVE_ORACLE.osmo.usd = u;
          LIVE_ORACLE.osmo.eur = u * 0.89;
          LIVE_ORACLE.osmo.gbp = u * 0.74;
          LIVE_ORACLE.osmo.change24h = parseFloat(t.priceChangePercent || 0);
          LIVE_ORACLE.osmo.live = true;
        } else if (t.symbol === "USDCUSDT") {
          const u = parseFloat(t.lastPrice || 0);
          LIVE_ORACLE.usdc.usd = u;
          LIVE_ORACLE.usdc.eur = u * 0.89;
          LIVE_ORACLE.usdc.gbp = u * 0.74;
          LIVE_ORACLE.usdc.change24h = parseFloat(t.priceChangePercent || 0);
          LIVE_ORACLE.usdc.live = true;
        }
      }
      lastPriceUpdate = Date.now();
      isPriceCached = false;
    }

    if (lastPriceUpdate > 0 && !isPriceCached) {
      try {
        chrome.storage.local.set({
          cached_live_oracle: {
            prices: LIVE_ORACLE,
            timestamp: lastPriceUpdate
          }
        });
      } catch (_) {}
    }
  } catch (err) {
    console.warn("Live oracle price fetch error:", err);
  } finally {
    priceFetchInProgress = false;
    updateOracleStatusUI();
  }
}

function getActiveCurrency() {
  return (typeof activeCurrency === "string" ? activeCurrency : "USD").toUpperCase();
}

function getActiveCurrencySymbol() {
  const curr = getActiveCurrency();
  return (typeof CURRENCY_SYMBOLS === "object" && CURRENCY_SYMBOLS[curr]) ? CURRENCY_SYMBOLS[curr] : "$";
}

function getEstimatedPrice(symbol) {
  const s = String(symbol || "").toLowerCase();
  const curr = getActiveCurrency().toLowerCase();
  const asset = LIVE_ORACLE[s];
  if (!asset) return 0;
  if (typeof asset[curr] === "number" && asset[curr] > 0) return asset[curr];
  return asset.usd || 0;
}

function get24hChange(symbol) {
  const s = String(symbol || "").toLowerCase();
  return LIVE_ORACLE[s]?.change24h || 0;
}

function formatFiatValue(amount, symbol) {
  const s = String(symbol || "").toLowerCase();
  const oracle = LIVE_ORACLE[s];
  // If price is not live (feed down, no cache) and not usdc peg, return em dash!
  if (!oracle || (!oracle.live && s !== "usdc")) {
    return "-";
  }
  const p = getEstimatedPrice(symbol);
  const n = parseFloat(String(amount || "0").replace(/,/g, "")) || 0;
  const currSym = getActiveCurrencySymbol();
  if (n <= 0) return `${currSym}0.00`;
  const val = n * p;
  if (val <= 0) return `${currSym}0.00`;
  if (val < 0.01) return `< ${currSym}0.01`;
  return `${currSym}${val.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function formatFiatValueDirect(val) {
  const currSym = getActiveCurrencySymbol();
  if (typeof val !== "number" || isNaN(val) || val <= 0) return `${currSym}0.00`;
  if (val < 0.01) return `< ${currSym}0.01`;
  return `${currSym}${val.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function calculateTotalPortfolioUsd() {
  let total = 0;
  let hasPricedAssets = false;
  let missingLivePrice = false;

  const assets = [
    { key: "atom", ext: parseFloat(multiChainHoldings?.external_natives?.atom || 0), luxa: parseFloat(vaultBalances?.atom || 0) },
    { key: "tia", ext: parseFloat(multiChainHoldings?.external_natives?.tia || 0), luxa: parseFloat(vaultBalances?.tia || 0) },
    { key: "osmo", ext: parseFloat(multiChainHoldings?.external_natives?.osmo || 0), luxa: parseFloat(vaultBalances?.osmo || 0) },
    { key: "usdc", ext: parseFloat(multiChainHoldings?.external_natives?.usdc || 0), luxa: parseFloat(vaultBalances?.usdc || 0) }
  ];

  for (const a of assets) {
    const totalAmount = a.ext + a.luxa;
    if (totalAmount <= 0) continue;
    hasPricedAssets = true;
    const oracle = LIVE_ORACLE[a.key];
    if (!oracle?.live && a.key !== "usdc") {
      missingLivePrice = true;
    }
    const price = getEstimatedPrice(a.key);
    total += totalAmount * price;
  }

  return { total, hasPricedAssets, missingLivePrice };
}

function calculatePortfolioPnl(currentTotal) {
  if (!currentTotal || currentTotal <= 0) {
    return { pnlUsd: 0, pnlPct: 0 };
  }

  let totalDollarDelta = 0;

  const assets = [
    { key: "atom", ext: parseFloat(multiChainHoldings?.external_natives?.atom || 0), luxa: parseFloat(vaultBalances?.atom || 0) },
    { key: "tia", ext: parseFloat(multiChainHoldings?.external_natives?.tia || 0), luxa: parseFloat(vaultBalances?.tia || 0) },
    { key: "osmo", ext: parseFloat(multiChainHoldings?.external_natives?.osmo || 0), luxa: parseFloat(vaultBalances?.osmo || 0) },
    { key: "usdc", ext: parseFloat(multiChainHoldings?.external_natives?.usdc || 0), luxa: parseFloat(vaultBalances?.usdc || 0) }
  ];

  for (const a of assets) {
    const totalAmount = a.ext + a.luxa;
    if (totalAmount <= 0) continue;
    const price = getEstimatedPrice(a.key);
    const changePct = get24hChange(a.key);
    const assetUsd = totalAmount * price;

    if (changePct !== 0 && assetUsd > 0) {
      const prevAssetUsd = assetUsd / (1 + changePct / 100);
      totalDollarDelta += (assetUsd - prevAssetUsd);
    }
  }

  const prevTotal = currentTotal - totalDollarDelta;
  const portfolioPct = prevTotal > 0 ? (totalDollarDelta / prevTotal) * 100 : 0;

  return {
    pnlUsd: totalDollarDelta,
    pnlPct: portfolioPct
  };
}

function updatePortfolioTotalUI() {
  const { total: totalUsd, hasPricedAssets, missingLivePrice } = calculateTotalPortfolioUsd();
  const totalEl = document.getElementById("main-portfolio-total-usd");
  const currSym = getActiveCurrencySymbol();
  if (totalEl) {
    if (missingLivePrice && totalUsd === 0) {
      totalEl.textContent = "-";
      totalEl.title = "Oracle prices unavailable";
    } else {
      totalEl.textContent = formatFiatValueDirect(totalUsd);
      totalEl.title = `Total Portfolio Value: ${currSym}${totalUsd.toFixed(4)}`;
    }
  }

  const pnlEl = document.getElementById("portfolio-pnl-value");
  if (pnlEl) {
    if (missingLivePrice && totalUsd === 0) {
      pnlEl.className = "portfolio-pnl-value pnl-neutral";
      pnlEl.textContent = "-";
    } else {
      const { pnlUsd, pnlPct } = calculatePortfolioPnl(totalUsd);
      if (pnlPct > 0.001) {
        pnlEl.className = "portfolio-pnl-value pnl-up";
        const sign = pnlUsd >= 0 ? "+" : "";
        pnlEl.textContent = `${sign}${currSym}${pnlUsd.toFixed(2)} (+${pnlPct.toFixed(2)}%)`;
      } else if (pnlPct < -0.001) {
        pnlEl.className = "portfolio-pnl-value pnl-down";
        pnlEl.textContent = `-${currSym}${Math.abs(pnlUsd).toFixed(2)} (-${Math.abs(pnlPct).toFixed(2)}%)`;
      } else {
        pnlEl.className = "portfolio-pnl-value pnl-neutral";
        pnlEl.textContent = `+${currSym}0.00 (+0.00%)`;
      }
    }
  }

  const nativeLuxa = parseFloat(vaultBalances?.luxa || 0);
  const extCosmos = parseFloat(multiChainHoldings?.luxa_external?.cosmoshub || 0);
  const extCelestia = parseFloat(multiChainHoldings?.luxa_external?.celestia || 0);
  const extOsmosis = parseFloat(multiChainHoldings?.luxa_external?.osmosis || 0);
  const extNoble = parseFloat(multiChainHoldings?.luxa_external?.noble || 0);
  const ibcLuxaTotal = extCosmos + extCelestia + extOsmosis + extNoble;
  const totalLuxaVal = nativeLuxa + ibcLuxaTotal;
  const hasIbcLuxa = ibcLuxaTotal > 0.000001;

  const luxaSubEl = document.getElementById("main-luxa-balance");
  if (luxaSubEl) {
    if (hasIbcLuxa) {
      luxaSubEl.textContent = `${totalLuxaVal.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} LUXA (Total)`;
      luxaSubEl.title = `Total: ${totalLuxaVal.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} LUXA (${nativeLuxa.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} on LUXA Network + ${ibcLuxaTotal.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} on IBC)`;
    } else {
      luxaSubEl.textContent = `${nativeLuxa.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} LUXA on LUXA Network`;
      luxaSubEl.title = `${nativeLuxa.toLocaleString("en-US")} LUXA on LUXA Network`;
    }
  }

  const detailRow = document.getElementById("main-native-detail-row");
  const nativeDetailEl = document.getElementById("main-luxa-native-detail");
  const ibcDetailEl = document.getElementById("main-luxa-ibc-detail");
  if (detailRow && nativeDetailEl && ibcDetailEl) {
    if (hasIbcLuxa) {
      detailRow.style.display = "flex";
      nativeDetailEl.textContent = `${nativeLuxa.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} on LUXA Network`;
      ibcDetailEl.textContent = `${ibcLuxaTotal.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} on IBC`;
    } else {
      detailRow.style.display = "none";
    }
  }

  updateOnchainMetricsUI();
  updateOracleStatusUI();
}

function updateOnchainMetricsUI() {
  const rawMicroEl = document.getElementById("onchain-raw-micro");
  if (rawMicroEl) {
    const luxaNum = parseFloat(vaultBalances?.luxa || 0);
    const microUnits = Math.round(luxaNum * 1000000);
    rawMicroEl.textContent = microUnits.toLocaleString("en-US");
    rawMicroEl.title = `${microUnits} uluxa on LUXA Network`;
  }

  const shardsValEl = document.getElementById("onchain-shards-val");
  if (shardsValEl) {
    const shardNum = parseFloat(vaultBalances?.shards || 0);
    shardsValEl.textContent = shardNum.toLocaleString("en-US", {
      minimumFractionDigits: shardNum % 1 === 0 ? 0 : 2,
      maximumFractionDigits: 2
    });
    shardsValEl.title = `${shardNum.toLocaleString("en-US")} SHARD on LUXA Network`;
  }

  const poolsEl = document.getElementById("metric-active-pools");
  if (poolsEl) {
    poolsEl.textContent = "4 Active Pools (LDEX)";
  }
}

function createChevronIcon() {
  const span = document.createElement("span");
  span.className = "mm-accordion-chevron";
  span.innerHTML = `<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block; vertical-align:middle;"><polyline points="6 9 12 15 18 9"></polyline></svg>`;
  return span;
}

function createPerfBadge(symbol) {
  const s = String(symbol || "").toLowerCase();
  const oracle = LIVE_ORACLE[s];
  const badge = document.createElement("span");
  badge.className = "mm-token-perf";

  if (!oracle || (!oracle.live && s !== "usdc")) {
    badge.className = "mm-token-perf perf-neutral";
    badge.textContent = "-";
    return badge;
  }

  const change = get24hChange(symbol);
  if (change > 0.001) {
    badge.className = "mm-token-perf perf-up";
    badge.innerHTML = `<svg width="7" height="7" viewBox="0 0 24 24" fill="currentColor" style="display:inline-block; vertical-align:middle; margin-right:2px;"><path d="M12 4l-8 8h16z"/></svg>${change.toFixed(2)}%`;
  } else if (change < -0.001) {
    badge.className = "mm-token-perf perf-down";
    badge.innerHTML = `<svg width="7" height="7" viewBox="0 0 24 24" fill="currentColor" style="display:inline-block; vertical-align:middle; margin-right:2px;"><path d="M12 20l-8-8h16z"/></svg>${Math.abs(change).toFixed(2)}%`;
  } else {
    badge.className = "mm-token-perf perf-neutral";
    badge.textContent = "0.00%";
  }
  return badge;
}

// popup/popup.js ? Spider's Nest Sovereign Controller (100% Interconnected & Cloud-Ready)

const BACKEND_API = "https://luxaecosystem.alwaysdata.net/api";



const RPC_ENDPOINT = "https://rpc.luxaecosystem.xyz";



const DEX_STUDIO_URL = "https://studio.luxaecosystem.xyz";



const PBKDF2_ITERATIONS = 210000;







function formatCompactNumber(val, decimals = 2) {



  const num = typeof val === "string" ? parseFloat(val) : val;



  if (!Number.isFinite(num) || num === 0) return "0.00";



  if (num >= 1e9) return `${(num / 1e9).toFixed(decimals)} B`;



  if (num >= 1e6) return `${(num / 1e6).toFixed(decimals)} M`;



  if (num >= 1e4) return `${(num / 1e3).toFixed(decimals)} K`;



  return num.toLocaleString("en-US", {



    minimumFractionDigits: 2,



    maximumFractionDigits: 4



  });



}







const CURRENCY_SYMBOLS = {



  USD: "$", EUR: "€", GBP: "£", JPY: "¥",



  CHF: "₣", BTC: "₿", ETH: "Ξ"



};







const RARITY_ACCENTS = {



  mythic: "#FFD700",



  legendary: "#F59E0B",



  epic: "#A855F7",



  rare: "#00FFCC",



  standard: "#38BDF8"



};







// --- CACHE DINAMICA REGISTRO ARTEFATTI ---



let _cachedRegistry = null;



async function fetchLiveNftRegistry() {



  if (_cachedRegistry) return _cachedRegistry;



  try {



    let res = await fetch("https://luxaecosystem.alwaysdata.net/nftlist.json", { cache: "no-cache" });



    if (!res.ok) res = await fetch("https://luxaecosystem.xyz/nftlist.json", { cache: "no-cache" });



    if (res.ok) {



      const doc = await res.json();



      if (Array.isArray(doc.nfts)) {



        _cachedRegistry = {};



        doc.nfts.forEach((item) => {



          const cleanId = String(item.id).replace(/[^0-9]/g, "");



          _cachedRegistry[cleanId] = item;



        });



        return _cachedRegistry;



      }



    }



  } catch (err) {



  console.warn("[LUXA Vault] Unable to retrieve remote nftlist.json:", err);



  }



  return _cachedRegistry || {};



}







function broadcastVaultState(action, address = null, origin = null) {



  try {



    chrome.runtime.sendMessage({ action, address, origin }, () => {



      if (chrome.runtime.lastError) {}



    });



  } catch (_) {}



}







// --- CRITTOGRAFIA LOCALE AES-GCM + PBKDF2 ---



function bytesToHex(bytes) {



  return Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("");



}







function hexToBytes(hex) {



  const cleanHex = hex.replace(/^0x/i, "");



  return new Uint8Array(cleanHex.match(/.{1,2}/g).map(b => parseInt(b, 16)));



}







async function deriveKeyFromPin(pin, salt) {



  const encoder = new TextEncoder();



  const baseKey = await crypto.subtle.importKey("raw", encoder.encode(pin), "PBKDF2", false, ["deriveKey"]);



  return crypto.subtle.deriveKey(



    { name: "PBKDF2", salt, iterations: PBKDF2_ITERATIONS, hash: "SHA-256" },



    baseKey,



    { name: "AES-GCM", length: 256 },



    false,



    ["encrypt", "decrypt"]



  );



}







async function encryptMnemonic(mnemonic, pin) {



  const salt = crypto.getRandomValues(new Uint8Array(16));



  const iv = crypto.getRandomValues(new Uint8Array(12));



  const key = await deriveKeyFromPin(pin, salt);



  const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(mnemonic));



  return {



    version: 2,



    salt: bytesToHex(salt),



    iv: bytesToHex(iv),



    ciphertext: bytesToHex(new Uint8Array(encrypted))



  };



}







async function decryptMnemonic(encrypted, pin) {



  try {



    const salt = hexToBytes(encrypted.salt);



    const iv = hexToBytes(encrypted.iv);



    const ciphertext = hexToBytes(encrypted.ciphertext);



    const key = await deriveKeyFromPin(pin, salt);



    const decrypted = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, ciphertext);



    return new TextDecoder().decode(decrypted);



  } catch (_) {



    throw new Error("Incorrect PIN. Decryption failed.");



  }



}







// --- MODAL & TOAST UI ENGINE ---



const LuxaUI = {



  _toastTimer: null,



  toast: function (msg, icon = "⚡", duration = 2400) {



    const toast = document.getElementById("luxa-toast");



    const tIcon = document.getElementById("toast-icon");



    const tMsg = document.getElementById("toast-msg");



    if (!toast) return;



    tIcon.textContent = icon;



    tMsg.textContent = msg;



    toast.style.display = "flex";



    clearTimeout(this._toastTimer);



    this._toastTimer = setTimeout(() => { toast.style.display = "none"; }, duration);



  },







  alert: function ({ title, desc, icon = "ℹ️", btnText = "Close" }) {



    return new Promise((resolve) => {



      const overlay = document.getElementById("luxa-modal-overlay");



      const mIcon = document.getElementById("modal-icon");



      const mTitle = document.getElementById("modal-title");



      const mDesc = document.getElementById("modal-desc");



      const inputWrap = document.getElementById("modal-input-wrap");



      const btnCancel = document.getElementById("btn-modal-cancel");



      const btnConfirm = document.getElementById("btn-modal-confirm");







      mIcon.textContent = icon;



      mTitle.textContent = title;



      mDesc.innerHTML = desc;



      inputWrap.style.display = "none";



      btnCancel.style.display = "none";



      btnConfirm.textContent = btnText;



      overlay.style.display = "flex";







      btnConfirm.onclick = () => { overlay.style.display = "none"; resolve(true); };



    });



  },







  confirm: function ({ title, desc, icon = "⚠️", confirmText = "Confirm", cancelText = "Cancel" }) {



    return new Promise((resolve) => {



      const overlay = document.getElementById("luxa-modal-overlay");



      const mIcon = document.getElementById("modal-icon");



      const mTitle = document.getElementById("modal-title");



      const mDesc = document.getElementById("modal-desc");



      const inputWrap = document.getElementById("modal-input-wrap");



      const btnCancel = document.getElementById("btn-modal-cancel");



      const btnConfirm = document.getElementById("btn-modal-confirm");







      mIcon.textContent = icon;



      mTitle.textContent = title;



      mDesc.innerHTML = desc;



      inputWrap.style.display = "none";



      btnCancel.style.display = "block";



      btnCancel.textContent = cancelText;



      btnConfirm.textContent = confirmText;



      overlay.style.display = "flex";







      btnConfirm.onclick = () => { overlay.style.display = "none"; resolve(true); };



      btnCancel.onclick = () => { overlay.style.display = "none"; resolve(false); };



    });



  },







  prompt: function ({ title, desc, placeholder = "", icon = "🔑", isPassword = false, defaultValue = "", rows = 2 }) {



    return new Promise((resolve) => {



      const overlay = document.getElementById("luxa-modal-overlay");



      const mIcon = document.getElementById("modal-icon");



      const mTitle = document.getElementById("modal-title");



      const mDesc = document.getElementById("modal-desc");



      const inputWrap = document.getElementById("modal-input-wrap");



      const input = document.getElementById("modal-input");



      const btnCancel = document.getElementById("btn-modal-cancel");



      const btnConfirm = document.getElementById("btn-modal-confirm");







      mIcon.textContent = icon;



      mTitle.textContent = title;



      mDesc.innerHTML = desc;



      inputWrap.style.display = "block";



      input.value = defaultValue;



      input.placeholder = placeholder;



      input.rows = rows;



      input.style.webkitTextSecurity = isPassword ? "disc" : "none";







      btnCancel.style.display = "block";



      btnCancel.textContent = "Cancel";



      btnConfirm.textContent = "Continue";



      overlay.style.display = "flex";







      setTimeout(() => input.focus(), 60);







      const handleEnter = (e) => {



        if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); btnConfirm.click(); }



      };



      input.onkeydown = handleEnter;







      btnConfirm.onclick = () => {



        const val = input.value.trim();



        input.onkeydown = null;



        overlay.style.display = "none";



        resolve(val);



      };



      btnCancel.onclick = () => {



        input.onkeydown = null;



        overlay.style.display = "none";



        resolve(null);



      };



    });



  }



};







// --- GOOGLE IDENTITY & ZERO-KNOWLEDGE DRIVE ENGINE ---



const GoogleDriveEngine = {



  getAuthToken: function (interactive = true) {



    return new Promise((resolve, reject) => {



      if (!chrome.identity || !chrome.identity.getAuthToken) {



        return reject(new Error("The chrome.identity API is not enabled in the manifest."));



      }



      chrome.identity.getAuthToken({ interactive }, (token) => {



        if (chrome.runtime.lastError || !token) {



          const message = chrome.runtime.lastError?.message || "Google authentication was cancelled.";



          if (message.toLowerCase().includes("bad client id")) {



            return reject(new Error("The OAuth2 client is not valid for this extension. In Google Cloud, create a Chrome Extension client using the ID from chrome://extensions, then replace oauth2.client_id in the manifest and reload the extension."));



          }



          return reject(new Error(message));



        }



        resolve(token);



      });



    });



  },







  getUserProfile: async function (token) {



    if (token && typeof token === "string" && token.split(".").length === 3) {



      try {



        const payloadBase64 = token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");



        const jsonPayload = decodeURIComponent(



          atob(payloadBase64)



            .split("")



            .map((c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2))



            .join("")



        );



        const parsed = JSON.parse(jsonPayload);



        if (parsed.email || parsed.name) {



          return {



            email: parsed.email || "",



            name: parsed.name || parsed.email || "Google User",



            picture: parsed.picture || ""



          };



        }



      } catch (e) {



        console.warn("JWT payload decode error:", e);



      }



    }







    const stored = await new Promise((resolve) => {



      chrome.storage.local.get(["google_account"], resolve);



    });



    if (stored?.google_account?.email) {



      return stored.google_account;



    }







    const res = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {



      headers: { Authorization: `Bearer ${token}` }



    });



    if (!res.ok) throw new Error("Unable to retrieve the Google profile.");



    return res.json();



  },







  findBackupFile: async function (token) {



    const q = encodeURIComponent("name = 'luxa_vault_backup.json' and trashed = false");



    const res = await fetch(`https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=${q}&fields=files(id,name,modifiedTime)`, {



      headers: { Authorization: `Bearer ${token}` }



    });



    const data = await res.json();



    return data.files && data.files.length > 0 ? data.files[0] : null;



  },







  uploadBackup: async function (token, vaultsData) {



    const existingFile = await this.findBackupFile(token);



    const backupContent = JSON.stringify({



      version: 2,



      timestamp: new Date().toISOString(),



      vaults: vaultsData



    });







    const metadata = {



      name: "luxa_vault_backup.json",



      mimeType: "application/json",



      parents: existingFile ? undefined : ["appDataFolder"]



    };







    const boundary = "-------LuxaVaultBoundary" + Math.random().toString(36).slice(2);



    const delimiter = `\r\n--${boundary}\r\n`;



    const closeDelim = `\r\n--${boundary}--`;







    const multipartBody =



      delimiter +



      "Content-Type: application/json; charset=UTF-8\r\n\r\n" +



      JSON.stringify(metadata) +



      delimiter +



      "Content-Type: application/json\r\n\r\n" +



      backupContent +



      closeDelim;







    const url = existingFile



      ? `https://www.googleapis.com/upload/drive/v3/files/${existingFile.id}?uploadType=multipart`



      : "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart";







    const res = await fetch(url, {



      method: existingFile ? "PATCH" : "POST",



      headers: {



        Authorization: `Bearer ${token}`,



        "Content-Type": `multipart/related; boundary=${boundary}`



      },



      body: multipartBody



    });







    if (!res.ok) throw new Error("Google Drive upload failed.");



    return res.json();



  },







  downloadBackup: async function (token) {



    const file = await this.findBackupFile(token);



    if (!file) throw new Error("No backup was found on Google Drive for this account.");







    const res = await fetch(`https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`, {



      headers: { Authorization: `Bearer ${token}` }



    });



    if (!res.ok) throw new Error("Unable to download data from Google Drive.");



    const data = await res.json();



    return { data, modifiedTime: file.modifiedTime };



  }



};







// --- CONTROLLER PRINCIPALE ---



document.addEventListener("DOMContentLoaded", async () => {



  function syncAppVersion() {



    let v = window.__LUXA_APP_VERSION__ || "1.6.4";



    try {



      if (typeof chrome !== "undefined" && chrome.runtime && typeof chrome.runtime.getManifest === "function") {



        const manifest = chrome.runtime.getManifest();



        if (manifest && manifest.version) {



          v = manifest.version;



        }



      }



    } catch (e) {}



    const displayVer = v.startsWith("v") ? v : ("v" + v);



    document.querySelectorAll(".app-version-display, #app-version-value").forEach((el) => {



      el.textContent = displayVer;



    });



  }



  syncAppVersion();







  const popupLoading = document.getElementById("popup-loading");



  const viewNoWallet = document.getElementById("view-no-wallet");



  const viewUnlock = document.getElementById("view-unlock");



  const viewApproveConnect = document.getElementById("view-approve-connect");



  const viewDashboard = document.getElementById("view-dashboard");



  const viewTokenDetail = document.getElementById("view-token-detail");



  const viewSend = document.getElementById("view-send");



  const viewInAppSwap = document.getElementById("view-inapp-swap");



  const viewNfts = document.getElementById("view-nfts");



  const viewSettings = document.getElementById("view-settings");



  const vaultTopBar = document.getElementById("vault-topbar");



  const walletSelector = document.getElementById("wallet-selector");



  const unlockPinInput = document.getElementById("unlock-pin");



  const unlockError = document.getElementById("unlock-error");



  const unlockWalletLabel = document.getElementById("unlock-wallet-label");







  let vaults = [];



  let activeIndex = 0;



  let activeCurrency = "USD";



  let currentSelectedToken = "luxa";
  let currentSelectedChain = "LUXA Network";



  let pendingSendToken = null;



  vaultBalances = { luxa: "0.000000", shards: "0", tia: "0.0000", usdc: "0.00", atom: "0.0000", osmo: "0.0000" };



  let swapIsAtoB = true;



  let livePoolState = { reserveA: 0, reserveB: 0, lastUpdated: 0 };



  let quoteRequestId = 0;



  let swapNetworkAllowed = false;



  const AMM_PAIR_CONTRACT = "luxa14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9smu4c28";



  const LIVE_COSMOS_REST = "https://api.luxaecosystem.xyz";



  const LIVE_POOL_API = `${BACKEND_API}/pool/reserves`;



  const LUXA_LOGO_URL = "https://luxaecosystem.alwaysdata.net/assets/128.png";



  const SHARDS_LOGO_URL = "https://luxaecosystem.alwaysdata.net/assets/shard128.png";



  const OFFICIAL_TOKEN_REGISTRY_URL = "https://raw.githubusercontent.com/luxaecosystem/luxa-token-registry/main/tokens.json";



  let officialTokenRegistry = null;



  let officialTokenRegistryRequest = null;



  const customTokenLogoRequests = new Map();



  const SWAP_NETWORK_FEE = 0.007;







  const btnTestnet = document.getElementById("btn-toggle-testnet");



  const btnMainnet = document.getElementById("btn-toggle-mainnet");



  const netDot = document.getElementById("net-status-dot");



  const netLabel = document.getElementById("net-status-label");



  const bannerTestnet = document.getElementById("vault-testnet-banner");



  const btnFaucet = document.getElementById("btn-vault-faucet");



  const networkToggleStrip = document.getElementById("network-toggle-strip");







  function updateNetworkUI(network) {



    const isTestnet = network === "testnet";



    if (btnTestnet && btnMainnet) {



      btnTestnet.classList.toggle("active", isTestnet);



      btnMainnet.classList.toggle("active", !isTestnet);



    }



    if (netDot) netDot.className = isTestnet ? "net-status-dot testnet" : "net-status-dot";



    if (netLabel) netLabel.textContent = isTestnet ? "Testnet (luxa-testnet)" : "Mainnet (luxa-1)";



    const isAppUnlocked = viewDashboard && viewDashboard.style.display !== "none";



    if (bannerTestnet) bannerTestnet.style.display = (isTestnet && isAppUnlocked) ? "flex" : "none";



    if (btnFaucet) btnFaucet.style.display = isTestnet ? "inline-flex" : "none";



  }







  async function renderNetworkMetrics(isTestnet) {



    const testnetBox = document.getElementById("metrics-testnet-box");



    const mainnetBox = document.getElementById("metrics-mainnet-box");



    const networkBadge = document.getElementById("metrics-network-badge");



    const metricsTitle = document.getElementById("metrics-card-title");



    const blockHeightEl = document.getElementById("metric-block-height");



    if (!testnetBox || !mainnetBox || !networkBadge) return;







    if (isTestnet) {



      testnetBox.style.display = "block";



      mainnetBox.style.display = "none";



      networkBadge.textContent = "TESTNET";



      networkBadge.style.borderColor = "#f59e0b";



      networkBadge.style.color = "#f59e0b";



      if (metricsTitle) metricsTitle.textContent = "Sandbox Ledger Status";



      return;



    }







    testnetBox.style.display = "none";



    mainnetBox.style.display = "block";



    networkBadge.textContent = "L1 LIVE";



    networkBadge.style.borderColor = "#00FFCC";



    networkBadge.style.color = "#00FFCC";



    if (metricsTitle) metricsTitle.textContent = "Real On-Chain Metrics";



    if (blockHeightEl) blockHeightEl.textContent = "Syncing...";







    try {



      const response = await fetch(`${RPC_ENDPOINT}/status`, { cache: "no-store" });



      if (!response.ok) throw new Error("RPC status request failed");



      const payload = await response.json();



      const latestHeight = payload?.result?.sync_info?.latest_block_height;



      if (blockHeightEl) {



        blockHeightEl.textContent = latestHeight



          ? `#${Number(latestHeight).toLocaleString()}`



          : "Online";



      }



    } catch (_) {



      if (blockHeightEl) blockHeightEl.textContent = "RPC Syncing...";



    }



  }







  if (btnTestnet && btnMainnet) {



    btnTestnet.onclick = () => {



      chrome.storage.local.set({ active_network: "testnet" }, () => {



        updateNetworkUI("testnet");



        LuxaUI.toast("Network set to TESTNET SANDBOX 🟡", "⚡");



        showDashboard();



      });



    };







    btnMainnet.onclick = () => {



      chrome.storage.local.set({ active_network: "mainnet" }, () => {



        updateNetworkUI("mainnet");



        LuxaUI.toast("Network set to MAINNET luxa-1 🟢", "⚡");



        showDashboard();



      });



    };



  }







  if (btnFaucet) {



    btnFaucet.onclick = async () => {



      const cur = vaults[activeIndex];



      if (!cur?.address) return;







      btnFaucet.disabled = true;



      btnFaucet.textContent = "Request in progress...";







      try {



        const res = await fetch(`${BACKEND_API}/testnet/faucet`, {



          method: "POST",



          headers: { "Content-Type": "application/json" },



          body: JSON.stringify({ address: cur.address })



        });



        const data = await res.json();



        if (!data.success) throw new Error(data.error || "Faucet error");







        LuxaUI.toast(`+${data.creditedLuxa} tLUXA received! 🎉`, "🚰");



        showDashboard();



      } catch (err) {



        LuxaUI.alert({ title: "Faucet error", desc: err.message, icon: "❌" });



      } finally {



        btnFaucet.disabled = false;



        btnFaucet.textContent = "Request Faucet (+50)";



      }



    };



  }







  chrome.storage.local.get(["active_network"], (data) => {



    const activeNetwork = data.active_network || "testnet";



    if (!data.active_network) {



      chrome.storage.local.set({ active_network: activeNetwork });



    }



    updateNetworkUI(activeNetwork);



  });







  // --- EXTERNAL DAPP CONNECTION REQUEST HANDLING ---



  function getQueryParam(name) {



    return new URLSearchParams(window.location.search).get(name);



  }







  function showApproveConnectScreen(origin, address) {



    hideAllViews();



    if (vaultTopBar) vaultTopBar.style.display = "none";



    const originEl = document.getElementById("auth-req-origin");



    const addressEl = document.getElementById("auth-req-address");



    const originLabel = document.getElementById("auth-scope-origin-label");



    const radioEcosystem = document.getElementById("auth-scope-ecosystem");



    const radioSingle = document.getElementById("auth-scope-single");







    if (originEl) originEl.textContent = origin || "";



    if (addressEl) addressEl.textContent = address || "luxa1...";



    if (originLabel) originLabel.textContent = origin || "this site";







    // Auto-select Ecosystem White Card for luxaecosystem.xyz domains or local dev



    let isEcosystemOrigin = false;



    try {



      if (origin) {



        const u = new URL(origin);



        if (u.hostname === "luxaecosystem.xyz" || u.hostname.endsWith(".luxaecosystem.xyz") || u.hostname === "localhost" || u.hostname === "127.0.0.1") {



          isEcosystemOrigin = true;



        }



      }



    } catch (_) {}







    if (radioEcosystem && radioSingle) {



      if (isEcosystemOrigin) {



        radioEcosystem.checked = true;



      } else {



        radioSingle.checked = true;



      }



    }







    if (viewApproveConnect) viewApproveConnect.style.display = "flex";



  }







  function escapeHtml(value) {



    return String(value ?? "").replace(/[&<>"']/g, (char) => ({



      "&": "&amp;",



      "<": "&lt;",



      ">": "&gt;",



      '"': "&quot;",



      "'": "&#39;"



    })[char]);



  }







  function showSignRequestScreen(txData) {



    hideAllViews();



    if (vaultTopBar) vaultTopBar.style.display = "none";







    const tx = txData?.tx || txData;



    const messages = tx?.messages || txData?.messages || [];



    const txValue = txData?.tx?.value || txData;



    const firstMessage = messages[0];



    const firstMessageValue = firstMessage?.value || {};



    const origin = txData?.origin || "Unknown site";



    const contract = txValue?.contract || txValue?.contractAddress || "luxa14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9smu4c28";



    let fundsDisplay = "0 LUXA";



    if (Array.isArray(txValue?.funds) && txValue.funds.length > 0) {



      const fund = txValue.funds[0];



      const amount = Number(fund.amount || 0) / 1000000;



      const denom = fund.denom === "uluxa" ? "LUXA" : "SHARD";



      fundsDisplay = `${amount} ${denom}`;



    }







    const isInstantiate = txData?.action === "INSTANTIATE_WASM_CONTRACT" || Boolean(txValue?.codeId && !txValue?.contractAddress);



    const isUpload = txData?.action === "UPLOAD_WASM_CONTRACT" || Boolean(txValue?.wasmByteCode);



    const isStaking = Array.isArray(messages) && messages.some(m => m?.typeUrl?.includes("staking") || m?.typeUrl?.includes("distribution"));







    let opTitle = isUpload



      ? "Store WASM Bytecode (CW20 Base)"



      : isInstantiate



      ? `Deploy Contract (Code #${txValue?.codeId || "2"})`



      : "Execute Smart Contract (DEX AMM)";



    let destLabel = isUpload



      ? "STORE CW20 BASE CODE"



      : isInstantiate



      ? `LABEL: ${txValue?.label || "Token"}`



      : contract;



    let btnLabel = isUpload



      ? "Sign & Store Code"



      : isInstantiate



      ? "Sign & Deploy to luxa-1"



      : "Sign & Confirm Transaction";







    if (firstMessage?.typeUrl === "/cosmos.bank.v1beta1.MsgSend") {



      const coin = firstMessageValue.amount?.[0];



      const symbol = coin?.denom === "uluxa" ? "LUXA" : coin?.denom === "ushard" ? "SHARD" : coin?.denom || "";



      fundsDisplay = `${Number(coin?.amount || 0) / 1000000} ${symbol}`;



      opTitle = "Send tokens";



      destLabel = `Recipient: ${firstMessageValue.toAddress || "unknown"}`;



      btnLabel = "Approve & Send";



    } else if (firstMessage?.typeUrl === "/cosmos.gov.v1.MsgVote") {



      const voteNames = { 1: "Yes", 2: "Abstain", 3: "No", 4: "No with veto" };



      opTitle = "Vote on governance proposal";



      destLabel = `Proposal #${firstMessageValue.proposalId || "?"} · ${voteNames[firstMessageValue.option] || "Unknown vote"}`;



      fundsDisplay = "No funds transferred";



      btnLabel = "Approve Vote";



    } else if (firstMessage?.typeUrl === "/cosmos.gov.v1.MsgDeposit") {



      const coin = firstMessageValue.amount?.[0];



      const symbol = coin?.denom === "uluxa" ? "LUXA" : coin?.denom === "ushard" ? "SHARD" : coin?.denom || "";



      fundsDisplay = `${Number(coin?.amount || 0) / 1000000} ${symbol}`;



      opTitle = "Deposit to governance proposal";



      destLabel = `Proposal #${firstMessageValue.proposalId || "?"}`;



      btnLabel = "Approve Deposit";



    } else if (firstMessage?.typeUrl === "/cosmos.distribution.v1beta1.MsgWithdrawValidatorCommission") {



      opTitle = "Withdraw validator commission";



      destLabel = `Validator: ${firstMessageValue.validatorAddress || "unknown"}`;



      fundsDisplay = "Accrued commission";



      btnLabel = "Approve Commission Withdrawal";



    }







    if (isStaking && messages.length > 0) {



      const m0 = messages[0];



      if (m0?.typeUrl === "/cosmos.staking.v1beta1.MsgDelegate") {



        opTitle = "Delegate LUXA (Staking)";



        const val = m0.value;



        const amt = Number(val?.amount?.amount || 0) / 1000000;



        fundsDisplay = `${amt} LUXA`;



        destLabel = `Validator: ${val?.validatorAddress || ""}`;



        btnLabel = "Sign & Stake LUXA";



      } else if (m0?.typeUrl === "/cosmos.staking.v1beta1.MsgUndelegate") {



        opTitle = "Unbond LUXA (Staking)";



        const val = m0.value;



        const amt = Number(val?.amount?.amount || 0) / 1000000;



        fundsDisplay = `${amt} LUXA`;



        destLabel = `Validator: ${val?.validatorAddress || ""}`;



        btnLabel = "Sign & Unbond LUXA";



      } else if (m0?.typeUrl === "/cosmos.distribution.v1beta1.MsgWithdrawDelegatorReward") {



        const includesCommission = messages.some(m => m?.typeUrl === "/cosmos.distribution.v1beta1.MsgWithdrawValidatorCommission");



        opTitle = includesCommission ? "Claim rewards and validator commission" : "Claim Staking Rewards";



        destLabel = messages.length > 1 ? `Claim from ${messages.length} Validators` : `Validator: ${m0.value?.validatorAddress || ""}`;



        fundsDisplay = includesCommission ? "Accrued rewards and commission" : "Accrued Rewards";



        btnLabel = includesCommission ? "Approve Withdrawals" : "Sign & Claim Rewards";



      } else if (m0?.typeUrl === "/cosmos.distribution.v1beta1.MsgWithdrawValidatorCommission") {



        opTitle = "Withdraw validator commission";



        destLabel = `Validator: ${m0.value?.validatorAddress || ""}`;



        fundsDisplay = "Accrued commission";



        btnLabel = "Approve Commission Withdrawal";



      }



    }







    document.body.innerHTML = `



      <div style="padding: 24px 20px; font-family: sans-serif; background: #070913; color: #fff; min-height: 100vh; display: flex; flex-direction: column; justify-content: space-between;">



        <div>



          <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 20px;">



            <img src="../icons/LUX_Vault.svg" style="width: 28px; height: 28px;" />



            <span style="font-weight: bold; color: #00FFCC; font-size: 16px;">LUXA Sovereign Vault</span>



          </div>



          <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(0,255,204,0.2); border-radius: 12px; padding: 14px; margin-bottom: 16px;">



            <div style="font-size: 11px; color: #88a0bf; margin-bottom: 4px;">OPERATION</div>



            <div style="font-size: 14px; font-weight: bold; color: #fff;">${escapeHtml(opTitle)}</div>



            <div style="font-size: 11px; color: #88a0bf; margin-top: 10px; margin-bottom: 4px;">AMOUNT / FUNDS</div>



            <div style="font-size: 16px; font-weight: bold; color: #00FFCC;">${escapeHtml(fundsDisplay)}</div>



            <div style="font-size: 11px; color: #88a0bf; margin-top: 10px; margin-bottom: 2px;">DESTINATION / DETAILS</div>



            <div style="font-family: monospace; font-size: 10px; color: #cbd5e1; word-break: break-all;">${escapeHtml(destLabel)}</div>



            <div style="font-size: 11px; color: #88a0bf; margin-top: 8px; word-break: break-all;">REQUESTED BY: <span style="color:#cbd5e1;">${escapeHtml(origin)}</span></div>



            <div style="font-size: 11px; color: #88a0bf; margin-top: 8px;">ESTIMATED GAS: <span style="color:#f59e0b;">${isUpload ? "0.015 LUXA" : "0.008 LUXA"}</span></div>



          </div>



          <div style="margin-bottom: 16px;">



            <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Enter your Vault PIN to authorize:</label>



            <input id="tx-pin-input" type="password" placeholder="4-digit PIN" style="width: 100%; box-sizing: border-box; background: #0c101d; border: 1px solid #1e293b; color: #fff; padding: 12px; border-radius: 8px; font-size: 16px; letter-spacing: 4px; text-align: center; outline: none;" />



            <div id="tx-pin-error" style="color: #ef4444; font-size: 11px; margin-top: 6px; display: none;"></div>



          </div>



        </div>



        <div style="display: flex; gap: 10px;">



          <button id="btn-reject-tx" style="flex: 1; padding: 12px; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); color: #fff; border-radius: 8px; cursor: pointer; font-weight: 600;">Reject</button>



          <button id="btn-confirm-tx" style="flex: 2; padding: 12px; background: #00FFCC; border: none; color: #070913; border-radius: 8px; cursor: pointer; font-weight: bold;">${btnLabel}</button>



        </div>



      </div>



    `;







    const pinInput = document.getElementById("tx-pin-input");



    const pinErr = document.getElementById("tx-pin-error");



    const btnConfirm = document.getElementById("btn-confirm-tx");



    const btnReject = document.getElementById("btn-reject-tx");



    setTimeout(() => pinInput?.focus(), 80);







    btnReject.onclick = () => {



      chrome.runtime.sendMessage(



        { action: "RESOLVE_SIGN_REQUEST", reqId: signReqId, error: "Transaction cancelled by user." },



        () => window.close()



      );



    };







    btnConfirm.onclick = async () => {



      const pin = pinInput.value.trim();



      if (!pin || pin.length < 4) {



        pinErr.textContent = "Enter a valid 4-digit PIN.";



        pinErr.style.display = "block";



        return;



      }







      chrome.storage.local.get(["luxa_vault", "luxa_vaults"], async (data) => {



        const vault = data.luxa_vault || (Array.isArray(data.luxa_vaults) ? data.luxa_vaults[0] : null);



        if (!vault) {



          pinErr.textContent = "No vault available.";



          pinErr.style.display = "block";



          return;



        }







        try {



          const mnemonic = await decryptMnemonic(vault.encrypted, pin);



          btnConfirm.disabled = true;



          btnConfirm.textContent = "Signing...";







          chrome.runtime.sendMessage(



            { action: "RESOLVE_SIGN_REQUEST", reqId: signReqId, mnemonic, txData },



            (res) => {



              if (res?.error) {



                pinErr.textContent = res.error;



                pinErr.style.display = "block";



                btnConfirm.disabled = false;



                btnConfirm.textContent = "Sign & Swap";



                return;



              }



              setTimeout(() => window.close(), 900);



            }



          );



        } catch (_) {



          pinErr.textContent = "Incorrect PIN. Access denied.";



          pinErr.style.display = "block";



        }



      });



    };



  }







  const isApproveMode = getQueryParam("mode") === "approve";



  const isSignMode = getQueryParam("mode") === "sign";



  const approveReqId = getQueryParam("reqId");



  const approveOrigin = getQueryParam("origin");



  const signReqId = getQueryParam("reqId");







  fetchLiveNftRegistry().catch(() => {});







  function hideAllViews() {



    if (popupLoading) popupLoading.style.display = "none";



    if (networkToggleStrip) networkToggleStrip.style.display = "none";



    if (bannerTestnet) bannerTestnet.style.display = "none";



    viewNoWallet.style.display = "none";



    viewUnlock.style.display = "none";



    if (viewApproveConnect) viewApproveConnect.style.display = "none";



    viewDashboard.style.display = "none";



    if (viewTokenDetail) viewTokenDetail.style.display = "none";



    viewSend.style.display = "none";



    if (viewInAppSwap) viewInAppSwap.style.display = "none";



    if (viewNfts) viewNfts.style.display = "none";



    if (viewSettings) viewSettings.style.display = "none";



  }







  function parseReserves(payload) {



    let data = payload?.data ?? payload;



    if (typeof data === "string") {



      try {



        data = JSON.parse(data);



      } catch {



        try {



          data = JSON.parse(atob(data));



        } catch {



          data = null;



        }



      }



    }







    let reserveA;



    let reserveB;



    if (Array.isArray(data)) {



      [reserveA, reserveB] = data;



    } else if (data && typeof data === "object") {



      reserveA = data.reserveA ?? data.reserve_a ?? data.reserve_u_luxa;



      reserveB = data.reserveB ?? data.reserve_b ?? data.reserve_u_shard;



    }







    reserveA = Number(reserveA);



    reserveB = Number(reserveB);



    return Number.isFinite(reserveA) && Number.isFinite(reserveB) && reserveA > 0 && reserveB > 0



      ? { reserveA, reserveB }



      : null;



  }







  async function fetchLivePoolReserves() {



    const query = encodeURIComponent(btoa(JSON.stringify({ get_reserves: {} })));



    const sources = [



      `${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/contract/${AMM_PAIR_CONTRACT}/smart/${query}`,



      LIVE_POOL_API



    ];



    for (const url of sources) {



      try {



        const response = await fetch(url, { cache: "no-store" });



        if (!response.ok) {



          console.warn("[LUXA Pool] HTTP", response.status, url);



          continue;



        }



        const reserves = parseReserves(await response.json());



        if (reserves) {



          livePoolState = { ...reserves, lastUpdated: Date.now() };



          return livePoolState;



        }



        console.warn("[LUXA Pool] Unrecognized reserve format from", url);



      } catch (err) {



        console.warn("[LUXA Pool] Fetch failed", url, err);



      }



    }



    return null;



  }







  async function openInAppSwap() {



    hideAllViews();



    if (vaultTopBar) vaultTopBar.style.display = "none";



    if (viewInAppSwap) viewInAppSwap.style.display = "block";



    swapIsAtoB = true;



    const input = document.getElementById("inapp-swap-input-in");



    if (input) input.value = "";



    updateInAppSwapUI();







    const rate = document.getElementById("inapp-swap-rate");



    const submit = document.getElementById("btn-inapp-swap-submit");



    const network = await new Promise((resolve) => {



      chrome.storage.local.get(["active_network"], (data) => resolve(data.active_network || "testnet"));



    });



    swapNetworkAllowed = true;



    if (submit) submit.disabled = false;



    const feeDisplay = document.getElementById("inapp-swap-network-fee");



    if (feeDisplay) feeDisplay.textContent = `${network === "testnet" ? 0 : SWAP_NETWORK_FEE} LUXA`;



    const reserves = await fetchLivePoolReserves();



    if (!reserves) {



      if (rate) rate.textContent = "Unable to load live pool reserves.";



      if (submit) submit.disabled = true;



      return;



    }



    const spotRate = swapIsAtoB



      ? reserves.reserveB / reserves.reserveA



      : (reserves.reserveA / reserves.reserveB) * 10000;



    if (rate) {



      rate.textContent = swapIsAtoB



        ? `1 LUXA ≈ ${spotRate.toLocaleString("en-US", { maximumFractionDigits: 4 })} SHARD`



        : `10,000 SHARD ≈ ${spotRate.toFixed(4)} LUXA`;



    }



    await calculateInAppQuote();



  }







  function updateInAppSwapUI() {



    const symbolIn = document.getElementById("inapp-swap-sym-in");



    const symbolOut = document.getElementById("inapp-swap-sym-out");



    const balance = document.getElementById("inapp-swap-bal-in");



    const logoIn = document.getElementById("inapp-swap-img-in");



    const logoOut = document.getElementById("inapp-swap-img-out");



    if (!symbolIn || !symbolOut || !balance) return;







    const luxaIn = swapIsAtoB;



    symbolIn.textContent = luxaIn ? "LUXA" : "SHARD";



    symbolOut.textContent = luxaIn ? "SHARD" : "LUXA";



    symbolIn.style.color = luxaIn ? "#00FFCC" : "#A855F7";



    symbolOut.style.color = luxaIn ? "#A855F7" : "#00FFCC";



    balance.textContent = `${Number(vaultBalances[luxaIn ? "luxa" : "shards"]).toLocaleString("en-US")} ${luxaIn ? "LUXA" : "SHARD"}`;



    if (logoIn) logoIn.src = luxaIn ? LUXA_LOGO_URL : SHARDS_LOGO_URL;



    if (logoOut) logoOut.src = luxaIn ? SHARDS_LOGO_URL : LUXA_LOGO_URL;







    balance.onclick = async () => {



      const rawBalance = Number(vaultBalances[luxaIn ? "luxa" : "shards"]) || 0;



      const network = await new Promise((resolve) => {



        chrome.storage.local.get(["active_network"], (data) => resolve(data.active_network || "testnet"));



      });



      const feeForNetwork = network === "testnet" ? 0 : SWAP_NETWORK_FEE;



      const maxAmount = luxaIn ? Math.max(0, rawBalance - feeForNetwork) : rawBalance;



      const input = document.getElementById("inapp-swap-input-in");



      if (input) input.value = maxAmount > 0 ? (luxaIn ? maxAmount.toFixed(6) : String(Math.floor(maxAmount))) : "0";



      calculateInAppQuote();



    };



  }







  async function calculateInAppQuote() {



    const requestId = ++quoteRequestId;



    const input = document.getElementById("inapp-swap-input-in");



    const output = document.getElementById("inapp-swap-input-out");



    const rate = document.getElementById("inapp-swap-rate");



    const amount = Number(input?.value || 0);



    const submit = document.getElementById("btn-inapp-swap-submit");







    if (!swapNetworkAllowed) {



      if (submit) submit.disabled = true;



      return;



    }



    if (!Number.isFinite(amount) || amount <= 0) {



      if (output) output.value = "0.0";



      if (submit) submit.disabled = true;



      return;



    }



    if (submit) submit.disabled = false;







    let reserves = livePoolState;



    if (!reserves.reserveA || !reserves.reserveB || Date.now() - reserves.lastUpdated > 8000) {



      reserves = await fetchLivePoolReserves();



    }



    if (requestId !== quoteRequestId) return;



    if (!reserves?.reserveA || !reserves?.reserveB) {



      if (output) output.value = "0.0";



      if (rate) rate.textContent = "Unable to load live pool reserves.";



      if (submit) submit.disabled = true;



      return;



    }







    const inputMicro = Math.floor(amount * 1_000_000);



    const inputWithFee = inputMicro * 0.997;



    const reserveIn = swapIsAtoB ? reserves.reserveA : reserves.reserveB;



    const reserveOut = swapIsAtoB ? reserves.reserveB : reserves.reserveA;



    const outputMicro = (reserveOut * inputWithFee) / (reserveIn + inputWithFee);



    const outputAmount = outputMicro / 1_000_000;



    if (!Number.isFinite(outputAmount) || outputAmount <= 0) {



      if (output) output.value = "0.0";



      if (rate) rate.textContent = "No valid quote is available for this amount.";



      if (submit) submit.disabled = true;



      return;



    }







    if (output) output.value = outputAmount.toFixed(swapIsAtoB ? 4 : 6);



    if (rate) {



      const spotRate = reserveOut / reserveIn;



      rate.textContent = swapIsAtoB



        ? `1 LUXA ≈ ${spotRate.toLocaleString("en-US", { maximumFractionDigits: 4 })} SHARD`



        : `10,000 SHARD ≈ ${(spotRate * 10000).toFixed(4)} LUXA`;



    }



  }







  document.getElementById("btn-inapp-swap-invert")?.addEventListener("click", () => {



    swapIsAtoB = !swapIsAtoB;



    const input = document.getElementById("inapp-swap-input-in");



    const output = document.getElementById("inapp-swap-input-out");



    if (input) input.value = "";



    if (output) output.value = "0.0";



    updateInAppSwapUI();



    const submit = document.getElementById("btn-inapp-swap-submit");



    if (submit) submit.disabled = false;



    const rate = document.getElementById("inapp-swap-rate");



    if (rate) rate.textContent = "Querying live pool...";



    calculateInAppQuote();



  });



  document.getElementById("btn-back-from-inapp-swap")?.addEventListener("click", showDashboard);



  document.getElementById("inapp-swap-input-in")?.addEventListener("input", calculateInAppQuote);







  document.getElementById("btn-inapp-swap-submit")?.addEventListener("click", async (event) => {



    const button = event.currentTarget;



    const currentVault = vaults[activeIndex];



    const input = document.getElementById("inapp-swap-input-in");



    const output = document.getElementById("inapp-swap-input-out");



    const amount = Number(input?.value || 0);



    const estimatedOutput = Number(output?.value || 0);



    if (!Number.isFinite(amount) || amount <= 0 || !Number.isFinite(estimatedOutput) || estimatedOutput <= 0) {



      return LuxaUI.alert({



        title: "Invalid Swap",



        desc: "Enter an amount with a valid live quote before swapping.",



        icon: "⚠️"



      });



    }



    if (!currentVault?.encrypted) {



      return LuxaUI.alert({ title: "Vault Unavailable", desc: "Unlock a vault before swapping.", icon: "⚠️" });



    }







    const network = await new Promise((resolve) => {



      chrome.storage.local.get(["active_network"], (data) => resolve(data.active_network || "testnet"));



    });



    const balance = Number(vaultBalances[swapIsAtoB ? "luxa" : "shards"]) || 0;



    const feeForNetwork = network === "testnet" ? 0 : SWAP_NETWORK_FEE;



    const maxAmount = swapIsAtoB ? Math.max(0, balance - feeForNetwork) : balance;



    if (amount > maxAmount) {



      return LuxaUI.alert({



        title: "Insufficient Balance",



        desc: swapIsAtoB



          ? `Available LUXA for this swap is ${maxAmount.toFixed(6)}${feeForNetwork ? " after reserving the network fee." : "."}`



          : `Available SHARD balance is ${balance.toLocaleString("en-US")}.`,



        icon: "⚠️"



      });



    }







    const refreshedPool = await fetchLivePoolReserves();



    if (!refreshedPool) {



      return LuxaUI.alert({



        title: "Pool Unavailable",



        desc: "Could not refresh the on-chain pool reserves. Please try again.",



        icon: "❌"



      });



    }



    await calculateInAppQuote();



    const refreshedOutput = Number(output?.value || 0);



    if (!Number.isFinite(refreshedOutput) || refreshedOutput <= 0) {



      return LuxaUI.alert({ title: "Quote Unavailable", desc: "Could not calculate a valid swap quote.", icon: "❌" });



    }







    if (network === "testnet") {



      button.disabled = true;



      button.textContent = "Swapping on testnet...";



      try {



        const res = await fetch(`${BACKEND_API}/testnet/swap`, {



          method: "POST",



          headers: { "Content-Type": "application/json" },



          body: JSON.stringify({



            address: currentVault.address,



            offerDenom: swapIsAtoB ? "luxa" : "shards",



            amount,



            minOut: refreshedOutput * 0.98



          })



        });



        const data = await res.json();



        if (!res.ok || !data.success) throw new Error(data.error || "Testnet swap failed.");







        await LuxaUI.alert({



          title: "Swap Confirmed (Testnet)",



          desc: `Received <b>${Number(data.received).toFixed(4)} ${data.receiveCurrency}</b>.<br><br>` +



                `<span style="font-family:monospace; font-size:10px; color:#00FFCC;">Tx: ${data.txHash}</span>`,



          icon: "⚡",



          btnText: "Return to Dashboard"



        });



        showDashboard();



      } catch (error) {



        await LuxaUI.alert({



          title: "Testnet Swap Failed",



          desc: error?.message || "An error occurred while swapping.",



          icon: "❌"



        });



      } finally {



        button.disabled = false;



        button.textContent = "Sign & Execute Swap";



      }



      return;



    }







    const inputSymbol = swapIsAtoB ? "LUXA" : "SHARD";



    const outputSymbol = swapIsAtoB ? "SHARD" : "LUXA";



    const pin = await LuxaUI.prompt({



      title: "Confirm AMM Swap",



      desc: `Swap <b>${amount} ${inputSymbol}</b> for an estimated <b>${refreshedOutput} ${outputSymbol}</b>.<br><br>Enter your PIN to authorize this transaction.`,



      placeholder: "4-digit PIN",



      icon: "🔒",



      isPassword: true,



      rows: 1



    });



    if (!pin) return;







    let mnemonic = "";



    let client = null;



    try {



      mnemonic = await decryptMnemonic(currentVault.encrypted, pin);



    } catch (_) {



      return LuxaUI.alert({ title: "Access Denied", desc: "Incorrect PIN entered.", icon: "❌" });



    }







    button.disabled = true;



    button.textContent = "Signing and broadcasting...";



    try {



      if (!globalThis.CosmJS) throw new Error("CosmJS is not available in this popup.");



      const hdPath = globalThis.CosmJS.stringToPath



        ? globalThis.CosmJS.stringToPath("m/44'/118'/0'/0/0")



        : undefined;



      const walletOptions = { prefix: "luxa" };



      if (hdPath) walletOptions.hdPaths = [hdPath];



      const signer = await globalThis.CosmJS.DirectSecp256k1HdWallet.fromMnemonic(mnemonic, walletOptions);



      const [account] = await signer.getAccounts();



      if (account.address.toLowerCase() !== String(currentVault.address || "").toLowerCase()) {



        throw new Error("The decrypted recovery phrase does not match the selected vault address.");



      }







      client = await globalThis.CosmJS.SigningCosmWasmClient.connectWithSigner(



        "https://rpc.luxaecosystem.xyz",



        signer,



        { gasPrice: globalThis.CosmJS.GasPrice.fromString("0.001uluxa") }



      );







      const inputMicro = BigInt(Math.floor(amount * 1_000_000)).toString();



      const minOutputMicro = BigInt(Math.floor(refreshedOutput * 0.98 * 1_000_000)).toString();



      const executeMsg = swapIsAtoB



        ? { swap_a_for_b: { min_out: minOutputMicro } }



        : { swap_b_for_a: { min_out: minOutputMicro } };



      const funds = [{



        denom: swapIsAtoB ? "uluxa" : "ushard",



        amount: inputMicro



      }];



      const result = await client.execute(



        account.address,



        AMM_PAIR_CONTRACT,



        executeMsg,



        { amount: [{ denom: "uluxa", amount: "7000" }], gas: "280000" },



        "LUXA Sovereign DEX Swap",



        funds



      );







      await LuxaUI.alert({



        title: "Swap Confirmed",



        desc: `Transaction confirmed in block <b>#${String(result.height || "")}</b>.<br><br><span style="font-family:monospace; font-size:10px; color:#00FFCC;">Tx Hash: ${String(result.transactionHash || "")}</span>`,



        icon: "⚡",



        btnText: "Return to Dashboard"



      });



      showDashboard();



    } catch (error) {



      await LuxaUI.alert({



        title: "Transaction Failed",



        desc: error?.message || "An error occurred while executing the swap.",



        icon: "❌"



      });



    } finally {



      if (client) await client.disconnect().catch((error) => console.warn("[LUXA Swap] Disconnect failed:", error));



      mnemonic = "";



      button.disabled = false;



      button.textContent = "Sign & Execute Swap";



    }



  });







  function showNoWalletScreen() {



    hideAllViews();



    if (vaultTopBar) vaultTopBar.style.display = "none";



    viewNoWallet.style.display = "flex";



  }







  // --- NATIVE BIOMETRIC (FINGERPRINT & FACE RECOGNITION) ---
  let isBiometricPromptOpen = false;

  async function checkBiometricAvailability(autoPrompt = true) {
    const btnBio = document.getElementById("btn-biometric-unlock");
    if (!window.LuxaBiometric) {
      if (btnBio) btnBio.style.display = "none";
      return;
    }
    try {
      const info = await window.LuxaBiometric.isAvailable();
      if (info && info.available) {
        if (btnBio) {
          btnBio.style.display = "inline-flex";
          btnBio.onclick = () => triggerBiometricUnlock();
        }
        if (info.hasCredentials && autoPrompt && localStorage.getItem("luxa_bio_enabled") !== "false") {
          setTimeout(() => triggerBiometricUnlock(), 250);
        }
      } else {
        if (btnBio) btnBio.style.display = "none";
      }
    } catch (_) {
      if (btnBio) btnBio.style.display = "none";
    }
  }

  async function triggerBiometricUnlock() {
    if (!window.LuxaBiometric || isBiometricPromptOpen) return;
    try {
      const info = await window.LuxaBiometric.isAvailable();
      if (!info || !info.hasCredentials) {
        LuxaUI.toast("Please unlock with PIN once to register fingerprint.", "ℹ️");
        unlockPinInput.focus();
        return;
      }
      isBiometricPromptOpen = true;
      const res = await window.LuxaBiometric.authenticate({
        title: "Spider Vault",
        subtitle: "Verify fingerprint to unlock",
        cancelText: "Use PIN"
      });
      isBiometricPromptOpen = false;
      if (res && res.success && res.pin) {
        unlockPinInput.value = res.pin;
        handleUnlock();
      }
    } catch (err) {
      isBiometricPromptOpen = false;
      console.warn("[LUXA Biometric] Auth error:", err);
    }
  }

  async function setupBiometricSettings() {
    const block = document.getElementById("settings-biometrics-block");
    const toggle = document.getElementById("toggle-biometrics");
    if (!block || !toggle || !window.LuxaBiometric) return;

    try {
      const info = await window.LuxaBiometric.isAvailable();
      if (!info || !info.available) {
        block.style.display = "none";
        return;
      }
      block.style.display = "block";
      toggle.checked = info.hasCredentials && localStorage.getItem("luxa_bio_enabled") !== "false";

      toggle.onchange = async () => {
        if (toggle.checked) {
          const pin = await LuxaUI.prompt({
            title: "Enable Biometrics",
            desc: "Enter your Vault PIN to link with Fingerprint & Face Recognition:",
            placeholder: "Enter Vault PIN",
            icon: "👆",
            isPassword: true,
            rows: 1
          });
          if (!pin) {
            toggle.checked = false;
            return;
          }
          const cur = vaults[activeIndex];
          try {
            await decryptMnemonic(cur.encrypted, pin);
            const res = await window.LuxaBiometric.setCredentials(pin);
            if (res && res.success) {
              localStorage.setItem("luxa_bio_enabled", "true");
              LuxaUI.toast("Biometric unlock enabled!", "👆");
            } else {
              toggle.checked = false;
              LuxaUI.alert({ title: "Setup Failed", desc: res?.error || "Could not register biometrics.", icon: "❌" });
            }
          } catch (_) {
            toggle.checked = false;
            LuxaUI.alert({ title: "Incorrect PIN", desc: "The PIN entered does not match your vault.", icon: "❌" });
          }
        } else {
          await window.LuxaBiometric.clearCredentials();
          localStorage.setItem("luxa_bio_enabled", "false");
          LuxaUI.toast("Biometric unlock disabled", "🔒");
        }
      };
    } catch (_) {
      block.style.display = "none";
    }
  }

  function showUnlockScreen() {



    hideAllViews();



    if (vaultTopBar) vaultTopBar.style.display = "none";



    viewUnlock.style.display = "flex";



    unlockPinInput.value = "";



    unlockError.style.display = "none";



    setTimeout(() => unlockPinInput.focus(), 80);







    const cur = vaults[activeIndex];



    if (cur) {



      const short = cur.address.slice(0, 8) + "..." + cur.address.slice(-4);



      unlockWalletLabel.textContent = `${cur.name || "Vault"} (${short})`;



    }

    checkBiometricAvailability(true);

  }







  // --- CREAZIONE, IMPORTAZIONE & RESET WALLET ---



  async function handleCreateNewWallet() {



    const pin = await LuxaUI.prompt({



      title: "Create New Vault",



      desc: "Set a security PIN of at least 4 characters to encrypt your keys:",



      placeholder: "e.g. 1234",



      icon: "🔒",



      isPassword: true,



      rows: 1



    });



    if (!pin || pin.length < 4) {



      if (pin) LuxaUI.alert({ title: "PIN Too Short", desc: "The PIN must contain at least 4 characters.", icon: "⚠️" });



      return;



    }







    LuxaUI.toast("Generating Cosmos keys... ⏳", "⚡");







    chrome.runtime.sendMessage({ action: "GENERATE_NEW_WALLET" }, async (res) => {



      if (res?.error || !res?.mnemonic) {



        return LuxaUI.alert({ title: "Creation Error", desc: res?.error || "Unable to generate the keys.", icon: "❌" });



      }







      if (res?.address) {



        const existingIdx = vaults.findIndex(



          (v) => v.address && v.address.trim().toLowerCase() === res.address.trim().toLowerCase()



        );



        if (existingIdx !== -1) {



          return LuxaUI.alert({



            title: "Wallet Already Exists",



            desc: "A vault with this address already exists in your wallet list.",



            icon: "⚠️"



          });



        }



      }







      try {



        const encrypted = await encryptMnemonic(res.mnemonic, pin);



        const vaultName = `Vault ${vaults.length + 1}`;



        const newVault = {



          name: vaultName,



          address: res.address,



          encrypted,



          createdAt: new Date().toISOString()



        };







        vaults.push(newVault);



        activeIndex = vaults.length - 1;







            chrome.storage.local.set({



              luxa_vaults: vaults,



              luxa_vault: newVault,



              active_wallet_idx: activeIndex,



              is_unlocked: true,



              last_activity: Date.now()



            }, async () => {



              broadcastVaultState("BROADCAST_VAULT_UNLOCKED", newVault.address);



              broadcastVaultState("VAULT_READY_BROADCAST", newVault.address);







              await LuxaUI.alert({



            title: "Save Your 24 Secret Words!",



            desc: `This is the ONLY copy of your keys. Write them down offline:<br><br><div style="text-align:left; font-family:monospace; background:#0b1220; border:1px solid rgba(0,255,204,0.3); padding:12px; border-radius:10px; color:#00FFCC; font-size:11px; line-height:1.7; word-break:break-word;">${res.mnemonic}</div>`,



            icon: "🔑",



            btnText: "I Saved the Words"



          });







          showDashboard();



        });



      } catch (err) {



        LuxaUI.alert({ title: "Encryption Error", desc: err.message, icon: "❌" });



      }



    });



  }







  async function handleImportWallet() {



    const rawMnemonic = await LuxaUI.prompt({



      title: "Import Vault",



      desc: "Enter your 12 or 24 recovery words separated by spaces:",



      placeholder: "word1 word2 word3 ...",



      icon: "📥",



      isPassword: false,



      rows: 3



    });



    if (!rawMnemonic) return;







    const mnemonic = rawMnemonic.trim().toLowerCase().replace(/\s+/g, " ");



    const wordCount = mnemonic.split(" ").length;



    if (wordCount !== 12 && wordCount !== 24) {



      return LuxaUI.alert({ title: "Invalid Mnemonic", desc: `You entered ${wordCount} words. Enter 12 or 24 words.`, icon: "⚠️" });



    }







    LuxaUI.toast("Checking on-chain derivation... ⏳", "⚡");







    chrome.runtime.sendMessage({ action: "DERIVE_WALLET_FROM_MNEMONIC", mnemonic }, async (res) => {



      if (res?.error || !res?.address) {



        return LuxaUI.alert({ title: "Import Error", desc: res?.error || "Invalid mnemonic phrase.", icon: "❌" });



      }







      // PREVENT DUPLICATE WALLET IMPORT:



      const existingIdx = vaults.findIndex(



        (v) => v.address && v.address.trim().toLowerCase() === res.address.trim().toLowerCase()



      );



      if (existingIdx !== -1) {



        const existingVault = vaults[existingIdx];



        const vaultName = existingVault.name || `Vault ${existingIdx + 1}`;



        const shortAddr = res.address.slice(0, 10) + "..." + res.address.slice(-6);







        const doSwitch = await LuxaUI.confirm({



          title: "Wallet Already Imported",



          desc: `This wallet address is already saved as <b>${vaultName}</b>:<br><br><span style="color:#00FFCC; font-family:monospace; word-break:break-all;">${shortAddr}</span><br><br>Do you want to switch to this Vault?`,



          icon: "ℹ️",



          confirmText: "Switch to Vault",



          cancelText: "Cancel"



        });







        if (doSwitch) {



          activeIndex = existingIdx;



          chrome.storage.local.set({



            luxa_vault: vaults[activeIndex],



            active_wallet_idx: activeIndex,



            is_unlocked: true,



            last_activity: Date.now()



          }, () => {



            showDashboard();



            LuxaUI.toast(`Switched to ${vaults[activeIndex].name}`, "⚡");



          });



        }



        return;



      }







      const pin = await LuxaUI.prompt({



        title: "Set Vault PIN",



        desc: `Derived address: <b style="color:#00FFCC; font-family:monospace;">${res.address.slice(0, 10)}...${res.address.slice(-6)}</b><br><br>Set a security PIN of at least 4 characters:`,



        placeholder: "e.g. 1234",



        icon: "🔒",



        isPassword: true,



        rows: 1



      });



      if (!pin || pin.length < 4) {



        if (pin) LuxaUI.alert({ title: "PIN Too Short", desc: "The PIN must contain at least 4 characters.", icon: "⚠️" });



        return;



      }







      try {



        const encrypted = await encryptMnemonic(mnemonic, pin);



        const vaultName = `Vault ${vaults.length + 1}`;



        const newVault = {



          name: vaultName,



          address: res.address,



          encrypted,



          createdAt: new Date().toISOString()



        };







        vaults.push(newVault);



        activeIndex = vaults.length - 1;







        chrome.storage.local.set({



          luxa_vaults: vaults,



          luxa_vault: newVault,



          active_wallet_idx: activeIndex,



          is_unlocked: true,



          last_activity: Date.now()



        }, () => {



          broadcastVaultState("BROADCAST_VAULT_UNLOCKED", newVault.address);



          broadcastVaultState("VAULT_READY_BROADCAST", newVault.address);



          LuxaUI.toast("Vault imported successfully! 🚀", "⚡");



          showDashboard();



        });



      } catch (err) {



        LuxaUI.alert({ title: "Encryption Error", desc: err.message, icon: "❌" });



      }



    });



  }







  async function handleResetVault() {



    const cur = vaults[activeIndex];



    if (!cur) return;



    const ok = await LuxaUI.confirm({



      title: "Remove Vault?",



      desc: `Do you want to remove <b>${cur.name}</b> (${cur.address.slice(0, 8)}...)?<br><br><span style="color:#ef4444;">Make sure you saved the 24 recovery words before continuing!</span>`,



      icon: "⚠️",



      confirmText: "Remove",



      cancelText: "Cancel"



    });



    if (!ok) return;







    vaults.splice(activeIndex, 1);



    if (vaults.length === 0) {



      activeIndex = 0;



      chrome.storage.local.remove(["luxa_vault", "luxa_vaults", "active_wallet_idx", "is_unlocked"], () => {



        broadcastVaultState("BROADCAST_VAULT_LOCKED");



        LuxaUI.toast("All vaults have been removed.", "🔄");



        showNoWalletScreen();



      });



    } else {



      activeIndex = 0;



      const nextVault = vaults[0];



      chrome.storage.local.set({



        luxa_vaults: vaults,



        luxa_vault: nextVault,



        active_wallet_idx: 0



      }, () => {



        LuxaUI.toast("Vault removed.", "🗑️");



        showDashboard();



      });



    }



  }







  // --- GOOGLE DRIVE CLOUD HANDLING (BACKUP & RESTORE) ---



  async function handleGoogleLogin() {



    try {



      LuxaUI.toast("Connecting to Google... ⏳", "☁️");



      const token = await GoogleDriveEngine.getAuthToken(true);



      const profile = await GoogleDriveEngine.getUserProfile(token);







      chrome.storage.local.set({



        google_account: {



          token,



          email: profile.email,



          name: profile.name,



          picture: profile.picture



        }



      }, () => {



        updateGoogleSettingsUI();



        LuxaUI.toast(`Synced with ${profile.name}!`, "✓");



      });



    } catch (err) {



      LuxaUI.alert({ title: "Google Sign-In Failed", desc: err.message, icon: "❌" });



    }



  }







  function handleGoogleDisconnect() {



    chrome.storage.local.remove(["google_account"], () => {



      updateGoogleSettingsUI();



      LuxaUI.toast("Google account disconnected.", "🔒");



    });



  }







  async function handleDriveBackup() {



    try {



      LuxaUI.toast("Saving to Google Drive... ⏳", "☁️");



      const token = await GoogleDriveEngine.getAuthToken(true);



      await GoogleDriveEngine.uploadBackup(token, vaults);



      const timestamp = new Date().toLocaleString();







      chrome.storage.local.set({ last_drive_backup: timestamp }, () => {



        const timeEl = document.getElementById("drive-backup-timestamp");



        if (timeEl) timeEl.textContent = timestamp;



        LuxaUI.alert({



          title: "Encrypted Backup Saved!",



          desc: "All your PIN-encrypted vaults are now safe in your private Google Drive space (Zero-Knowledge).",



          icon: "☁️"



        });



      });



    } catch (err) {



      LuxaUI.alert({ title: "Backup Error", desc: err.message, icon: "❌" });



    }



  }







  async function handleDriveRestore() {



    try {



      LuxaUI.toast("Searching Drive for a backup... ⏳", "📥");



      const token = await GoogleDriveEngine.getAuthToken(true);



      const { data, modifiedTime } = await GoogleDriveEngine.downloadBackup(token);







      if (!data || !Array.isArray(data.vaults) || data.vaults.length === 0) {



        throw new Error("The Google Drive backup file is empty or invalid.");



      }







      const ok = await LuxaUI.confirm({



        title: "Restore Vaults?",



        desc: `Found <b>${data.vaults.length}</b> vault(s) saved on ${new Date(modifiedTime).toLocaleString()}.<br><br>Do you want to overwrite or import the vaults saved on this device?`,



        icon: "📥",



        confirmText: "Restore",



        cancelText: "Cancel"



      });



      if (!ok) return;







      // Deduplicate restored vaults



      const seen = new Set();



      const uniqueRestored = [];



      for (const v of data.vaults) {



        if (!v || !v.address) continue;



        const cleanAddr = String(v.address).trim().toLowerCase();



        if (!seen.has(cleanAddr)) {



          seen.add(cleanAddr);



          uniqueRestored.push(v);



        }



      }



      vaults = uniqueRestored;



      activeIndex = 0;



      const primaryVault = vaults[0];







      chrome.storage.local.set({



        luxa_vaults: vaults,



        luxa_vault: primaryVault,



        active_wallet_idx: 0,



        is_unlocked: false



      }, () => {



        LuxaUI.toast("Vaults restored successfully!", "⚡");



        showUnlockScreen();



      });



    } catch (err) {



      LuxaUI.alert({ title: "Restore Error", desc: err.message, icon: "❌" });



    }



  }







  function updateGoogleSettingsUI() {



    chrome.storage.local.get(["google_account", "last_drive_backup"], (data) => {



      const loggedOutBox = document.getElementById("google-logged-out");



      const loggedInBox = document.getElementById("google-logged-in");



      const avatarEl = document.getElementById("google-avatar");



      const nameEl = document.getElementById("google-name");



      const emailEl = document.getElementById("google-email");



      const timeEl = document.getElementById("drive-backup-timestamp");







      if (timeEl) timeEl.textContent = data.last_drive_backup || "Never";







      if (data.google_account?.email) {



        if (loggedOutBox) loggedOutBox.style.display = "none";



        if (loggedInBox) loggedInBox.style.display = "block";



        if (nameEl) nameEl.textContent = data.google_account.name || "Google User";



        if (emailEl) emailEl.textContent = data.google_account.email;



        if (avatarEl && data.google_account.picture) avatarEl.src = data.google_account.picture;



      } else {



        if (loggedOutBox) loggedOutBox.style.display = "block";



        if (loggedInBox) loggedInBox.style.display = "none";



      }



    });



  }







  function renderConnectedSitesSettings() {



    const list = document.getElementById("connected-sites-list");



    if (!list) return;







    chrome.storage.local.get(["approved_origins", "connected_sites", "white_card_authorized"], (data) => {



      const approvedOrigins = Array.isArray(data.approved_origins) ? data.approved_origins : [];



      const connectedSites = Array.isArray(data.connected_sites) ? data.connected_sites : [];



      const allEntries = Array.from(new Set([...approvedOrigins, ...connectedSites])).filter(Boolean);







      const hasWhiteCard = Boolean(data.white_card_authorized) || allEntries.includes("*.luxaecosystem.xyz");



      const singleOrigins = allEntries.filter(o => o !== "*.luxaecosystem.xyz");







      if (!hasWhiteCard && singleOrigins.length === 0) {



        list.innerHTML = `



          <div style="font-size:11.5px; color:var(--text-3); text-align:center; padding:12px 6px;">



            No authorized sites connected.



          </div>



          <button type="button" id="btn-quick-enable-whitecard" style="width:100%; margin-top:4px; padding:9px 12px; background:linear-gradient(135deg, rgba(0,255,204,0.12), rgba(124,58,237,0.15)); border:1px solid rgba(0,255,204,0.4); border-radius:9px; color:#00FFCC; font-size:11.5px; font-weight:700; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:6px;">



            <span>🌐</span> Authorize LUXA Ecosystem (White Card)



          </button>



        `;



        const btnEnable = list.querySelector("#btn-quick-enable-whitecard");



        if (btnEnable) {



          btnEnable.onclick = () => {



            const ecoList = ["*.luxaecosystem.xyz", "https://luxaecosystem.xyz", "https://ldex.luxaecosystem.xyz", "https://studio.luxaecosystem.xyz", "https://explorer.luxaecosystem.xyz", "https://faucet.luxaecosystem.xyz"];



            chrome.storage.local.set({



              white_card_authorized: true,



              approved_origins: ecoList,



              connected_sites: ecoList



            }, () => {



              LuxaUI.toast("LUXA Ecosystem White Card authorized!", "🌐");



              renderConnectedSitesSettings();



              checkCurrentTabConnection();



            });



          };



        }



        return;



      }







      let html = "";







      // 1. Ecosystem White Card Card if active



      if (hasWhiteCard) {



        html += `



          <div class="connected-site-row" style="background:linear-gradient(135deg, rgba(0,255,204,0.08), rgba(124,58,237,0.1)); border:1px solid rgba(0,255,204,0.35); padding:10px 12px; margin-bottom:8px; border-radius:10px; display:flex; align-items:center; justify-content:space-between;">



            <div style="flex:1; min-width:0; padding-right:8px;">



              <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">



                <span style="font-size:14px;">🌐</span>



                <span style="font-weight:700; color:#fff; font-size:12px;">LUXA Ecosystem</span>



                <span style="font-size:9px; background:rgba(0,255,204,0.18); color:#00FFCC; border:1px solid rgba(0,255,204,0.4); padding:1px 5px; border-radius:4px; font-weight:800; font-family:var(--font-mono);">WHITE CARD</span>



              </div>



              <div style="font-size:10px; color:var(--text-3); margin-top:3px; font-family:var(--font-mono);">*.luxaecosystem.xyz (All subdomains)</div>



            </div>



            <button type="button" class="btn-quick-disconnect btn-revoke-white-card" title="Revoke White Card SSO" style="padding:4px 8px; font-size:11px; white-space:nowrap;">Revoke ✕</button>



          </div>



        `;



      }







      // 2. Individual Authorized Origins



      singleOrigins.forEach(orig => {



        let cleanHost = orig;



        try { cleanHost = new URL(orig).hostname; } catch (_) {}



        const isEco = cleanHost === "luxaecosystem.xyz" || cleanHost.endsWith(".luxaecosystem.xyz");



        const badgeLabel = isEco ? "ECOSYSTEM" : "DAPP";



        const badgeColor = isEco ? "color:var(--cyan); border-color:rgba(0,255,204,0.3);" : "color:var(--text-2); border-color:rgba(255,255,255,0.15);";







        html += `



          <div class="connected-site-row" style="padding:9px 11px; margin-bottom:6px; border-radius:10px; display:flex; align-items:center; justify-content:space-between;">



            <div style="flex:1; min-width:0; overflow:hidden; padding-right:8px;">



              <div style="display:flex; align-items:center; gap:6px;">



                <span style="font-size:12px;">🔗</span>



                <span style="font-weight:600; color:#fff; font-size:11.5px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${escapeHtml(cleanHost)}</span>



                <span style="font-size:9px; background:rgba(255,255,255,0.05); padding:1px 4px; border-radius:4px; font-family:var(--font-mono); border:1px solid; ${badgeColor}">${badgeLabel}</span>



              </div>



              <div style="font-size:10px; color:var(--text-3); font-family:var(--font-mono); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; margin-top:2px;">${escapeHtml(orig)}</div>



            </div>



            <button type="button" class="btn-quick-disconnect btn-revoke-single" data-origin="${escapeHtml(orig)}" title="Revoke access" style="padding:4px 8px; font-size:11px; white-space:nowrap;">Revoke ✕</button>



          </div>



        `;



      });







      // If White Card not yet active, show add button at bottom



      if (!hasWhiteCard) {



        html += `



          <button type="button" id="btn-quick-enable-whitecard" style="width:100%; margin-top:8px; padding:8px 12px; background:linear-gradient(135deg, rgba(0,255,204,0.12), rgba(124,58,237,0.15)); border:1px solid rgba(0,255,204,0.35); border-radius:8px; color:#00FFCC; font-size:11.5px; font-weight:700; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:6px;">



            <span>🌐</span> Authorize LUXA Ecosystem (White Card)



          </button>



        `;



      }







      list.innerHTML = html;







      // Event: Revoke White Card



      const btnRevokeWc = list.querySelector(".btn-revoke-white-card");



      if (btnRevokeWc) {



        btnRevokeWc.onclick = () => {



          chrome.storage.local.set({



            white_card_authorized: false,



            approved_origins: singleOrigins.filter(o => !o.includes("luxaecosystem.xyz")),



            connected_sites: singleOrigins.filter(o => !o.includes("luxaecosystem.xyz"))



          }, () => {



            LuxaUI.toast("LUXA Ecosystem White Card revoked", "🔒");



            renderConnectedSitesSettings();



            checkCurrentTabConnection();



            broadcastVaultState("BROADCAST_VAULT_REVOKED", null, "*.luxaecosystem.xyz");



          });



        };



      }







      // Event: Quick Enable White Card



      const btnEnableWc = list.querySelector("#btn-quick-enable-whitecard");



      if (btnEnableWc) {



        btnEnableWc.onclick = () => {



          const updated = Array.from(new Set([...allEntries, "*.luxaecosystem.xyz", "https://luxaecosystem.xyz", "https://ldex.luxaecosystem.xyz", "https://studio.luxaecosystem.xyz", "https://explorer.luxaecosystem.xyz", "https://faucet.luxaecosystem.xyz"]));



          chrome.storage.local.set({



            white_card_authorized: true,



            approved_origins: updated,



            connected_sites: updated



          }, () => {



            LuxaUI.toast("LUXA Ecosystem White Card authorized!", "🌐");



            renderConnectedSitesSettings();



            checkCurrentTabConnection();



          });



        };



      }







      // Event: Revoke Single Site



      list.querySelectorAll(".btn-revoke-single").forEach(btn => {



        btn.onclick = () => {



          const targetOrigin = btn.getAttribute("data-origin");



          const updatedApproved = approvedOrigins.filter(o => o !== targetOrigin);



          const updatedConnected = connectedSites.filter(o => o !== targetOrigin);



          chrome.storage.local.set({



            approved_origins: updatedApproved,



            connected_sites: updatedConnected



          }, () => {



            LuxaUI.toast(`Revoked for ${targetOrigin}`, "🔒");



            renderConnectedSitesSettings();



            checkCurrentTabConnection();



            broadcastVaultState("BROADCAST_VAULT_REVOKED", null, targetOrigin);

          });

        };

      });

    });

  }







  // --- ASSEGNAZIONE EVENTI PULSANTI ---



  document.getElementById("btn-create-wallet").onclick = handleCreateNewWallet;

  const btnCheckOTA = document.getElementById("btn-check-ota-update");
  if (btnCheckOTA) {
    btnCheckOTA.onclick = () => {
      if (typeof window.checkLuxaUpdate === "function") {
        window.checkLuxaUpdate();
      } else {
        LuxaUI.toast("Running on latest Spider Vault v1.6.2", "✓");
      }
    };
  }




  document.getElementById("btn-import-wallet").onclick = handleImportWallet;



  document.getElementById("btn-restore-drive-initial").onclick = handleDriveRestore;



  document.getElementById("btn-new-vault").onclick = handleCreateNewWallet;



  document.getElementById("btn-import-sub").onclick = handleImportWallet;



  document.getElementById("btn-reset").onclick = handleResetVault;







  document.getElementById("btn-google-login").onclick = handleGoogleLogin;



  document.getElementById("btn-disconnect-google").onclick = handleGoogleDisconnect;



  document.getElementById("btn-drive-backup").onclick = handleDriveBackup;



  document.getElementById("btn-drive-restore").onclick = handleDriveRestore;







  document.getElementById("btn-unlock-reset").onclick = async () => {



    const ok = await LuxaUI.confirm({



      title: "Reset PIN?",



      desc: "If you forgot your PIN or password, you must remove the vault and re-import it using your secret words.<br><br><a href='https://luxaecosystem.xyz/support-recovery.html' target='_blank' style='color:#00FFCC;text-decoration:underline;font-weight:700;'>📖 View Step-by-Step Reset Guide ↗</a><br><br>Remove the vault now?",



      icon: "⚠️",



      confirmText: "Reset",



      cancelText: "Cancel"



    });



    if (ok) {



      chrome.storage.local.remove(["luxa_vault", "luxa_vaults", "active_wallet_idx", "is_unlocked"], () => {



        broadcastVaultState("BROADCAST_VAULT_LOCKED");



        showNoWalletScreen();



      });



    }



  };







  document.getElementById("btn-settings").onclick = () => {



    viewDashboard.style.display = "none";



    if (viewSettings) {



      viewSettings.style.display = "block";



      updateGoogleSettingsUI();

      setupBiometricSettings();

      renderConnectedSitesSettings();



      const nameInput = document.getElementById("settings-wallet-name");



      if (nameInput && vaults[activeIndex]) nameInput.value = vaults[activeIndex].name || "";



      const currSelect = document.getElementById("settings-currency");



      if (currSelect) currSelect.value = activeCurrency;



    }



  };







  document.getElementById("btn-back-from-settings").onclick = () => showDashboard();







  document.getElementById("btn-save-wallet-name").onclick = () => {



    const nameInput = document.getElementById("settings-wallet-name");



    const newName = nameInput.value.trim();



    if (!newName) return LuxaUI.alert({ title: "Name Required", desc: "Enter a valid name.", icon: "⚠️" });







    vaults[activeIndex].name = newName;



    chrome.storage.local.set({ luxa_vaults: vaults, luxa_vault: vaults[activeIndex] }, () => {



      LuxaUI.toast("Vault name saved!", "✓");



      showDashboard();



    });



  };







  const _currEl = document.getElementById("settings-currency");



  if (_currEl) _currEl.onchange = (e) => {



    activeCurrency = e.target.value;
    chrome.storage.local.set({ luxa_currency: activeCurrency }, () => {
      LuxaUI.toast(`Currency set to ${activeCurrency}`, "💱");
      const usdEl = document.getElementById("main-luxa-usd");
      if (usdEl) {
        const symbol = CURRENCY_SYMBOLS[activeCurrency] || "$";
        usdEl.innerHTML = `≈ ${symbol}-.-- ${activeCurrency} <span class="usd-pending-tag">pre-listing</span>`;
      }
      updatePortfolioTotalUI();
      const currentVault = vaults[activeIndex];
      if (currentVault) renderTokensList(currentVault.address);
    });



  };







  // --- PIN UNLOCK LOGIC ---



  async function handleUnlock() {



    const pin = unlockPinInput.value;



    const cur = vaults[activeIndex];



    try {



      await decryptMnemonic(cur.encrypted, pin);



      if (window.LuxaBiometric) {



        window.LuxaBiometric.isAvailable().then(info => {



          if (info && info.available && !info.hasCredentials) {



            window.LuxaBiometric.setCredentials(pin).then(() => {



              localStorage.setItem("luxa_bio_enabled", "true");



              checkBiometricAvailability(false);



            }).catch(() => {});



          }



        }).catch(() => {});



      }



      chrome.storage.local.set({ is_unlocked: true, last_activity: Date.now() }, () => {



        broadcastVaultState("BROADCAST_VAULT_UNLOCKED", cur.address);



        broadcastVaultState("VAULT_READY_BROADCAST", cur.address);



        LuxaUI.toast(`Vault ${cur.name} unlocked!`, "🔓");



        if (window._pendingConnectRequest) {



          const req = window._pendingConnectRequest;



          window._pendingConnectRequest = null;



          if (typeof window.handleLuxaConnectRequest === "function") {



            window.handleLuxaConnectRequest(req);



            return;



          }



        }



        showDashboard();



      });



    } catch (_) {



      unlockError.textContent = "Incorrect PIN. Access denied.";



      unlockError.style.display = "block";



      unlockPinInput.value = "";



      unlockPinInput.focus();



    }



  }







  document.getElementById("btn-unlock-submit").onclick = handleUnlock;



  unlockPinInput.addEventListener("keydown", (e) => { if (e.key === "Enter") handleUnlock(); });







  function switchVaultToken(token, chainOrigin = null, customBal = null) {
    currentSelectedToken = (token || 'luxa').toLowerCase();
    currentSelectedChain = chainOrigin || 'LUXA Network';
    const isLuxa = currentSelectedToken.startsWith('luxa');
    const isShards = currentSelectedToken === 'shards' || currentSelectedToken === 'shard';
    const isIbc = IBC_ASSETS_MAP[currentSelectedToken.toUpperCase()];

    const isFromExternal = Boolean(currentSelectedChain && (
      currentSelectedChain.toLowerCase().includes('cosmos') ||
      currentSelectedChain.toLowerCase().includes('celestia') ||
      currentSelectedChain.toLowerCase().includes('osmosis') ||
      currentSelectedChain.toLowerCase().includes('noble')
    ));

    let balance = customBal || vaultBalances[currentSelectedToken] || (isLuxa ? vaultBalances.luxa : isShards ? vaultBalances.shards : '0');
    let symbol = isIbc ? currentSelectedToken.toUpperCase() : (isLuxa ? 'LUXA' : 'SHARD');
    let chainName = currentSelectedChain;

    if (currentSelectedToken === 'atom') {
      balance = isFromExternal ? (multiChainHoldings.external_natives.atom || '0.000000') : (vaultBalances.atom || '0.000000');
    }
    if (currentSelectedToken === 'tia') {
      balance = isFromExternal ? (multiChainHoldings.external_natives.tia || '0.000000') : (vaultBalances.tia || '0.000000');
    }
    if (currentSelectedToken === 'osmo') {
      balance = isFromExternal ? (multiChainHoldings.external_natives.osmo || '0.000000') : (vaultBalances.osmo || '0.000000');
    }
    if (currentSelectedToken === 'usdc') {
      balance = isFromExternal ? (multiChainHoldings.external_natives.usdc || '0.000000') : (vaultBalances.usdc || '0.000000');
    }

    // Update Asset Selector Card
    const symEl = document.getElementById('send-selected-symbol');
    const chainEl = document.getElementById('send-selected-chain');
    const iconEl = document.getElementById('send-selected-icon');
    const fiatEl = document.getElementById('send-selected-fiat');
    const dispBal = document.getElementById('extDisplayBalance');

    if (symEl) symEl.textContent = symbol;
    if (chainEl) chainEl.textContent = chainName;
    if (fiatEl) fiatEl.textContent = `≈ ${formatFiatValue(balance, symbol)} USD`;
    if (dispBal) dispBal.textContent = `${balance} ${symbol}`;

    if (iconEl) {
      if (isLuxa) iconEl.src = '../icons/logoluxa.png';
      else if (isShards) iconEl.src = '../icons/shard128.png';
      else if (symbol === 'TIA') iconEl.src = 'https://raw.githubusercontent.com/cosmos/chain-registry/master/celestia/images/celestia.png';
      else if (symbol === 'USDC' || symbol === 'USDC.N') iconEl.src = 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png';
      else if (symbol === 'ATOM') iconEl.src = 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.png';
      else if (symbol === 'OSMO') iconEl.src = 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/osmo.png';
    }

    const fee = document.getElementById('extFeeDisplay');
    if (fee) {
      if (isFromExternal && currentSelectedChain.toLowerCase().includes('cosmos')) {
        fee.textContent = '0.005000 ATOM (Cosmos Hub Gas)';
      } else if (isFromExternal && currentSelectedChain.toLowerCase().includes('celestia')) {
        fee.textContent = '0.005000 TIA (Celestia Gas)';
      } else if (isFromExternal && currentSelectedChain.toLowerCase().includes('osmosis')) {
        fee.textContent = '0.006000 OSMO (Osmosis Gas)';
      } else if (isFromExternal && currentSelectedChain.toLowerCase().includes('noble')) {
        fee.textContent = '0.005000 USDC (Noble Gas)';
      } else {
        fee.textContent = '0.000200 LUXA';
      }
    }

    const amount = document.getElementById('extAmountInput');
    if (amount) amount.value = '';

    const recipient = document.getElementById('extRecipientInput');
    if (recipient) {
      if (isFromExternal) {
        // Automatically default recipient to the active LUXA wallet address!
        recipient.value = vaults[activeIndex]?.address || '';
        recipient.placeholder = 'luxa1... (Your LUXA destination address)';
      } else if (symbol === 'TIA' || chainName.toLowerCase().includes('celestia')) {
        recipient.placeholder = 'celestia1... (Celestia) or luxa1... (IBC)';
      } else if (symbol === 'ATOM' || chainName.toLowerCase().includes('cosmos')) {
        recipient.placeholder = 'cosmos1... (Cosmos Hub) or luxa1... (IBC)';
      } else if (symbol === 'OSMO' || chainName.toLowerCase().includes('osmosis')) {
        recipient.placeholder = 'osmo1... (Osmosis) or luxa1... (IBC)';
      } else if (symbol === 'USDC' || chainName.toLowerCase().includes('noble')) {
        recipient.placeholder = 'noble1... (Noble) or luxa1... (IBC)';
      } else {
        recipient.placeholder = 'luxa1... (LUXA Network) or IBC address';
      }
    }
  }

  function openAssetSelectorModal() {
    const modal = document.getElementById('asset-selector-modal');
    if (!modal) return;
    modal.style.display = 'flex';

    const closeBtn = document.getElementById('btn-close-asset-selector');
    if (closeBtn) closeBtn.onclick = () => { modal.style.display = 'none'; };

    const searchInput = document.getElementById('input-search-asset');
    if (searchInput) searchInput.value = '';

    const listContainer = document.getElementById('asset-selector-list');
    if (!listContainer) return;

    // Build the list of selectable assets (Keplr Screenshot 5 style)
    const assets = [
      {
        symbol: 'ATOM',
        token: 'atom',
        name: 'ATOM',
        chain: 'Cosmos Hub',
        balance: multiChainHoldings.external_natives.atom || '0.000000',
        icon: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.png'
      },
      {
        symbol: 'TIA',
        token: 'tia',
        name: 'TIA',
        chain: 'Celestia',
        balance: multiChainHoldings.external_natives.tia || '0.000000',
        icon: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/celestia/images/celestia.png'
      },
      {
        symbol: 'OSMO',
        token: 'osmo',
        name: 'OSMO',
        chain: 'Osmosis',
        balance: multiChainHoldings.external_natives.osmo || '0.000000',
        icon: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/osmo.png'
      },
      {
        symbol: 'USDC.n',
        token: 'usdc',
        name: 'USDC',
        chain: 'Noble',
        balance: multiChainHoldings.external_natives.usdc || '0.000000',
        icon: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png'
      },
      {
        symbol: 'LUXA',
        token: 'luxa',
        name: 'LUXA',
        chain: 'LUXA Network',
        balance: (parseFloat(vaultBalances.luxa || 0)).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
        icon: '../icons/logoluxa.png'
      },
      {
        symbol: 'SHARD',
        token: 'shards',
        name: 'SHARD',
        chain: 'LUXA Network',
        balance: (parseFloat(vaultBalances.shards || 0)).toLocaleString('en-US'),
        icon: '../icons/shard128.png'
      },
      {
        symbol: 'LUXA',
        token: 'luxa',
        name: 'LUXA (Cosmos Hub)',
        chain: 'on Cosmos Hub [IBC]',
        balance: multiChainHoldings.luxa_external.cosmoshub || '0.000000',
        icon: '../icons/icon128.png'
      },
      {
        symbol: 'LUXA',
        token: 'luxa',
        name: 'LUXA (Celestia)',
        chain: 'on Celestia [IBC]',
        balance: multiChainHoldings.luxa_external.celestia || '0.000000',
        icon: '../icons/icon128.png'
      },
      {
        symbol: 'LUXA',
        token: 'luxa',
        name: 'LUXA (Osmosis)',
        chain: 'on Osmosis [IBC]',
        balance: multiChainHoldings.luxa_external.osmosis || '0.000000',
        icon: '../icons/icon128.png'
      },
      {
        symbol: 'LUXA',
        token: 'luxa',
        name: 'LUXA (Noble)',
        chain: 'on Noble [IBC]',
        balance: multiChainHoldings.luxa_external.noble || '0.000000',
        icon: '../icons/icon128.png'
      }
    ];

    function renderList(query = '') {
      listContainer.replaceChildren();
      const q = query.trim().toLowerCase();
      const filtered = assets.filter(a => !q || a.symbol.toLowerCase().includes(q) || a.chain.toLowerCase().includes(q));

      filtered.forEach(item => {
        const row = document.createElement('div');
        row.style.display = 'flex';
        row.style.alignItems = 'center';
        row.style.justifyContent = 'space-between';
        row.style.padding = '10px 12px';
        row.style.background = 'rgba(255, 255, 255, 0.03)';
        row.style.border = '1px solid rgba(255, 255, 255, 0.08)';
        row.style.borderRadius = '12px';
        row.style.cursor = 'pointer';
        row.style.transition = 'all 0.15s ease';

        row.onmouseover = () => { row.style.background = 'rgba(0, 255, 204, 0.06)'; row.style.borderColor = 'rgba(0, 255, 204, 0.3)'; };
        row.onmouseout = () => { row.style.background = 'rgba(255, 255, 255, 0.03)'; row.style.borderColor = 'rgba(255, 255, 255, 0.08)'; };

        const left = document.createElement('div');
        left.style.display = 'flex';
        left.style.alignItems = 'center';
        left.style.gap = '10px';

        const img = document.createElement('img');
        img.src = item.icon;
        img.style.width = '30px';
        img.style.height = '30px';
        img.style.borderRadius = '50%';
        img.style.objectFit = 'contain';

        const meta = document.createElement('div');
        meta.style.textAlign = 'left';

        const sym = document.createElement('div');
        sym.style.fontSize = '13.5px';
        sym.style.fontWeight = '700';
        sym.style.color = '#fff';
        sym.textContent = item.symbol;

        const ch = document.createElement('div');
        ch.style.fontSize = '10.5px';
        ch.style.color = '#94a3b8';
        ch.textContent = item.chain;

        meta.append(sym, ch);
        left.append(img, meta);

        const right = document.createElement('div');
        right.style.textAlign = 'right';

        const bal = document.createElement('div');
        bal.style.fontSize = '13px';
        bal.style.fontWeight = '700';
        bal.style.color = '#fff';
        bal.style.fontFamily = 'var(--font-mono)';
        bal.textContent = item.balance;

        const fiat = document.createElement('div');
        fiat.style.fontSize = '10.5px';
        fiat.style.color = '#94a3b8';
        fiat.textContent = formatFiatValue(item.balance, item.name);

        right.append(bal, fiat);
        row.append(left, right);

        row.onclick = () => {
          switchVaultToken(item.token, item.chain, item.balance);
          modal.style.display = 'none';
        };

        listContainer.appendChild(row);
      });
    }

    renderList();
    if (searchInput) {
      searchInput.oninput = () => renderList(searchInput.value);
    }
  }

  function handleMaxClick() {
    const chLower = String(currentSelectedChain || '').toLowerCase();
    if (chLower.includes('cosmos') && currentSelectedToken === 'atom') {
      const bal = parseFloat(multiChainHoldings.external_natives.atom || 0);
      const safeMax = Math.max(0, bal - 0.005);
      const amount = document.getElementById("extAmountInput");
      if (amount) amount.value = safeMax > 0 ? safeMax.toFixed(6) : "0.000000";
      return;
    }
    const rawBalance = parseFloat(vaultBalances[currentSelectedToken]) || 0;
    const maxSendable = currentSelectedToken === "luxa" ? Math.max(0, rawBalance - 0.0002) : rawBalance;
    const amount = document.getElementById("extAmountInput");
    if (amount) amount.value = currentSelectedToken === "luxa" ? maxSendable.toFixed(6) : (currentSelectedToken === "atom" ? maxSendable.toFixed(6) : String(Math.floor(maxSendable)));
  }







  function checkCurrentTabConnection() {



    const bar = document.getElementById("site-connection-bar");



    const siteLabel = document.getElementById("connected-site-name");



    const btnAction = document.getElementById("btn-quick-disconnect-site");



    if (!bar || !siteLabel || !btnAction) return;







    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {



      if (!tabs || !tabs[0] || !tabs[0].url) { bar.style.display = "none"; return; }



      try {



        const url = new URL(tabs[0].url);



        if (!url.protocol.startsWith("http")) { bar.style.display = "none"; return; }



        const origin = url.origin;



        const host = url.hostname;







        chrome.storage.local.get(["approved_origins", "connected_sites", "white_card_authorized", "luxa_vault"], (data) => {



          const approved = Array.from(new Set([...(data.approved_origins || []), ...(data.connected_sites || [])]));



          const hasWhiteCard = Boolean(data.white_card_authorized) || approved.includes("*.luxaecosystem.xyz");



          const isEcosystemHost = host === "luxaecosystem.xyz" || host.endsWith(".luxaecosystem.xyz");



          const isApproved = approved.includes(origin) || (hasWhiteCard && isEcosystemHost);
          if (!isApproved) { bar.style.display = "none"; return; }



          bar.style.display = "flex";



          siteLabel.textContent = isApproved && hasWhiteCard && isEcosystemHost ? `${host} (White Card)` : host;







          if (isApproved) {



            btnAction.textContent = "Revoke ✕";



            btnAction.className = "btn-quick-disconnect";



            btnAction.onclick = () => {



              const updatedApproved = (data.approved_origins || []).filter(e => e !== origin);



              const updatedConnected = (data.connected_sites || []).filter(e => e !== origin);



              const patch = { approved_origins: updatedApproved, connected_sites: updatedConnected };



              if (hasWhiteCard && isEcosystemHost) {



                patch.white_card_authorized = false;



              }



              chrome.storage.local.set(patch, () => {



                LuxaUI.toast(`Revoked for ${host}`, "🔒");



                checkCurrentTabConnection();



                renderConnectedSitesSettings();



                broadcastVaultState("BROADCAST_VAULT_REVOKED", null, origin);



              });



            };



          } else {



            btnAction.textContent = "Connect";



            btnAction.className = "btn-quick-connect";



            btnAction.onclick = () => {



              const newApproved = Array.from(new Set([...(data.approved_origins || []), origin]));



              const newConnected = Array.from(new Set([...(data.connected_sites || []), origin]));



              chrome.storage.local.set({ approved_origins: newApproved, connected_sites: newConnected }, () => {



                LuxaUI.toast(`Connected to ${host}!`, "⚡");



                checkCurrentTabConnection();



                renderConnectedSitesSettings();



                if (data.luxa_vault?.address) {



                  broadcastVaultState("BROADCAST_VAULT_UNLOCKED", data.luxa_vault.address);



                  broadcastVaultState("VAULT_READY_BROADCAST", data.luxa_vault.address);



                }



              });



            };



          }



        });



      } catch (_) { bar.style.display = "none"; }



    });



  }







  async function loadWalletNfts(address) {



    const summarySub = document.getElementById("nft-summary-count");



    if (summarySub) summarySub.textContent = "Querying ledger…";



    try {



      const res = await fetch(`${BACKEND_API}/ecosystem/vault/registered-nfts-public/${encodeURIComponent(address)}`);



      const data = await res.json();



      const registered = (data && data.success && Array.isArray(data.registered)) ? data.registered : [];



      window._walletNftsCache = registered;



      if (tabContentNfts && tabContentNfts.style.display !== "none") {



        renderNftVaultList(registered);



      }



      if (summarySub) {



        summarySub.textContent = registered.length



          ? `${registered.length} Genesis Relic${registered.length > 1 ? "s" : ""} anchored`



          : "No relics owned";



      }



    } catch (_) {



      window._walletNftsCache = [];



      if (summarySub) summarySub.textContent = "Ledger unreachable";



    }



  }







  function formatTokenUnits(rawAmount, decimals) {



    const str = String(rawAmount || "0").replace(/[^0-9]/g, "");



    if (!str || str === "0") return "0";



    const dec = Number.isInteger(decimals) && decimals >= 0 ? decimals : 6;



    if (dec === 0) return str;



    const padded = str.padStart(dec + 1, "0");



    const whole = padded.slice(0, -dec);



    const frac = padded.slice(-dec).replace(/0+$/, "");



    return frac ? `${whole}.${frac}` : whole;



  }







  async function fetchOfficialTokenRegistry() {



    if (officialTokenRegistry) return officialTokenRegistry;



    if (officialTokenRegistryRequest) return officialTokenRegistryRequest;







    officialTokenRegistryRequest = (async () => {



      try {



        const response = await fetch(OFFICIAL_TOKEN_REGISTRY_URL, { cache: "no-cache" });



        if (!response.ok) throw new Error(`HTTP ${response.status}`);







        const data = await response.json();



        if (!data || data.chain_id !== "luxa-1" || !Array.isArray(data.tokens)) {



          throw new Error("Invalid LUXA token registry response.");



        }







        const registry = new Map();



        data.tokens.forEach((token) => {



          if (



            token?.chain_id !== "luxa-1" ||



            token?.type !== "cw20" ||



            typeof token.contract !== "string" ||



            typeof token.symbol !== "string" ||



            typeof token.logo !== "string"



          ) {



            return;



          }







          let logoUrl;



          try {



            logoUrl = new URL(token.logo);



          } catch {



            return;



          }



          if (logoUrl.protocol !== "https:") return;







          registry.set(token.contract.toLowerCase(), logoUrl.href);



          registry.set(token.symbol.toLowerCase(), logoUrl.href);



        });







        officialTokenRegistry = registry;



      } catch (error) {



        console.warn("[LUXA Vault] Unable to load official token logos:", error);



        officialTokenRegistry = new Map();



      } finally {



        officialTokenRegistryRequest = null;



      }



      return officialTokenRegistry;



    })();







    return officialTokenRegistryRequest;



  }







  async function resolveCustomTokenLogo(contractAddress, symbol) {



    const contract = String(contractAddress || "").trim().toLowerCase();



    const tokenSymbol = String(symbol || "").trim().toLowerCase();



    if (!contract) return null;



    if (customTokenLogoRequests.has(contract)) return customTokenLogoRequests.get(contract);







    const request = (async () => {



      const registry = await fetchOfficialTokenRegistry();



      const officialLogo = registry.get(contract) || registry.get(tokenSymbol);



      if (officialLogo) return officialLogo;







      try {



        const query = btoa(JSON.stringify({ marketing_info: {} }));



        const response = await fetch(



          `${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/contract/${encodeURIComponent(contractAddress)}/smart/${query}`,



          { cache: "no-store" }



        );



        if (!response.ok) return null;







        const result = await response.json();



        let marketingInfo = result?.data !== undefined ? result.data : result;



        if (typeof marketingInfo === "string") {



          try {



            marketingInfo = JSON.parse(marketingInfo);



          } catch {



            return null;



          }



        }







        const candidate = marketingInfo?.logo?.url;



        if (typeof candidate !== "string") return null;



        const logoUrl = new URL(candidate);



        return logoUrl.protocol === "https:" ? logoUrl.href : null;



      } catch (error) {



        console.warn(`[LUXA Vault] Unable to resolve logo for ${contract}:`, error);



        return null;



      }



    })();







    customTokenLogoRequests.set(contract, request);



    return request;



  }







  async function fetchOnChainTokenBalance(contractAddress, walletAddress, decimals) {



    if (!contractAddress || !walletAddress) return "0";



    const queries = [



      { balance: { address: walletAddress } },



      { balance_of: { who: walletAddress } },



      { get_balance: { account: walletAddress } }



    ];



    for (const q of queries) {



      try {



        const qB64 = btoa(JSON.stringify(q));



        const res = await fetch(



          `${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/contract/${encodeURIComponent(contractAddress)}/smart/${qB64}`,



          { cache: "no-store" }



        );



        if (res.ok) {



          const json = await res.json();



          let data = json?.data !== undefined ? json.data : json;



          if (typeof data === "string") {



            try { data = JSON.parse(data); } catch {}



          }



          if (typeof data === "object" && data !== null && data.balance !== undefined) {



            return formatTokenUnits(data.balance, decimals);



          }



          if (typeof data === "string" || typeof data === "number") {



            return formatTokenUnits(data, decimals);



          }



        }



      } catch (_) {}



    }



    return "0";



  }







  async function refreshCustomTokenBalances(walletAddress) {



    if (!walletAddress) return;



    const storageKey = `custom_tokens_${walletAddress}`;



    const stored = await new Promise((resolve) => chrome.storage.local.get([storageKey], resolve));



    const currentList = Array.isArray(stored[storageKey]) ? stored[storageKey] : [];



    if (!currentList.length) return;







    let hasUpdates = false;



    for (const token of currentList) {



      if (!token.contract) continue;



      try {



        const liveBal = await fetchOnChainTokenBalance(token.contract, walletAddress, token.decimals ?? 6);



        if (liveBal !== token.balance) {



          token.balance = liveBal;



          hasUpdates = true;



          const balEl = document.querySelector(`[data-token-contract="${token.contract}"] .mm-token-amount`);



          if (balEl) balEl.textContent = `${liveBal} ${token.symbol}`;



        }



      } catch (e) {



        console.warn("[LUXA Vault] Balance refresh failed for", token.symbol, e);



      }



    }



    if (hasUpdates) {



      await new Promise((resolve) => chrome.storage.local.set({ [storageKey]: currentList }, resolve));



    }



  }







    function createSingleTokenRow(token, walletAddress) {
    const row = document.createElement("div");
    row.className = "mm-token-row";
    row.tabIndex = 0;
    row.setAttribute("role", "button");

    const left = document.createElement("div");
    left.className = "mm-token-left";

    const iconWrapper = document.createElement("div");
    iconWrapper.className = "mm-token-icon-wrapper";
    const iconAvatar = document.createElement("div");
    iconAvatar.className = "mm-token-icon-avatar";

    if (token.icon) {
      const icon = document.createElement("img");
      icon.src = token.icon;
      icon.alt = "";
      icon.loading = "lazy";
      icon.onerror = () => { iconAvatar.textContent = token.symbol.slice(0, 3); };
      iconAvatar.appendChild(icon);
    } else {
      iconAvatar.textContent = token.symbol.slice(0, 3);
    }
    iconWrapper.appendChild(iconAvatar);

    const meta = document.createElement("div");
    meta.className = "mm-token-meta";
    const name = document.createElement("span");
    name.className = "mm-token-name";
    name.textContent = token.name;
    const sub = document.createElement("span");
    sub.className = "mm-token-sub";
    sub.textContent = token.sub;
    meta.append(name, sub);
    left.append(iconWrapper, meta);

    const right = document.createElement("div");
    right.className = "mm-token-right";
    const amount = document.createElement("span");
    amount.className = "mm-token-amount";
    amount.textContent = `${token.balance} ${token.symbol}`;
    const fiat = document.createElement("span");
    fiat.className = "mm-token-fiat";
    fiat.textContent = token.fiat || "-";
    right.append(amount, fiat);

    const actions = document.createElement("div");
    actions.className = "mm-token-actions";
    actions.appendChild(right);

    if (token.custom) {
      const removeButton = document.createElement("button");
      removeButton.type = "button";
      removeButton.className = "btn-remove-token";
      removeButton.title = "Hide / Remove token";
      removeButton.textContent = "🗑️";
      removeButton.onclick = (event) => {
        event.stopPropagation();
        deleteCustomToken(walletAddress, token.contract, token.symbol);
      };
      actions.appendChild(removeButton);
    }

    row.append(left, actions);

    row.onclick = (event) => {
      if (event.target.closest(".btn-remove-token")) return;
      showTokenDetail(token);
    };

    return row;
  }

  async function renderTokensList(walletAddress) {
    const container = document.getElementById("token-list-items");
    if (!container) return;

    const storageKey = `custom_tokens_${walletAddress}`;
    const stored = await new Promise((resolve) => chrome.storage.local.get([storageKey], resolve));
    const customTokens = Array.isArray(stored[storageKey]) ? stored[storageKey] : [];

    container.replaceChildren();

    // 1. MULTI-CHAIN LUXA ROW (SOVEREIGN L1)
    const luxaRow = document.createElement("div");
    luxaRow.className = "mm-token-row mm-token-row-multichain is-open";
    luxaRow.setAttribute("role", "button");

    const luxaLeft = document.createElement("div");
    luxaLeft.className = "mm-token-left";

    const luxaIconWrap = document.createElement("div");
    luxaIconWrap.className = "mm-token-icon-wrapper";
    const luxaAvatar = document.createElement("div");
    luxaAvatar.className = "mm-token-icon-avatar";
    const luxaImg = document.createElement("img");
    luxaImg.src = "../icons/logoluxa.png";
    luxaImg.alt = "LUXA";
    luxaAvatar.appendChild(luxaImg);
    luxaIconWrap.appendChild(luxaAvatar);

    const luxaMeta = document.createElement("div");
    luxaMeta.className = "mm-token-meta";
    const luxaNameRow = document.createElement("div");
    luxaNameRow.style.display = "flex";
    luxaNameRow.style.alignItems = "center";
    luxaNameRow.style.gap = "4px";

    const luxaName = document.createElement("span");
    luxaName.className = "mm-token-name";
    luxaName.textContent = "LUXA";

    const miniIcons = document.createElement("span");
    miniIcons.className = "mm-mini-chain-icons";
    miniIcons.innerHTML = `
      <img src="https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.png" class="mm-mini-chain-icon" title="Cosmos Hub" />
      <img src="https://raw.githubusercontent.com/cosmos/chain-registry/master/celestia/images/celestia.png" class="mm-mini-chain-icon" title="Celestia" />
      <span style="font-size:9.5px; color:#94a3b8; font-weight:700;">+2</span>
    `;

    const chevron = createChevronIcon();

    luxaNameRow.append(luxaName, miniIcons, chevron);
    const luxaSub = document.createElement("span");
    luxaSub.className = "mm-token-sub";
    luxaSub.innerHTML = `Native L1 <span class="dot-sep">&bull;</span> Multi-Chain IBC`;
    luxaMeta.append(luxaNameRow, luxaSub);
    luxaLeft.append(luxaIconWrap, luxaMeta);

    const luxaRight = document.createElement("div");
    luxaRight.className = "mm-token-right";
    const luxaAmount = document.createElement("span");
    luxaAmount.className = "mm-token-amount";
    const totalLuxa = (parseFloat(vaultBalances.luxa || 0) + 
      parseFloat(multiChainHoldings.luxa_external.cosmoshub || 0) + 
      parseFloat(multiChainHoldings.luxa_external.celestia || 0) + 
      parseFloat(multiChainHoldings.luxa_external.osmosis || 0) + 
      parseFloat(multiChainHoldings.luxa_external.noble || 0)).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    luxaAmount.textContent = totalLuxa;

    const luxaFiat = document.createElement("span");
    luxaFiat.className = "mm-token-fiat";
    luxaFiat.textContent = "-";
    luxaRight.append(luxaAmount, luxaFiat);

    luxaRow.append(luxaLeft, luxaRight);

    // LUXA Subcontainer (accordion)
    const luxaSubContainer = document.createElement("div");
    luxaSubContainer.className = "mm-multichain-subcontainer";

    const luxaBreakdown = [
      { label: "on Cosmos Hub", isIbc: true, balance: multiChainHoldings?.luxa_external?.cosmoshub ?? "0.000000" },
      { label: "on Celestia", isIbc: true, balance: multiChainHoldings?.luxa_external?.celestia ?? "0.000000" },
      { label: "on Noble", isIbc: true, balance: multiChainHoldings?.luxa_external?.noble ?? "0.000000" },
      { label: "on Osmosis", isIbc: true, balance: multiChainHoldings?.luxa_external?.osmosis ?? "0.000000" },
      { label: "on LUXA Network", isIbc: false, balance: (parseFloat(vaultBalances?.luxa || 0)).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) }
    ];

    luxaBreakdown.forEach(item => {
      const sRow = document.createElement("div");
      sRow.className = "mm-multichain-subrow";
      sRow.innerHTML = `
        <div class="subrow-left">
          <span class="subrow-chain-label">${item.label}</span>
          ${item.isIbc ? '<span class="subrow-ibc-badge">IBC</span>' : ''}
        </div>
        <div class="subrow-right">
          <div class="subrow-amount">${item.balance}</div>
          <div class="subrow-fiat">-</div>
        </div>
      `;
      sRow.onclick = (e) => {
        e.stopPropagation();
        pendingSendToken = 'luxa';
        const sendBtn = document.getElementById("btn-send");
        if (sendBtn) sendBtn.click();
        switchVaultToken('luxa', item.label, item.balance);
      };
      luxaSubContainer.appendChild(sRow);
    });

    luxaRow.onclick = () => {
      const isOpen = luxaRow.classList.toggle("is-open");
      luxaSubContainer.style.display = isOpen ? "flex" : "none";
      chevron.textContent = isOpen ? "▲" : "▼";
    };

    container.appendChild(luxaRow);
    container.appendChild(luxaSubContainer);

    // 2. SHARD (Utility)
    const shardRow = createSingleTokenRow({
      name: "SHARD",
      symbol: "SHARD",
      balance: (parseFloat(vaultBalances.shards || 0)).toLocaleString("en-US"),
      icon: "../icons/shard128.png",
      sub: "LUXA Network • Utility Token",
      fiat: "-"
    }, walletAddress);
    container.appendChild(shardRow);

    // 3. ATOM (Cosmos Hub Multi-Chain Accordion)
    const atomExtBal = multiChainHoldings.external_natives.atom || "0.000000";
    const atomLuxaBal = vaultBalances.atom || "0.000000";
    const totalAtomNum = parseFloat(atomExtBal) + parseFloat(atomLuxaBal);
    const totalAtom = totalAtomNum > 0 ? totalAtomNum.toFixed(6) : "0.000000";

    const atomRow = document.createElement("div");
    atomRow.className = "mm-token-row mm-token-row-multichain is-open";
    atomRow.setAttribute("role", "button");

    const atomLeft = document.createElement("div");
    atomLeft.className = "mm-token-left";
    const atomIconWrap = document.createElement("div");
    atomIconWrap.className = "mm-token-icon-wrapper";
    const atomAvatar = document.createElement("div");
    atomAvatar.className = "mm-token-icon-avatar";
    const atomImg = document.createElement("img");
    atomImg.src = "https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.png";
    atomImg.alt = "ATOM";
    atomAvatar.appendChild(atomImg);
    atomIconWrap.appendChild(atomAvatar);

    const atomMeta = document.createElement("div");
    atomMeta.className = "mm-token-meta";
    const atomNameRow = document.createElement("div");
    atomNameRow.style.display = "flex";
    atomNameRow.style.alignItems = "center";
    atomNameRow.style.gap = "4px";

    const atomName = document.createElement("span");
    atomName.className = "mm-token-name";
    atomName.textContent = "ATOM";

    const atomPerf = createPerfBadge("atom");

    const atomMini = document.createElement("span");
    atomMini.className = "mm-mini-chain-icons";
    atomMini.innerHTML = `
      <img src="https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.png" class="mm-mini-chain-icon" title="Cosmos Hub" />
      <img src="../icons/logoluxa.png" class="mm-mini-chain-icon" title="LUXA Network" />
    `;

    const atomChevron = createChevronIcon();

    atomNameRow.append(atomName, atomPerf, atomMini, atomChevron);
    const atomSub = document.createElement("span");
    atomSub.className = "mm-token-sub";
    atomSub.innerHTML = `Cosmos Hub <span class="dot-sep">&bull;</span> Multi-Chain IBC`;
    atomMeta.append(atomNameRow, atomSub);
    atomLeft.append(atomIconWrap, atomMeta);

    const atomRight = document.createElement("div");
    atomRight.className = "mm-token-right";
    const atomAmount = document.createElement("span");
    atomAmount.className = "mm-token-amount";
    atomAmount.textContent = totalAtom;
    const atomFiat = document.createElement("span");
    atomFiat.className = "mm-token-fiat";
    atomFiat.textContent = formatFiatValue(totalAtom, "ATOM");
    atomRight.append(atomAmount, atomFiat);

    atomRow.append(atomLeft, atomRight);

    const atomSubContainer = document.createElement("div");
    atomSubContainer.className = "mm-multichain-subcontainer";

    const atomBreakdown = [
      { label: "on Cosmos Hub", isIbc: false, balance: atomExtBal, fiat: formatFiatValue(atomExtBal, "ATOM") },
      { label: "on LUXA Network", isIbc: true, balance: atomLuxaBal, fiat: formatFiatValue(atomLuxaBal, "ATOM") }
    ];

    atomBreakdown.forEach(item => {
      const sRow = document.createElement("div");
      sRow.className = "mm-multichain-subrow";
      sRow.innerHTML = `
        <div class="subrow-left">
          <span class="subrow-chain-label">${item.label}</span>
          ${item.isIbc ? '<span class="subrow-ibc-badge">IBC</span>' : ''}
        </div>
        <div class="subrow-right">
          <div class="subrow-amount">${item.balance}</div>
          <div class="subrow-fiat">${item.fiat}</div>
        </div>
      `;
      sRow.onclick = (e) => {
        e.stopPropagation();
        pendingSendToken = 'atom';
        const sendBtn = document.getElementById("btn-send");
        if (sendBtn) sendBtn.click();
        switchVaultToken('atom', item.label, item.balance);
      };
      atomSubContainer.appendChild(sRow);
    });

    atomRow.onclick = () => {
      const isOpen = atomRow.classList.toggle("is-open");
      atomSubContainer.style.display = isOpen ? "flex" : "none";
      // handled by CSS rotation
    };

    container.appendChild(atomRow);
    container.appendChild(atomSubContainer);

    // 4. TIA (Celestia Multi-Chain)
    const tiaExtBal = multiChainHoldings.external_natives.tia || "0.000000";
    const tiaLuxaBal = vaultBalances.tia || "0.000000";
    const totalTiaNum = parseFloat(tiaExtBal) + parseFloat(tiaLuxaBal);
    const totalTia = totalTiaNum > 0 ? totalTiaNum.toFixed(6) : "0.000000";

    const tiaRow = document.createElement("div");
    tiaRow.className = "mm-token-row mm-token-row-multichain is-open";
    tiaRow.setAttribute("role", "button");

    const tiaLeft = document.createElement("div");
    tiaLeft.className = "mm-token-left";
    const tiaIconWrap = document.createElement("div");
    tiaIconWrap.className = "mm-token-icon-wrapper";
    const tiaAvatar = document.createElement("div");
    tiaAvatar.className = "mm-token-icon-avatar";
    const tiaImg = document.createElement("img");
    tiaImg.src = "https://raw.githubusercontent.com/cosmos/chain-registry/master/celestia/images/celestia.png";
    tiaImg.alt = "TIA";
    tiaAvatar.appendChild(tiaImg);
    tiaIconWrap.appendChild(tiaAvatar);

    const tiaMeta = document.createElement("div");
    tiaMeta.className = "mm-token-meta";
    const tiaNameRow = document.createElement("div");
    tiaNameRow.style.display = "flex";
    tiaNameRow.style.alignItems = "center";
    tiaNameRow.style.gap = "4px";

    const tiaName = document.createElement("span");
    tiaName.className = "mm-token-name";
    tiaName.textContent = "TIA";

    const tiaPerf = createPerfBadge("tia");

    const tiaMini = document.createElement("span");
    tiaMini.className = "mm-mini-chain-icons";
    tiaMini.innerHTML = `
      <img src="https://raw.githubusercontent.com/cosmos/chain-registry/master/celestia/images/celestia.png" class="mm-mini-chain-icon" title="Celestia" />
      <img src="../icons/logoluxa.png" class="mm-mini-chain-icon" title="LUXA Network" />
    `;

    const tiaChevron = createChevronIcon();

    tiaNameRow.append(tiaName, tiaPerf, tiaMini, tiaChevron);
    const tiaSub = document.createElement("span");
    tiaSub.className = "mm-token-sub";
    tiaSub.innerHTML = `Celestia <span class="dot-sep">&bull;</span> Multi-Chain IBC`;
    tiaMeta.append(tiaNameRow, tiaSub);
    tiaLeft.append(tiaIconWrap, tiaMeta);

    const tiaRight = document.createElement("div");
    tiaRight.className = "mm-token-right";
    const tiaAmount = document.createElement("span");
    tiaAmount.className = "mm-token-amount";
    tiaAmount.textContent = totalTia;
    const tiaFiat = document.createElement("span");
    tiaFiat.className = "mm-token-fiat";
    tiaFiat.textContent = formatFiatValue(totalTia, "TIA");
    tiaRight.append(tiaAmount, tiaFiat);

    tiaRow.append(tiaLeft, tiaRight);

    const tiaSubContainer = document.createElement("div");
    tiaSubContainer.className = "mm-multichain-subcontainer";

    const tiaBreakdown = [
      { label: "on Celestia", isIbc: false, balance: tiaExtBal, fiat: formatFiatValue(tiaExtBal, "TIA") },
      { label: "on LUXA Network", isIbc: true, balance: tiaLuxaBal, fiat: formatFiatValue(tiaLuxaBal, "TIA") }
    ];

    tiaBreakdown.forEach(item => {
      const sRow = document.createElement("div");
      sRow.className = "mm-multichain-subrow";
      sRow.innerHTML = `
        <div class="subrow-left">
          <span class="subrow-chain-label">${item.label}</span>
          ${item.isIbc ? '<span class="subrow-ibc-badge">IBC</span>' : ''}
        </div>
        <div class="subrow-right">
          <div class="subrow-amount">${item.balance}</div>
          <div class="subrow-fiat">${item.fiat}</div>
        </div>
      `;
      sRow.onclick = (e) => {
        e.stopPropagation();
        pendingSendToken = 'tia';
        const sendBtn = document.getElementById("btn-send");
        if (sendBtn) sendBtn.click();
        switchVaultToken('tia', item.label, item.balance);
      };
      tiaSubContainer.appendChild(sRow);
    });

    tiaRow.onclick = () => {
      const isOpen = tiaRow.classList.toggle("is-open");
      tiaSubContainer.style.display = isOpen ? "flex" : "none";
      // handled by CSS rotation
    };

    container.appendChild(tiaRow);
    container.appendChild(tiaSubContainer);

    // 5. OSMO (Osmosis Multi-Chain Accordion)
    const osmoExtBal = multiChainHoldings.external_natives.osmo || "0.000000";
    const osmoLuxaBal = vaultBalances.osmo || "0.000000";
    const totalOsmoNum = parseFloat(osmoExtBal) + parseFloat(osmoLuxaBal);
    const totalOsmo = totalOsmoNum > 0 ? totalOsmoNum.toFixed(6) : "0.000000";

    const osmoRow = document.createElement("div");
    osmoRow.className = "mm-token-row mm-token-row-multichain is-open";
    osmoRow.setAttribute("role", "button");

    const osmoLeft = document.createElement("div");
    osmoLeft.className = "mm-token-left";
    const osmoIconWrap = document.createElement("div");
    osmoIconWrap.className = "mm-token-icon-wrapper";
    const osmoAvatar = document.createElement("div");
    osmoAvatar.className = "mm-token-icon-avatar";
    const osmoImg = document.createElement("img");
    osmoImg.src = "https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/osmo.png";
    osmoImg.alt = "OSMO";
    osmoAvatar.appendChild(osmoImg);
    osmoIconWrap.appendChild(osmoAvatar);

    const osmoMeta = document.createElement("div");
    osmoMeta.className = "mm-token-meta";
    const osmoNameRow = document.createElement("div");
    osmoNameRow.style.display = "flex";
    osmoNameRow.style.alignItems = "center";
    osmoNameRow.style.gap = "4px";

    const osmoName = document.createElement("span");
    osmoName.className = "mm-token-name";
    osmoName.textContent = "OSMO";

    const osmoPerf = createPerfBadge("osmo");

    const osmoMini = document.createElement("span");
    osmoMini.className = "mm-mini-chain-icons";
    osmoMini.innerHTML = `
      <img src="https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/osmo.png" class="mm-mini-chain-icon" title="Osmosis" />
      <img src="../icons/logoluxa.png" class="mm-mini-chain-icon" title="LUXA Network" />
    `;

    const osmoChevron = createChevronIcon();

    osmoNameRow.append(osmoName, osmoPerf, osmoMini, osmoChevron);
    const osmoSub = document.createElement("span");
    osmoSub.className = "mm-token-sub";
    osmoSub.innerHTML = `Osmosis <span class="dot-sep">&bull;</span> Multi-Chain IBC`;
    osmoMeta.append(osmoNameRow, osmoSub);
    osmoLeft.append(osmoIconWrap, osmoMeta);

    const osmoRight = document.createElement("div");
    osmoRight.className = "mm-token-right";
    const osmoAmount = document.createElement("span");
    osmoAmount.className = "mm-token-amount";
    osmoAmount.textContent = totalOsmo;
    const osmoFiat = document.createElement("span");
    osmoFiat.className = "mm-token-fiat";
    osmoFiat.textContent = formatFiatValue(totalOsmo, "OSMO");
    osmoRight.append(osmoAmount, osmoFiat);

    osmoRow.append(osmoLeft, osmoRight);

    const osmoSubContainer = document.createElement("div");
    osmoSubContainer.className = "mm-multichain-subcontainer";

    const osmoBreakdown = [
      { label: "on Osmosis", isIbc: false, balance: osmoExtBal, fiat: formatFiatValue(osmoExtBal, "OSMO") },
      { label: "on LUXA Network", isIbc: true, balance: osmoLuxaBal, fiat: formatFiatValue(osmoLuxaBal, "OSMO") }
    ];

    osmoBreakdown.forEach(item => {
      const sRow = document.createElement("div");
      sRow.className = "mm-multichain-subrow";
      sRow.innerHTML = `
        <div class="subrow-left">
          <span class="subrow-chain-label">${item.label}</span>
          ${item.isIbc ? '<span class="subrow-ibc-badge">IBC</span>' : ''}
        </div>
        <div class="subrow-right">
          <div class="subrow-amount">${item.balance}</div>
          <div class="subrow-fiat">${item.fiat}</div>
        </div>
      `;
      sRow.onclick = (e) => {
        e.stopPropagation();
        pendingSendToken = 'osmo';
        const sendBtn = document.getElementById("btn-send");
        if (sendBtn) sendBtn.click();
        switchVaultToken('osmo', item.label, item.balance);
      };
      osmoSubContainer.appendChild(sRow);
    });

    osmoRow.onclick = () => {
      const isOpen = osmoRow.classList.toggle("is-open");
      osmoSubContainer.style.display = isOpen ? "flex" : "none";
      // handled by CSS rotation
    };

    container.appendChild(osmoRow);
    container.appendChild(osmoSubContainer);

    // 6. USDC.n (Noble Multi-Chain Accordion)
    const usdcExtBal = multiChainHoldings.external_natives.usdc || "0.000000";
    const usdcLuxaBal = vaultBalances.usdc || "0.000000";
    const totalUsdcNum = parseFloat(usdcExtBal) + parseFloat(usdcLuxaBal);
    const totalUsdc = totalUsdcNum > 0 ? totalUsdcNum.toFixed(6) : "0.000000";

    const usdcRow = document.createElement("div");
    usdcRow.className = "mm-token-row mm-token-row-multichain is-open";
    usdcRow.setAttribute("role", "button");

    const usdcLeft = document.createElement("div");
    usdcLeft.className = "mm-token-left";
    const usdcIconWrap = document.createElement("div");
    usdcIconWrap.className = "mm-token-icon-wrapper";
    const usdcAvatar = document.createElement("div");
    usdcAvatar.className = "mm-token-icon-avatar";
    const usdcImg = document.createElement("img");
    usdcImg.src = "../icons/usdc.png";
    usdcImg.alt = "USDC";
    usdcImg.onerror = () => {
      usdcImg.src = "https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png";
    };
    usdcAvatar.appendChild(usdcImg);
    usdcIconWrap.appendChild(usdcAvatar);

    const usdcMeta = document.createElement("div");
    usdcMeta.className = "mm-token-meta";
    const usdcNameRow = document.createElement("div");
    usdcNameRow.style.display = "flex";
    usdcNameRow.style.alignItems = "center";
    usdcNameRow.style.gap = "4px";

    const usdcName = document.createElement("span");
    usdcName.className = "mm-token-name";
    usdcName.textContent = "USDC.n";

    const usdcPerf = createPerfBadge("usdc");

    const usdcMini = document.createElement("span");
    usdcMini.className = "mm-mini-chain-icons";
    usdcMini.innerHTML = `
      <img src="https://raw.githubusercontent.com/cosmos/chain-registry/master/noble/images/stake.png" class="mm-mini-chain-icon" title="Noble" />
      <img src="../icons/logoluxa.png" class="mm-mini-chain-icon" title="LUXA Network" />
    `;

    const usdcChevron = createChevronIcon();

    usdcNameRow.append(usdcName, usdcPerf, usdcMini, usdcChevron);
    const usdcSub = document.createElement("span");
    usdcSub.className = "mm-token-sub";
    usdcSub.innerHTML = `Noble <span class="dot-sep">&bull;</span> Multi-Chain IBC`;
    usdcMeta.append(usdcNameRow, usdcSub);
    usdcLeft.append(usdcIconWrap, usdcMeta);

    const usdcRight = document.createElement("div");
    usdcRight.className = "mm-token-right";
    const usdcAmount = document.createElement("span");
    usdcAmount.className = "mm-token-amount";
    usdcAmount.textContent = totalUsdc;
    const usdcFiat = document.createElement("span");
    usdcFiat.className = "mm-token-fiat";
    usdcFiat.textContent = formatFiatValue(totalUsdc, "USDC");
    usdcRight.append(usdcAmount, usdcFiat);

    usdcRow.append(usdcLeft, usdcRight);

    const usdcSubContainer = document.createElement("div");
    usdcSubContainer.className = "mm-multichain-subcontainer";

    const usdcBreakdown = [
      { label: "on Noble", isIbc: false, balance: usdcExtBal, fiat: formatFiatValue(usdcExtBal, "USDC") },
      { label: "on LUXA Network", isIbc: true, balance: usdcLuxaBal, fiat: formatFiatValue(usdcLuxaBal, "USDC") }
    ];

    usdcBreakdown.forEach(item => {
      const sRow = document.createElement("div");
      sRow.className = "mm-multichain-subrow";
      sRow.innerHTML = `
        <div class="subrow-left">
          <span class="subrow-chain-label">${item.label}</span>
          ${item.isIbc ? '<span class="subrow-ibc-badge">IBC</span>' : ''}
        </div>
        <div class="subrow-right">
          <div class="subrow-amount">${item.balance}</div>
          <div class="subrow-fiat">${item.fiat}</div>
        </div>
      `;
      sRow.onclick = (e) => {
        e.stopPropagation();
        pendingSendToken = 'usdc';
        const sendBtn = document.getElementById("btn-send");
        if (sendBtn) sendBtn.click();
        switchVaultToken('usdc', item.label, item.balance);
      };
      usdcSubContainer.appendChild(sRow);
    });

    usdcRow.onclick = () => {
      const isOpen = usdcRow.classList.toggle("is-open");
      usdcSubContainer.style.display = isOpen ? "flex" : "none";
      // handled by CSS rotation
    };

    container.appendChild(usdcRow);
    container.appendChild(usdcSubContainer);

    // 7. Custom CW20 Tokens
    customTokens.forEach(token => {
      const cRow = createSingleTokenRow({
        name: token.name || token.symbol,
        symbol: token.symbol,
        balance: String(token.balance ?? "0"),
        icon: token.icon || token.logo || "",
        sub: token.contract ? (token.contract.length > 16 ? `${token.contract.slice(0, 8)}...${token.contract.slice(-4)}` : token.contract) : "CW20",
        fiat: "$0.00",
        custom: true,
        contract: token.contract
      }, walletAddress);
      container.appendChild(cRow);
    });

    if (customTokens.length > 0) {
      refreshCustomTokenBalances(walletAddress).catch(() => {});
    }
  }

  async function showTokenDetail(token) {



    hideAllViews();



    const detailView = document.getElementById("view-token-detail");



    if (!detailView) return;



    detailView.style.display = "block";







    const currentVault = vaults[activeIndex];



    const symbol = String(token.symbol || "TKN");



    const isNativeLuxa = symbol === "LUXA";



    const isShards = symbol === "SHARD";



    const isCustomCw20 = Boolean(token.custom);



    const tokenContract = String(token.contract || "");



    const tokenName = String(token.name || symbol);







    document.getElementById("detail-token-title").textContent = tokenName;



    document.getElementById("detail-token-badge").textContent = isNativeLuxa ? "NATIVE L1" : (isShards ? "UTILITY" : (IBC_ASSETS_MAP[symbol] ? ("IBC • " + IBC_ASSETS_MAP[symbol].chain.toUpperCase()) : "CW20"));



    document.getElementById("detail-token-balance").textContent = `${token.balance ?? "0"} ${symbol}`;



    document.getElementById("detail-token-decimals").textContent = String(token.decimals ?? (isShards ? 0 : 6));







    const iconElement = document.getElementById("detail-token-icon");



    if (iconElement) iconElement.src = token.icon || "../icons/LUX_Vault.svg";







    const contractElement = document.getElementById("detail-token-contract");




    const isIbcAsset = IBC_ASSETS_MAP[symbol];
    let contractAddress = tokenContract || (isNativeLuxa ? "luxa-1 (Native Coin)" : "luxa-1 (Sub-denom)");
    let copyAddress = tokenContract || currentVault?.address || "";

    if (isIbcAsset && currentVault?.address) {
      const extAddr = convertCosmosAddress(currentVault.address, isIbcAsset.prefix);
      contractAddress = `${isIbcAsset.chain}: ${extAddr}`;
      copyAddress = extAddr;

      // Query live external chain balance to show both external and internal
      if (isIbcAsset.rest) {
        fetch(`${isIbcAsset.rest}/cosmos/bank/v1beta1/balances/${extAddr}`)
          .then(r => r.json())
          .then(res => {
            if (res && Array.isArray(res.balances)) {
              const matched = res.balances.find(b => (b.denom || "").toLowerCase() === (isIbcAsset.baseDenom || "utia"));
              if (matched) {
                const extAmt = (parseFloat(matched.amount || "0") / 1e6).toFixed(symbol === "USDC" ? 2 : 4);
                const balEl = document.getElementById("detail-token-balance");
                if (balEl) {
                  balEl.innerHTML = `<div>${token.balance ?? "0"} ${symbol} <span style="font-size:11px; color:#00FFCC; font-weight:normal;">(on LUXA)</span></div><div style="font-size:12px; color:#94a3b8; margin-top:4px;">${extAmt} ${symbol} <span style="font-size:10px; color:#818cf8;">(on ${isIbcAsset.chain})</span></div>`;
                }
              }
            }
          }).catch(() => {});
      }
    }




    contractElement.textContent = contractAddress.length > 34 ? `${contractAddress.slice(0, 20)}...${contractAddress.slice(-8)}` : contractAddress;



    contractElement.onclick = () => {



      if (copyAddress) {



        navigator.clipboard.writeText(copyAddress);



        LuxaUI.toast(`${isIbcAsset ? isIbcAsset.chain : "Contract"} address copied! 📋`, "⚡");



      }



    };







    const poolStatusTag = document.getElementById("detail-pool-status-tag");



    const poolStateLabel = document.getElementById("detail-pool-state-label");



    const poolReserveLuxa = document.getElementById("detail-pool-reserve-luxa");



    const poolReserveToken = document.getElementById("detail-pool-reserve-token");



    const poolRatio = document.getElementById("detail-pool-ratio");







    poolStatusTag.textContent = "VERIFYING...";



    poolStatusTag.style.borderColor = "#f59e0b";



    poolStatusTag.style.color = "#f59e0b";



    poolStateLabel.textContent = "Checking AMM engine...";



    poolReserveLuxa.textContent = "—";



    poolReserveToken.textContent = "—";



    poolRatio.textContent = "Pool verification in progress...";







    document.getElementById("btn-back-from-token-detail").onclick = () => showDashboard();

    // Enable dynamic Buy button for listed and pooled tokens (LDEX Sovereign Exchange)
    const btnDetailBuy = document.getElementById("btn-detail-buy");
    if (btnDetailBuy) {
      const isBuyable = isNativeLuxa || isShards || Boolean(isIbcAsset) || Boolean(IBC_ASSETS_MAP[symbol]);
      if (isBuyable) {
        btnDetailBuy.classList.remove("is-disabled");
        btnDetailBuy.removeAttribute("disabled");
        btnDetailBuy.title = `Buy ${symbol} on LDEX Sovereign DEX`;
        const soonBadge = btnDetailBuy.querySelector(".mm-soon-badge");
        if (soonBadge) soonBadge.style.display = "none";
        btnDetailBuy.onclick = () => {
          const targetPair = isNativeLuxa ? "" : `?pair=${encodeURIComponent(symbol)}/LUXA`;
          const dexUrl = `https://ldex.luxaecosystem.xyz/${targetPair}`;
          LuxaUI.toast(`Opening LDEX to buy ${symbol}... ⚡`, "🛒");
          if (window.chrome && chrome.tabs && chrome.tabs.create) {
            chrome.tabs.create({ url: dexUrl });
          } else {
            window.open(dexUrl, "_blank");
          }
        };
      } else {
        btnDetailBuy.classList.add("is-disabled");
        btnDetailBuy.title = "No active AMM pool or listing on DEX";
        const soonBadge = btnDetailBuy.querySelector(".mm-soon-badge");
        if (soonBadge) soonBadge.style.display = "";
        btnDetailBuy.onclick = null;
      }
    }

    const btnDetailSwap = document.getElementById("btn-detail-swap");
    if (btnDetailSwap) {
      btnDetailSwap.onclick = () => {
        if (isShards || isNativeLuxa) {
          openInAppSwap();
        } else {
          const swapUrl = `https://ldex.luxaecosystem.xyz/?pair=${encodeURIComponent(symbol)}/LUXA&tab=amm`;
          LuxaUI.toast(`Opening LDEX AMM Swap for ${symbol}... ⚡`, "⇄");
          if (window.chrome && chrome.tabs && chrome.tabs.create) {
            chrome.tabs.create({ url: swapUrl });
          } else {
            window.open(swapUrl, "_blank");
          }
        }
      };
    }

    document.getElementById("btn-detail-open-pool").onclick = () => {
      const poolUrl = isIbcAsset 
        ? `https://ldex.luxaecosystem.xyz/?pair=${encodeURIComponent(symbol)}/LUXA`
        : `${DEX_STUDIO_URL}?tab=pool&token=${encodeURIComponent(tokenContract || symbol)}`;
      if (window.chrome && chrome.tabs && chrome.tabs.create) {
        chrome.tabs.create({ url: poolUrl });
      } else {
        window.open(poolUrl, "_blank");
      }
    };



    document.getElementById("btn-detail-receive").onclick = () => {



      if (currentVault?.address) openReceiveModal(currentVault.address, token);



    };



    document.getElementById("btn-detail-send").onclick = () => {
      if (isCustomCw20) {
        LuxaUI.alert({
          title: "CW20 Transfer",
          desc: "Direct transfers for custom contracts are signed and executed via the interactive LUXA Studio DEX console.",
          icon: "ℹ️"
        });
        return;
      }
      hideAllViews();
      if (vaultTopBar) vaultTopBar.style.display = "block";
      if (viewSend) viewSend.style.display = "block";
      document.getElementById("extRecipientInput").value = "";
      document.getElementById("extAmountInput").value = "";
      switchVaultToken(symbol.toLowerCase());
    };







    if (isNativeLuxa) {



      poolStatusTag.textContent = "BASE ASSET";



      poolStatusTag.style.borderColor = "var(--cyan)";



      poolStatusTag.style.color = "var(--cyan)";



      poolStateLabel.textContent = "Native L1 Settlement Asset";



      poolReserveLuxa.textContent = "Primary Liquidity";



      poolReserveToken.textContent = "N/A";



      poolRatio.textContent = "1.0000 LUXA (Base)";



      return;



    }







    try {



      const reserves = await fetchLivePoolReserves();



      if (reserves && (reserves.reserveA > 0 || reserves.reserveB > 0)) {



        const reserveA = reserves.reserveA / 1_000_000;



        const reserveB = reserves.reserveB / 1_000_000;



        poolStatusTag.textContent = "ACTIVE ON-CHAIN";



        poolStatusTag.style.borderColor = "#00FFCC";



        poolStatusTag.style.color = "#00FFCC";







        poolReserveLuxa.textContent = `${reserveA.toFixed(2)} LUXA`;



        poolReserveToken.textContent = `${reserveB.toLocaleString(undefined, {maximumFractionDigits: 0})} ${symbol}`;



        poolStateLabel.textContent = "Active AMM Pool (x*y=k)";



        poolRatio.textContent = `1 ${symbol} ≈ ${(reserveA / Math.max(1, reserveB)).toFixed(6)} LUXA (1 LUXA ≈ ${(reserveB / Math.max(0.0001, reserveA)).toLocaleString(undefined, {maximumFractionDigits: 2})} ${symbol})`;



      } else {



        poolStatusTag.textContent = "POOL NOT CREATED";



        poolStatusTag.style.borderColor = "#f59e0b";



        poolStatusTag.style.color = "#f59e0b";



        poolStateLabel.textContent = "No active AMM pool for this token";



        poolReserveLuxa.textContent = "0.00 LUXA";



        poolReserveToken.textContent = `0.00 ${symbol}`;



        poolRatio.textContent = "Pre-Listing / No Liquidity";



      }



    } catch (_) {



      poolStatusTag.textContent = "SOON";



      poolStatusTag.style.borderColor = "#88a0bf";



      poolStatusTag.style.color = "#88a0bf";



      poolStateLabel.textContent = "DEX Pooling module unreachable";



      poolReserveLuxa.textContent = "—";



      poolReserveToken.textContent = "—";



      poolRatio.textContent = "Pool data unavailable";



    }



  }







  async function deleteCustomToken(walletAddress, contractAddress, symbol) {



    try {



      const confirmed = await LuxaUI.confirm({



        title: "Hide Token?",



        desc: "Remove this token from your tracked assets? This will not affect your on-chain funds.",



        icon: "🗑️",



        confirmText: "Remove",



        cancelText: "Cancel"



      });



      if (!confirmed) return;







      const storageKey = `custom_tokens_${walletAddress}`;



      const stored = await new Promise((resolve) => chrome.storage.local.get([storageKey], resolve));



      const currentList = Array.isArray(stored[storageKey]) ? stored[storageKey] : [];



      const contractKey = String(contractAddress || "").toLowerCase();



      const updatedList = currentList.filter((item) => String(item.contract || "").toLowerCase() !== contractKey);







      await new Promise((resolve, reject) => {



        chrome.storage.local.set({ [storageKey]: updatedList }, () => {



          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));



          else resolve();



        });



      });



      LuxaUI.toast(`Token ${symbol} removed from Vault`, "✓");



      renderTokensList(walletAddress);



    } catch (err) {



      LuxaUI.alert({ title: "Token Removal Failed", desc: err.message, icon: "❌" });



    }



  }







  async function renderNftVaultList(registered, targetId = "nft-vault-list-dashboard") {



    const list = document.getElementById(targetId);



    if (!list) return;







    const lpPositions = (Array.isArray(window._walletLpPositions) && window._walletLpPositions.length)



      ? window._walletLpPositions



      : (window._walletLpPositionCache && window._walletLpPositionCache.lpBalance > 0 ? [window._walletLpPositionCache] : []);



    const hasLpNft = lpPositions.some(p => p.lpBalance > 0);







    if (!registered.length && !hasLpNft) {



      list.replaceChildren();



      const empty = document.createElement("div");



      empty.className = "nft-empty-msg";



      empty.innerHTML = "No Genesis Relics or LP Certificates anchored in this Vault.<br><small style=\"color:#88BBFF;\">Official relics and DEX LP certificates are registered on-chain on luxa-1.</small>";



      list.appendChild(empty);



      return;



    }







    const registry = await fetchLiveNftRegistry();



    const carousel = document.createElement("div");



    carousel.className = "sovereign-card-carousel";







    if (hasLpNft) {



      for (const lpPos of lpPositions.filter(p => p.lpBalance > 0)) {



        const lpSlot = document.createElement("div");



        lpSlot.className = "sovereign-card-slot";



        lpSlot.style.border = "1.5px solid #00ffaa";



        lpSlot.style.borderRadius = "18px";



        lpSlot.style.boxShadow = "0 6px 20px rgba(0, 255, 170, 0.25)";







        const lpInner = document.createElement("div");



        lpInner.className = "sovereign-card-inner";



        lpInner.style.aspectRatio = "4 / 5";



        lpInner.style.background = "radial-gradient(circle at 60% 40%, #0d4a32 0%, #051a12 100%)";



        lpInner.style.display = "flex";



        lpInner.style.flexDirection = "column";



        lpInner.style.justifyContent = "space-between";



        lpInner.style.padding = "14px 10px";







        const pairLabel = lpPos.pairName || "LUXA/LUNA";



        const balLabel = typeof lpPos.lpBalance === "number" ? lpPos.lpBalance.toLocaleString("en-US", { maximumFractionDigits: 2 }) : String(lpPos.lpBalance);







        lpInner.innerHTML = `



          <div style="display:flex; justify-content:space-between; align-items:center;">



            <span style="font-family:monospace; font-size:12px; font-weight:bold; color:#fff;">${escapeHtml(pairLabel)}</span>



            <span style="font-family:monospace; font-size:10px; color:#58f0b0; background:rgba(0,255,170,0.15); border:1px solid rgba(0,255,170,0.3); border-radius:6px; padding:2px 6px;">0.3%</span>



          </div>



          <div style="text-align:center; padding:8px 0;">



            <svg width="44" height="44" viewBox="0 0 100 100" fill="none" style="margin: 0 auto; filter: drop-shadow(0 0 8px rgba(0,255,170,0.7));">



              <path d="M 28 16 V 74 Q 28 84 42 84 H 80" stroke="#00ffaa" stroke-width="8" stroke-linecap="round" stroke-linejoin="round" fill="none"/>



              <path d="M 28 16 V 74 Q 28 84 42 84 H 80" stroke="#ffffff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none"/>



              <circle cx="28" cy="16" r="4.5" fill="#ffffff"/>



              <circle cx="80" cy="84" r="4.5" fill="#ffffff"/>



            </svg>



            <div style="font-family:monospace; font-size:12px; font-weight:bold; color:#00ffaa; margin-top:5px;">LP POSITION #${lpPos.positionId}</div>



            <div style="font-family:monospace; font-size:9.5px; color:#94a3b8;">${balLabel} LP • ${lpPos.sharePct}</div>



          </div>



          <div style="border-top:1px solid rgba(0,255,170,0.2); padding-top:6px; text-align:center;">



            <span style="font-family:monospace; font-size:9px; color:#58f0b0; text-transform:uppercase; letter-spacing:1px; font-weight:bold;">LUXA L1 SOVEREIGN LP ↗</span>



          </div>



        `;







        lpSlot.appendChild(lpInner);



        lpSlot.onclick = () => {



          if (window._setSelectedLpPool && lpPos.contractAddress) {



            window._setSelectedLpPool(lpPos.contractAddress);



          }



          switchTab("pools");



        };



        carousel.appendChild(lpSlot);



      }



    }







    registered.forEach((item) => {



      const key = String(item.id || item.key || "0").replace(/[^0-9]/g, "");



      const meta = registry[key] || {};







      const name = meta.name || item.name || `Genesis Relic #${key}`;



      const description = meta.description || item.description || item.utility || "Genesis immutable relic anchored on luxa-1 protocol.";



      const attributes = meta.attributes || item.attributes || [];



      const roleAttribute = attributes.find(a => a.trait_type === "Authority" || a.trait_type === "Archetype");



      const role = roleAttribute?.value || meta.category || item.category || "Genesis Relic";



      const rarity = meta.rarity || item.tier || "Sovereign";



      const rarityKey = rarity.toLowerCase().split(" ")[0];



      const isCitizenZero = key === "0";



      const accent = isCitizenZero ? "#FFD700" : (meta.accent_color || RARITY_ACCENTS[rarityKey] || "#00FFCC");



      const badgeIcon = isCitizenZero ? "👑" : (meta.symbol || meta.badge_icon || "🛡️");



      const txHash = String(meta.tx_hash || item.txHash || (isCitizenZero ? "3302E3C2C59820DD1D37F913C96A49566FE8AAA3612863D3EC84CBFDAF989B69" : "")).trim();



      const explorerUrl = txHash



        ? `https://luxaecosystem.xyz/explorer.html?tx=${encodeURIComponent(txHash)}`



        : `https://luxaecosystem.xyz/explorer.html?q=${encodeURIComponent(key)}`;



      



      const imgSrc = meta.image || item.image || (item.fileName



        ? `https://luxaecosystem.alwaysdata.net/assets/nfts/${item.fileName}`



        : "../icons/LUX_Vault.svg");



      const holder = item.ownerAddress || item.vaultAddress || "luxa1...";



      const shortHolder = holder.length > 20 ? `${holder.slice(0, 10)}...${holder.slice(-6)}` : holder;



      const tickerText = ` ⚡ HOLDER: ${shortHolder} • ON-CHAIN: LUXA-1 • ASSET: ${name.toUpperCase()} • STATUS: ANCHORED ⚡ `.repeat(3);







      const slot = document.createElement("div");



      slot.className = "sovereign-card-slot";



      slot.style.border = `1.5px solid ${accent}`;



      slot.style.borderRadius = "18px";



      slot.style.boxShadow = `0 6px 20px ${accent}22`;







      const inner = document.createElement("div");



      inner.className = "sovereign-card-inner";



      inner.style.aspectRatio = "4 / 5";







      const img = document.createElement("img");



      img.className = "sovereign-card-img";



      img.src = imgSrc;



      img.alt = name;



      img.loading = "lazy";



      img.style.objectFit = "cover";



      img.style.objectPosition = "top center";



      img.onerror = () => { img.src = "../icons/LUX_Vault.svg"; };







      const shade = document.createElement("div");



      shade.className = "sovereign-card-shade";







      const lxBadge = document.createElement("div");



      lxBadge.className = "sovereign-lx-badge";



      lxBadge.textContent = badgeIcon;



      lxBadge.style.border = `1.5px solid ${accent}`;



      lxBadge.style.color = accent;







      if ([...badgeIcon].length <= 2) {



        lxBadge.style.padding = "0";



        lxBadge.style.width = "26px";



      } else {



        lxBadge.style.padding = "0 7px";



        lxBadge.style.width = "auto";



      }







      const footer = document.createElement("div");



      footer.className = "sovereign-card-footer";



      



      const titleEl = document.createElement("div");



      titleEl.className = "sovereign-card-title";



      titleEl.textContent = name;







      const subEl = document.createElement("div");



      subEl.className = "sovereign-card-sub";



      subEl.textContent = `${rarity.toUpperCase()} #${key}`;



      subEl.style.color = accent;







      footer.append(titleEl, subEl);







      const ticker = document.createElement("div");



      ticker.className = "sovereign-ticker";



      const track = document.createElement("div");



      track.className = "sovereign-ticker-track";



      track.textContent = tickerText;



      track.style.color = accent;



      ticker.appendChild(track);







      inner.append(img, shade, lxBadge, footer, ticker);



      slot.appendChild(inner);







      slot.onclick = () => {



        const powers = attributes.map(a => `<li><b>${a.trait_type}:</b> ${a.value}</li>`).join("");







        LuxaUI.alert({



          title: name,



          desc: `



            <div style="text-align:left; font-size:11.5px;">



              <div style="color:${accent}; font-weight:bold; margin-bottom:4px;">${role}</div>



              <p style="color:#94a3b8; margin-bottom:10px;">${description}</p>



              <div style="color:#FFD700; font-weight:bold; margin-bottom:4px;">⚡ PROTOCOL ATTRIBUTES:</div>



              <ul style="padding-left:16px; margin-bottom:10px; color:#e2e8f0; line-height:1.6;">${powers || '<li>Sovereign on-chain anchoring certified</li>'}</ul>



              <div style="border-top:1px solid rgba(255,255,255,0.08); padding-top:6px;">



                <span style="color:#94a3b8;">Transaction Hash:</span><br>



                ${txHash ? `<a href="${explorerUrl}" id="modal-nft-tx-link" style="color:${accent}; font-family:monospace; font-size:10px; text-decoration:underline; word-break:break-all;">${txHash} 🔗</a>` : '<span style="color:#64748b; font-family:monospace; font-size:10px;">Protocol Genesis Reserve</span>'}



              </div>



            </div>



          `,



          icon: badgeIcon,



          btnText: "Close"



        });







        setTimeout(() => {



          const link = document.getElementById("modal-nft-tx-link");



          if (link && txHash) link.onclick = (e) => { e.preventDefault(); chrome.tabs.create({ url: explorerUrl }); };



        }, 50);



      };







      carousel.appendChild(slot);



    });







    list.replaceChildren(carousel);



  }







  function decodeAttr(str) {



    if (!str || typeof str !== "string") return "";



    try {



      const dec = atob(str);



      if (btoa(dec) === str) return dec;



    } catch (_) {}



    return str;



  }







  const KNOWN_CW20_TOKENS = {



    "luxa1hulx7cgvpfcvg83wk5h96sedqgn72n026w6nl47uht554xhvj9ns85cdy9": { symbol: "LUNA", decimals: 6 },



    "luxa1aakfpghcanxtc45gpqlx8j3rq0zcpyf49qmhm9mdjrfx036h4z5sdj4ev2": { symbol: "MOJO", decimals: 6 }



  };







  async function resolveTokenSymbol(denomOrAddr) {
    if (!denomOrAddr) return "TOKEN";
    const d = String(denomOrAddr).trim();
    const dLower = d.toLowerCase();
    if (dLower === "uluxa") return "LUXA";
    if (dLower === "ushard") return "SHARD";
    if (dLower === "uatom") return "ATOM";
    if (dLower === "uosmo") return "OSMO";
    if (dLower === "utia") return "TIA";
    if (dLower === "uusdc") return "USDC";

    if (typeof IBC_ASSETS_MAP === "object" && IBC_ASSETS_MAP) {
      for (const [sym, asset] of Object.entries(IBC_ASSETS_MAP)) {
        if (asset.denom && dLower === asset.denom.toLowerCase()) return sym;
        if (asset.baseDenom && dLower === asset.baseDenom.toLowerCase()) return sym;
      }
    }
    if (dLower.includes("9117a26ba81e29fa4f78f57dc2bd90cd3d26848101ba880445f119b22a1e254e")) return "ATOM";
    if (dLower.includes("bf28d9c17e0306b194d50f51c3b2590bead15e04e03add34c3a26e62d85c9676")) return "TIA";
    if (dLower.includes("bff0d3805b50d93e2fa5c0b2ddf7e0b30a631076cd80bc12a48c0e95404b4a41")) return "USDC";
    if (dLower.includes("0471f1c4e7afd3f07702bef6dc365268d64570f7c1fdc98ea6098dd6de59817b")) return "OSMO";

    if (KNOWN_CW20_TOKENS[d]) return KNOWN_CW20_TOKENS[d].symbol;
    if (KNOWN_CW20_TOKENS[dLower]) return KNOWN_CW20_TOKENS[dLower].symbol;

    if (d.startsWith("luxa1")) {
      try {
        const qB64 = btoa(JSON.stringify({ token_info: {} }));
        const res = await fetch(`${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/contract/${encodeURIComponent(d)}/smart/${qB64}`, { cache: "no-store" });
        if (res.ok) {
          const j = await res.json();
          const info = j?.data !== undefined ? j.data : j;
          if (info?.symbol) {
            const sym = String(info.symbol).toUpperCase();
            KNOWN_CW20_TOKENS[d] = { symbol: sym, decimals: Number(info.decimals || 6) };
            return sym;
          }
        }
      } catch (_) {}
      return `${d.slice(0, 6)}...`;
    }

    if (dLower.startsWith("ibc/")) {
      return "IBC/" + d.slice(4, 9).toUpperCase() + "...";
    }

    return d.toUpperCase();
  }

  let _selectedLpPoolIndex = 0;



  window._setSelectedLpPool = (addr) => {



    if (Array.isArray(window._walletLpPositions)) {



      const idx = window._walletLpPositions.findIndex(p => p.contractAddress === addr);



      if (idx >= 0) _selectedLpPoolIndex = idx;



    }



  };







  async function loadWalletLpPositions(walletAddress) {



    const container = document.getElementById("lp-vault-list-dashboard");



    if (!container) return;







    container.innerHTML = `



      <div style="padding: 28px 0; text-align: center; font-family: monospace; font-size: 11px; color: #88a0bf;">



        <div class="popup-loading-spinner" style="margin: 0 auto 12px auto; width: 26px; height: 26px;"></div>



        Scanning active AMM pools on luxa-1...



      </div>



    `;







    try {



      if (typeof walletAddress !== "string" || !walletAddress.startsWith("luxa")) {



        throw new Error("A valid LUXA wallet address is required.");



      }







      // 1. Fetch Code 4 contracts



      let contracts4 = [];



      try {



        const r4 = await fetch(`${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/code/4/contracts`, { cache: "no-store" });



        if (r4.ok) {



          const d4 = await r4.json();



          contracts4 = d4?.contracts || [];



        }



      } catch (_) {}







      // 2. Fetch Code 1 contracts



      let contracts1 = [];



      try {



        const r1 = await fetch(`${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/code/1/contracts`, { cache: "no-store" });



        if (r1.ok) {



          const d1 = await r1.json();



          contracts1 = d1?.contracts || [];



        }



      } catch (_) {}







      // Fallback if list fetch was empty



      if (!contracts4.length && !contracts1.length) {



        contracts4 = ["luxa1ery8l6jquynn9a4cz2pff6khg8c68f7urt33l5n9dng2cwzz4c4qewa7v3"];



        contracts1 = [AMM_PAIR_CONTRACT];



      }







      const activePositions = [];



      const allDiscoveredPools = [];







      // Query Code 4 Pair Contracts



      for (const poolAddr of contracts4) {



        try {



          let rawBal = 0;



          try {



            const balB64 = btoa(JSON.stringify({ get_lp_balance: { account: walletAddress } }));



            const res = await fetch(`${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/contract/${encodeURIComponent(poolAddr)}/smart/${balB64}`, { cache: "no-store" });



            if (res.ok) {



              const j = await res.json();



              const val = j?.data !== undefined ? j.data : j;



              if (/^\d+$/.test(String(val))) rawBal = Number(val);



            }



          } catch (_) {}







          if (rawBal <= 0) {



            try {



              const balB64 = btoa(JSON.stringify({ balance_of: { who: walletAddress } }));



              const res = await fetch(`${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/contract/${encodeURIComponent(poolAddr)}/smart/${balB64}`, { cache: "no-store" });



              if (res.ok) {



                const j = await res.json();



                const val = j?.data !== undefined ? j.data : j;



                if (/^\d+$/.test(String(val))) rawBal = Number(val);



              }



            } catch (_) {}



          }







          const pB64 = btoa(JSON.stringify({ pair_info: {} }));



          const pRes = await fetch(`${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/contract/${encodeURIComponent(poolAddr)}/smart/${pB64}`, { cache: "no-store" });



          if (pRes.ok) {



            const pJson = await pRes.json();



            const pInfo = pJson?.data !== undefined ? pJson.data : pJson;



            if (pInfo && (pInfo.reserve_a !== undefined || pInfo.reserve_b !== undefined)) {



              const rA = Number(pInfo.reserve_a || 0) / 1_000_000;



              const rB = Number(pInfo.reserve_b || 0) / 1_000_000;



              const totalLp = Number(pInfo.total_lp_supply || 0) / 1_000_000;



              const symA = await resolveTokenSymbol(pInfo.token_a || "uluxa");



              const symB = await resolveTokenSymbol(pInfo.token_b);



              const pairName = `${symA}/${symB}`;



              const lpBal = rawBal / 1_000_000;



              const shareRatio = totalLp > 0 ? (lpBal / totalLp) : 0;



              const positionId = Math.abs(walletAddress.split("").reduce((acc, c) => ((acc << 5) - acc) + c.charCodeAt(0), 0) % 9999 + 1);







              const posData = {



                contractAddress: poolAddr,



                pairName,



                symbolA: symA,



                symbolB: symB,



                reserveA: rA,



                reserveB: rB,



                totalLpSupply: totalLp,



                lpBalance: lpBal,



                shareRatio,



                sharePct: `${(shareRatio * 100).toFixed(2)}%`,



                pooledLuxa: (rA * shareRatio).toFixed(4),



                pooledTokenB: (rB * shareRatio).toLocaleString("en-US", { maximumFractionDigits: 2 }),



                spotRate: (rA > 0 && rB > 0) ? (rB / rA).toLocaleString("en-US", { maximumFractionDigits: 2 }) : "1.00",



                positionId,



                walletAddress,



                codeId: 4



              };







              if (lpBal > 0) {



                activePositions.push(posData);



              }



              if (rA > 0 || rB > 0) {



                allDiscoveredPools.push(posData);



              }



            }



          }



        } catch (err) {



          console.warn("[LUXA Vault] Error scanning Code 4 pool", poolAddr, err);



        }



      }







      // Query Code 1 Pair Contracts



      for (const poolAddr of contracts1) {



        try {



          let rawBal = 0;



          try {



            const balB64 = btoa(JSON.stringify({ balance_of: { who: walletAddress } }));



            const res = await fetch(`${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/contract/${encodeURIComponent(poolAddr)}/smart/${balB64}`, { cache: "no-store" });



            if (res.ok) {



              const j = await res.json();



              const val = j?.data !== undefined ? j.data : j;



              if (/^\d+$/.test(String(val))) rawBal = Number(val);



            }



          } catch (_) {}







          let rA = 0;



          let rB = 0;



          try {



            const rB64 = btoa(JSON.stringify({ get_reserves: {} }));



            const res = await fetch(`${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/contract/${encodeURIComponent(poolAddr)}/smart/${rB64}`, { cache: "no-store" });



            if (res.ok) {



              const j = await res.json();



              const data = j?.data !== undefined ? j.data : j;



              if (Array.isArray(data) && data.length >= 2) {



                rA = Number(data[0]) / 1_000_000;



                rB = Number(data[1]) / 1_000_000;



              }



            }



          } catch (_) {}







          let totalLp = 0;



          try {



            const rawKeyB64 = btoa("total_supply");



            const rawRes = await fetch(`${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/contract/${encodeURIComponent(poolAddr)}/raw/${rawKeyB64}`, { cache: "no-store" });



            if (rawRes.ok) {



              const rawJson = await rawRes.json();



              if (rawJson?.data) {



                let decoded = atob(rawJson.data);



                try { decoded = JSON.parse(decoded); } catch {}



                if (/^\d+$/.test(String(decoded))) {



                  totalLp = Number(decoded) / 1_000_000;



                }



              }



            }



          } catch (_) {}







          if (rA > 0 || rB > 0 || rawBal > 0) {



            const symA = "LUXA";



            const symB = "SHARD";



            const pairName = `${symA}/${symB}`;



            const lpBal = rawBal / 1_000_000;



            const shareRatio = totalLp > 0 ? (lpBal / totalLp) : 0;



            const positionId = Math.abs(walletAddress.split("").reduce((acc, c) => ((acc << 5) - acc) + c.charCodeAt(0), 0) % 9999 + 1);







            const posData = {



              contractAddress: poolAddr,



              pairName,



              symbolA: symA,



              symbolB: symB,



              reserveA: rA,



              reserveB: rB,



              totalLpSupply: totalLp,



              lpBalance: lpBal,



              shareRatio,



              sharePct: `${(shareRatio * 100).toFixed(4)}%`,



              pooledLuxa: (rA * shareRatio).toFixed(4),



              pooledTokenB: (rB * shareRatio).toLocaleString("en-US", { maximumFractionDigits: 2 }),



              spotRate: (rA > 0 && rB > 0) ? (rB / rA).toLocaleString("en-US", { maximumFractionDigits: 2 }) : "10,000",



              positionId,



              walletAddress,



              codeId: 1



            };







            if (lpBal > 0) {



              activePositions.push(posData);



            }



            if (rA > 0 || rB > 0) {



              allDiscoveredPools.push(posData);



            }



          }



        } catch (err) {



          console.warn("[LUXA Vault] Error scanning Code 1 pool", poolAddr, err);



        }



      }







      window._walletLpPositions = activePositions;



      window._walletLpPositionCache = activePositions[0] || null;



      window._allDiscoveredPools = allDiscoveredPools;







      // Update NFT list if already loaded in DOM



      if (document.getElementById("tab-content-nfts")?.style.display === "block" || window._walletNftsCache) {



        renderNftVaultList(window._walletNftsCache || []);



      }







      if (activePositions.length <= 0) {
        const hasDiscoveredPools = Array.isArray(allDiscoveredPools) && allDiscoveredPools.length > 0;
        const topPool = hasDiscoveredPools ? allDiscoveredPools[0] : null;

        const poolsChipsHtml = hasDiscoveredPools
          ? allDiscoveredPools.map(p => `
              <span style="background: rgba(0,255,204,0.08); border: 1px solid rgba(0,255,204,0.28); border-radius: 6px; padding: 4px 8px; color: #fff; font-size: 10.5px; font-weight: 700; white-space: nowrap; display: inline-flex; align-items: center; gap: 4px;">
                <span style="color: #00FFCC; font-size: 11px;">⚡</span> ${escapeHtml(p.pairName)}
              </span>
            `).join("")
          : '<span style="color:#94a3b8; font-size:11px;">No active pools detected on-chain</span>';

        const reservesHtml = topPool && typeof topPool.reserveA === "number" && typeof topPool.reserveB === "number"
          ? `${topPool.reserveA.toLocaleString(undefined, {maximumFractionDigits: 1})} ${escapeHtml(topPool.symbolA || "")} / ${topPool.reserveB.toLocaleString(undefined, {maximumFractionDigits: 1})} ${escapeHtml(topPool.symbolB || "")}`
          : "Data unavailable";

        const topPoolLabel = topPool ? escapeHtml(topPool.pairName) : "LUXA/LUNA";

        container.innerHTML = `
          <div style="padding: 16px 8px; width: 100%; max-width: 100%; box-sizing: border-box; text-align: center; font-family: monospace;">
            <div style="font-size: 28px; line-height: 1; margin-bottom: 6px; color: #00FFCC; opacity: 0.9;">∅</div>
            <div style="font-size: 13.5px; font-weight: 700; color: #fff; letter-spacing: 0.3px;">No Active LP Position</div>
            <p style="font-size: 11px; color: #94a3b8; margin: 6px auto 14px; max-width: 270px; line-height: 1.5;">
              Wallet <b style="color: #f1f5f9;">${walletAddress.slice(0, 8)}...${walletAddress.slice(-4)}</b> currently holds 0 LP tokens on luxa-1.
            </p>

            <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(0,255,204,0.2); border-radius: 12px; padding: 12px 14px; margin-bottom: 14px; text-align: left; width: 100%; box-sizing: border-box;">
              <div style="margin-bottom: 10px;">
                <div style="color: #94a3b8; font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px;">Active AMM Liquidity Pools</div>
                <div style="display: flex; flex-wrap: wrap; gap: 6px;">
                  ${poolsChipsHtml}
                </div>
              </div>

              <div style="border-top: 1px solid rgba(255,255,255,0.07); padding-top: 10px; margin-bottom: 6px;">
                <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 3px;">
                  <span style="color: #94a3b8; font-size: 10px; text-transform: uppercase;">Top Pool Reserves (${topPoolLabel}):</span>
                  <span style="color: #a7f3d0; font-size: 10.5px; font-weight: 700;">0.30% fee</span>
                </div>
                <div style="color: #00FFCC; font-size: 11.5px; font-weight: 700; word-break: break-word;">
                  ${reservesHtml}
                </div>
              </div>
            </div>

            <div style="display: flex; flex-direction: column; gap: 8px; width: 100%; align-items: center;">
              <button type="button" class="btn-manage-dex-pool" id="btn-empty-go-pool" style="width: 100%; max-width: 310px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; gap: 8px;">
                <span>💧</span> Add Liquidity on DEX Studio ↗
              </button>
              <button type="button" class="btn-manage-dex-pool" id="btn-preview-nft-cert" style="width: 100%; max-width: 310px; box-sizing: border-box; background: rgba(255,255,255,0.04); border-color: rgba(255,255,255,0.18); color: #cbd5e1; display: flex; align-items: center; justify-content: center; gap: 8px;">
                <span>👁️</span> Preview LP NFT Certificate
              </button>
            </div>
          </div>
        `;

        document.getElementById("btn-empty-go-pool")?.addEventListener("click", () => {



          chrome.tabs.create({ url: `${DEX_STUDIO_URL}#pool` });



        });



        document.getElementById("btn-preview-nft-cert")?.addEventListener("click", () => {



          renderLuxaLpNftCard(container, {



            walletAddress,



            positionId: 777,



            contractAddress: topPool.contractAddress || AMM_PAIR_CONTRACT,



            pairName: topPool.pairName || "LUXA/LUNA",



            symbolA: topPool.symbolA || "LUXA",



            symbolB: topPool.symbolB || "LUNA",



            lpBalance: 10.0,



            sharePct: "0.0001%",



            pooledLuxa: "0.1000",



            pooledTokenB: "1,000.00",



            reserveA: topPool.reserveA || 1000,



            reserveB: topPool.reserveB || 100000,



            spotRate: "100.00",



            totalLpSupply: 10000,



            isPreview: true



          });



        });



        return;



      }







      if (_selectedLpPoolIndex >= activePositions.length) {



        _selectedLpPoolIndex = 0;



      }







      renderLuxaLpNftCard(container, activePositions[_selectedLpPoolIndex], activePositions);



    } catch (error) {



      const message = error instanceof Error ? error.message : "Unknown error.";



      container.innerHTML = `



        <div style="padding: 24px 12px; text-align: center; font-family: monospace; font-size: 11px; color: #ef4444;">



          ⚠️ Unable to read on-chain pool data: ${escapeHtml(message)}



          <br><br>



          <button type="button" class="btn-manage-dex-pool" id="btn-retry-lp" style="margin: 0 auto;">



            🔄 Retry Query



          </button>



        </div>



      `;



      document.getElementById("btn-retry-lp")?.addEventListener("click", () => loadWalletLpPositions(walletAddress));



    }



  }







  function renderLuxaLpNftCard(container, data, allPositions = []) {



    const {



      walletAddress,



      positionId,



      lpBalance,



      sharePct,



      pooledLuxa,



      pooledTokenB,



      reserveA,



      reserveB,



      spotRate,



      totalLpSupply,



      contractAddress,



      pairName,



      symbolA,



      symbolB,



      isPreview



    } = data;







    const currentPair = pairName || "LUXA/LUNA";



    const currentSymA = symbolA || "LUXA";



    const currentSymB = symbolB || "LUNA";



    const currentPoolAddr = contractAddress || AMM_PAIR_CONTRACT;



    const fullBorderText = `• OWNER: ${walletAddress} • LUXA L1 SOVEREIGN LP #${positionId} • PAIR: ${currentPair} • `;



    const repeatedBorderText = fullBorderText.repeat(3);



    const explorerUrl = `https://luxaecosystem.xyz/explorer.html?pool=${encodeURIComponent(currentPoolAddr)}&owner=${encodeURIComponent(walletAddress)}&pos=${positionId}`;







    let tabsHtml = "";



    if (Array.isArray(allPositions) && allPositions.length > 1) {



      tabsHtml = `



        <div class="lp-pools-nav" style="display:flex; gap:6px; margin-bottom:12px; overflow-x:auto; padding-bottom:4px; max-width:100%;">



          ${allPositions.map((pos, idx) => {



            const isSel = pos.contractAddress === currentPoolAddr;



            const balStr = typeof pos.lpBalance === "number" ? pos.lpBalance.toLocaleString(undefined, {maximumFractionDigits: 1}) : pos.lpBalance;



            return `



              <button type="button" class="btn-lp-pos-tab" data-idx="${idx}" style="background:${isSel ? 'rgba(0,255,170,0.18)' : 'rgba(255,255,255,0.05)'}; border:1px solid ${isSel ? '#00ffaa' : 'rgba(255,255,255,0.12)'}; border-radius:8px; padding:5px 10px; color:${isSel ? '#00ffaa' : '#94a3b8'}; font-family:monospace; font-size:11px; cursor:pointer; white-space:nowrap;">



                ${escapeHtml(pos.pairName)} (${balStr} LP)



              </button>



            `;



          }).join("")}



        </div>



      `;



    }







    container.innerHTML = `



      ${tabsHtml}



      <div class="lp-card-wrapper select-none">



        ${isPreview ? '<div style="font-size:9.5px; font-weight:700; color:#f59e0b; background:rgba(245,158,11,0.12); border:1px solid rgba(245,158,11,0.3); border-radius:999px; padding:3px 10px; margin-bottom:8px; font-family:monospace;">PREVIEW MODE — DEPOSIT TO CLAIM ON-CHAIN</div>' : ''}



        <svg class="lp-nft-svg" viewBox="0 0 300 470" fill="none" xmlns="http://www.w3.org/2000/svg">



          <defs>



            <radialGradient id="vaultNftBg" cx="75%" cy="40%" r="85%" fx="60%" fy="30%">



              <stop offset="0%" stop-color="#156644"/>



              <stop offset="35%" stop-color="#0a3d28"/>



              <stop offset="70%" stop-color="#062118"/>



              <stop offset="100%" stop-color="#030d0a"/>



            </radialGradient>



            <radialGradient id="vaultNftShadow" cx="20%" cy="60%" r="60%">



              <stop offset="0%" stop-color="#220d2b" stop-opacity="0.75"/>



              <stop offset="100%" stop-color="#000000" stop-opacity="0"/>



            </radialGradient>



            <filter id="vaultNeonL" x="-50%" y="-50%" width="200%" height="200%">



              <feGaussianBlur in="SourceGraphic" stdDeviation="4" result="blur1"/>



              <feGaussianBlur in="SourceGraphic" stdDeviation="8" result="blur2"/>



              <feMerge>



                <feMergeNode in="blur2"/>



                <feMergeNode in="blur1"/>



                <feMergeNode in="SourceGraphic"/>



              </feMerge>



            </filter>



            <filter id="vaultStarGlow" x="-60%" y="-60%" width="220%" height="220%">



              <feGaussianBlur in="SourceGraphic" stdDeviation="3" result="glow"/>



              <feMerge>



                <feMergeNode in="glow"/>



                <feMergeNode in="glow"/>



                <feMergeNode in="SourceGraphic"/>



              </feMerge>



            </filter>



            <path id="vaultBorderTextPath" d="M 50 14 H 250 A 36 36 0 0 1 286 50 V 420 A 36 36 0 0 1 250 456 H 50 A 36 36 0 0 1 14 420 V 50 A 36 36 0 0 1 50 14 Z"/>



          </defs>



          <rect width="300" height="470" rx="36" fill="url(#vaultNftBg)"/>



          <rect width="300" height="470" rx="36" fill="url(#vaultNftShadow)"/>



          <rect x="14" y="14" width="272" height="442" rx="32" stroke="#00ffaa" stroke-width="1.2" stroke-opacity="0.35" fill="none"/>



          <text fill="#58f0b0" fill-opacity="0.8" font-size="7.5" font-family="monospace" letter-spacing="1.2">



            <textPath href="#vaultBorderTextPath" startOffset="0%">



              <animate attributeName="startOffset" from="0%" to="-100%" dur="25s" repeatCount="indefinite"/>



              ${escapeHtml(repeatedBorderText)}



            </textPath>



          </text>



          <g transform="translate(30, 48)">



            <text x="0" y="28" fill="#ffffff" font-size="21" font-weight="bold" font-family="monospace" letter-spacing="1.5">${escapeHtml(currentPair)}</text>



            <text x="0" y="62" fill="#d1fae5" font-size="22" font-family="monospace">0.3%</text>



          </g>







          {/* Lettera L centrale neon */}



          <g transform="translate(100, 185)">



            <path d="M 22 15 V 95 Q 22 110 38 110 H 95" stroke="#041a12" stroke-width="30" stroke-linecap="round" stroke-linejoin="round" fill="none"/>



            <path d="M 22 15 V 95 Q 22 110 38 110 H 95" stroke="#00ffaa" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none" filter="url(#vaultNeonL)"/>



            <path d="M 22 15 V 95 Q 22 110 38 110 H 95" stroke="#ffffff" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>



            <circle cx="22" cy="15" r="5" fill="#00ffaa" filter="url(#vaultNeonL)"/>



            <circle cx="22" cy="15" r="2.5" fill="#ffffff"/>



            <circle cx="22" cy="15" r="9" stroke="#00ffaa" stroke-width="1" stroke-opacity="0.4"/>



            <circle cx="95" cy="110" r="5" fill="#00ffaa" filter="url(#vaultNeonL)"/>



            <circle cx="95" cy="110" r="2.5" fill="#ffffff"/>



            <circle cx="95" cy="110" r="9" stroke="#00ffaa" stroke-width="1" stroke-opacity="0.4"/>



          </g>







          <g transform="translate(26, 350)">



            <rect x="0" y="0" width="70" height="22" rx="6" fill="#041812" fill-opacity="0.85" stroke="#124a35" stroke-width="0.8"/>



            <text x="10" y="15" fill="#ffffff" font-size="10" font-weight="bold" font-family="monospace">ID: #${positionId}</text>



            <rect x="0" y="27" width="130" height="22" rx="6" fill="#041812" fill-opacity="0.85" stroke="#124a35" stroke-width="0.8"/>



            <text x="10" y="42" fill="#86efac" font-size="9.5" font-family="monospace">LP: ${typeof lpBalance === 'number' ? lpBalance.toFixed(2) : lpBalance}</text>



            <rect x="0" y="54" width="130" height="22" rx="6" fill="#041812" fill-opacity="0.85" stroke="#124a35" stroke-width="0.8"/>



            <text x="10" y="69" fill="#86efac" font-size="9.5" font-family="monospace">Share: ${sharePct}</text>



          </g>







          <g transform="translate(232, 362)">



            <rect x="0" y="0" width="34" height="34" rx="10" fill="#041812" fill-opacity="0.85" stroke="#124a35" stroke-width="0.8"/>



            <circle cx="17" cy="17" r="10" fill="#00ffcc" opacity="0.35">



              <animate attributeName="r" values="8;14;8" dur="2s" repeatCount="indefinite"/>



              <animate attributeName="opacity" values="0.25;0.7;0.25" dur="2s" repeatCount="indefinite"/>



            </circle>



            <path d="M 17 9 L 19.5 14.5 L 25 17 L 19.5 19.5 L 17 25 L 14.5 19.5 L 9 17 L 14.5 14.5 Z" fill="#a7f3d0" filter="url(#vaultStarGlow)">



              <animate attributeName="fill" values="#a7f3d0;#ffffff;#00ffcc;#a7f3d0" dur="2s" repeatCount="indefinite"/>



              <animate attributeName="opacity" values="0.8;1;0.8" dur="2s" repeatCount="indefinite"/>



            </path>



            <rect x="0" y="42" width="34" height="34" rx="10" fill="#041812" fill-opacity="0.85" stroke="#124a35" stroke-width="0.8"/>



            <path d="M 11 50 V 66 Q 11 70 15 70 H 24" stroke="#a7f3d0" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>



            <circle cx="24" cy="70" r="2" fill="#a7f3d0"/>



          </g>



        </svg>







        <div class="lp-details-box">



          <div class="lp-details-row">



            <span>Pool Ownership:</span>



            <span class="lp-details-val cyan">${sharePct}</span>



          </div>



          <div class="lp-details-row">



            <span>Pooled ${escapeHtml(currentSymA)}:</span>



            <span class="lp-details-val">${pooledLuxa} ${escapeHtml(currentSymA)}</span>



          </div>



          <div class="lp-details-row">



            <span>Pooled ${escapeHtml(currentSymB)}:</span>



            <span class="lp-details-val">${pooledTokenB} ${escapeHtml(currentSymB)}</span>



          </div>



          <div class="lp-details-row">



            <span>Total LP Supply:</span>



            <span class="lp-details-val">${totalLpSupply.toLocaleString(undefined, {maximumFractionDigits: 2})} LP</span>



          </div>



          <div class="lp-details-row">



            <span>AMM Spot Rate:</span>



            <span class="lp-details-val">1 ${escapeHtml(currentSymA)} ≈ ${spotRate} ${escapeHtml(currentSymB)}</span>



          </div>



          <div class="lp-details-row" style="margin-top: 4px; padding-top: 4px; border-top: 1px dashed rgba(255,255,255,0.08);">



            <span style="color: #22c55e;">Protocol Fee Yield:</span>



            <span style="color: #22c55e; font-weight: bold;">0.30% accrued to LP</span>



          </div>



          <div class="lp-details-row" style="margin-top: 2px;">



            <span style="color: #64748b;">Pair Contract:</span>



            <span style="color: #94a3b8; font-size: 10px; cursor: pointer;" id="btn-copy-pair-contract" title="Click to copy contract">



              ${currentPoolAddr.slice(0, 10)}...${currentPoolAddr.slice(-6)} 📋



            </span>



          </div>



        </div>







        <a href="${explorerUrl}" target="_blank" rel="noopener noreferrer" class="btn-manage-dex-pool" style="background:#061812; border:1px solid rgba(0,255,170,0.4); color:#00ffaa; text-decoration:none; display:flex; align-items:center; justify-content:center; gap:6px; margin-top:8px;">



          <span>View Position &amp; PnL Analytics in Explorer</span>



          <span>↗</span>



        </a>







        <button type="button" class="btn-manage-dex-pool" id="btn-vault-manage-pool" style="margin-top:6px;">



          <span>Manage Position on DEX Studio</span>



          <span>↗</span>



        </button>



      </div>



    `;







    container.querySelectorAll(".btn-lp-pos-tab").forEach(btn => {



      btn.addEventListener("click", () => {



        const idx = Number(btn.getAttribute("data-idx") || 0);



        _selectedLpPoolIndex = idx;



        if (allPositions[idx]) {



          renderLuxaLpNftCard(container, allPositions[idx], allPositions);



        }



      });



    });







    document.getElementById("btn-copy-pair-contract")?.addEventListener("click", () => {



      navigator.clipboard.writeText(currentPoolAddr);



      LuxaUI.toast("Pair contract address copied!", "⚡");



    });







    document.getElementById("btn-vault-manage-pool")?.addEventListener("click", () => {



      chrome.tabs.create({ url: `${DEX_STUDIO_URL}#pool` });



    });



  }







  // (escapeHtml is declared in outer scope)







  let historyOpen = false;







  const tabBtnTokens = document.getElementById("tab-btn-tokens");



  const tabBtnPools = document.getElementById("tab-btn-pools");



  const tabBtnNfts = document.getElementById("tab-btn-nfts");



  const tabBtnActivity = document.getElementById("tab-btn-activity");



  const tabContentTokens = document.getElementById("tab-content-tokens");



  const tabContentPools = document.getElementById("tab-content-pools");



  const tabContentNfts = document.getElementById("tab-content-nfts");



  const tabContentActivity = document.getElementById("tab-content-activity");







  function switchTab(target) {



    const buttons = [tabBtnTokens, tabBtnPools, tabBtnNfts, tabBtnActivity];



    const contents = [tabContentTokens, tabContentPools, tabContentNfts, tabContentActivity];



    buttons.forEach((button) => button?.classList.remove("active"));



    buttons.forEach((button) => button?.setAttribute("aria-selected", "false"));



    contents.forEach((content) => { if (content) content.style.display = "none"; });







    if (target === "tokens") {



      tabBtnTokens?.classList.add("active");



      tabBtnTokens?.setAttribute("aria-selected", "true");



      if (tabContentTokens) tabContentTokens.style.display = "block";



    } else if (target === "pools") {



      tabBtnPools?.classList.add("active");



      tabBtnPools?.setAttribute("aria-selected", "true");



      if (tabContentPools) tabContentPools.style.display = "block";



      const currentVault = vaults[activeIndex];



      if (currentVault?.address) loadWalletLpPositions(currentVault.address);



    } else if (target === "nfts") {



      tabBtnNfts?.classList.add("active");



      tabBtnNfts?.setAttribute("aria-selected", "true");



      if (tabContentNfts) tabContentNfts.style.display = "block";



      renderNftVaultList(window._walletNftsCache || []);



    } else if (target === "activity") {



      tabBtnActivity?.classList.add("active");



      tabBtnActivity?.setAttribute("aria-selected", "true");



      if (tabContentActivity) tabContentActivity.style.display = "block";



      if (!historyOpen) document.getElementById("btn-toggle-activity")?.click();



    }



  }







  if (tabBtnTokens) tabBtnTokens.onclick = () => switchTab("tokens");



  if (tabBtnPools) tabBtnPools.onclick = () => switchTab("pools");



  if (tabBtnNfts) tabBtnNfts.onclick = () => switchTab("nfts");



  if (tabBtnActivity) tabBtnActivity.onclick = () => switchTab("activity");







  const importModal = document.getElementById("import-token-modal");



  const btnOpenImport = document.getElementById("btn-open-import-token-modal");



  const btnCloseImport = document.getElementById("btn-close-import-token");



  const btnCancelImport = document.getElementById("btn-cancel-import-token");



  const btnSubmitImport = document.getElementById("btn-submit-import-token");



  const inputAddr = document.getElementById("input-token-address");



  const inputSym = document.getElementById("input-token-symbol");



  const inputDec = document.getElementById("input-token-decimals");







  if (btnOpenImport && importModal) {



    btnOpenImport.onclick = () => {



      if (inputAddr) inputAddr.value = "";



      if (inputSym) inputSym.value = "";



      if (inputDec) inputDec.value = "6";



      const oldPreview = document.getElementById("import-token-logo-preview");



      if (oldPreview) oldPreview.remove();



      importModal.style.display = "flex";



      inputAddr?.focus();



    };



  }







  [btnCloseImport, btnCancelImport].forEach((button) => {



    if (button && importModal) {



      button.onclick = () => {



        const oldPreview = document.getElementById("import-token-logo-preview");



        if (oldPreview) oldPreview.remove();



        importModal.style.display = "none";



      };



    }



  });







  if (inputAddr) {



    let lookupTimer = null;



    inputAddr.addEventListener("input", () => {



      clearTimeout(lookupTimer);



      const addr = inputAddr.value.trim();



      const oldPreview = document.getElementById("import-token-logo-preview");



      if (oldPreview) oldPreview.remove();



      if (!/^luxa1[a-z0-9]{38,58}$/i.test(addr)) return;







      lookupTimer = setTimeout(async () => {



        try {



          const qB64 = btoa(JSON.stringify({ token_info: {} }));



          const tRes = await fetch(



            `${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/contract/${encodeURIComponent(addr)}/smart/${qB64}`,



            { cache: "no-store" }



          ).catch(() => null);







          let sym = "";



          if (tRes && tRes.ok) {



            const tJson = await tRes.json();



            const tData = tJson?.data !== undefined ? tJson.data : tJson;



            if (tData?.symbol) {



              sym = String(tData.symbol).toUpperCase();



              if (inputSym) inputSym.value = sym;



            }



            if (Number.isInteger(tData?.decimals) && inputDec) {



              inputDec.value = String(tData.decimals);



            }



          }







          const logo = await resolveCustomTokenLogo(addr, sym || inputSym?.value || "");



          if (logo) {



            let previewEl = document.getElementById("import-token-logo-preview");



            if (!previewEl) {



              previewEl = document.createElement("div");



              previewEl.id = "import-token-logo-preview";



              previewEl.style.cssText = "display:flex; align-items:center; gap:8px; margin:8px 0; padding:6px 10px; background:rgba(0,255,170,0.08); border:1px solid rgba(0,255,170,0.25); border-radius:8px;";



              inputAddr.parentElement.after(previewEl);



            }



            previewEl.innerHTML = `<img src="${logo}" style="width:24px; height:24px; border-radius:50%; object-fit:cover;" onerror="this.style.display='none'" /><span style="font-size:11px; font-family:monospace; color:#00ffaa; font-weight:bold;">Token Logo Recognized: ${sym || "CW20"}</span>`;



          }



        } catch (_) {}



      }, 250);



    });



  }







  if (btnSubmitImport && importModal) {



    btnSubmitImport.onclick = async () => {



      const currentVault = vaults[activeIndex];



      if (!currentVault?.address) return;







      const contractAddr = inputAddr?.value.trim() || "";



      if (!/^luxa1[a-z0-9]{38,58}$/i.test(contractAddr)) {



        return LuxaUI.alert({



          title: "Invalid Contract Address",



          desc: "The address must be a valid luxa-1 contract address (luxa1...).",



          icon: "⚠️"



        });



      }







      btnSubmitImport.disabled = true;



      btnSubmitImport.textContent = "Verifying on-chain...";







      try {



        let contractName = "";



        let contractSymbol = "";



        let contractDecimals = Number.parseInt(inputDec?.value, 10) || 6;



        let totalSupply = "0";







        // 1. Verify contract exists on luxa-1 chain via Cosmos wasm module



        let contractInfo = null;



        try {



          const infoRes = await fetch(



            `${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/contract/${encodeURIComponent(contractAddr)}`,



            { cache: "no-store" }



          );



          if (infoRes.ok) {



            const infoJson = await infoRes.json();



            contractInfo = infoJson?.contract_info || infoJson;



            if (contractInfo?.label) {



              contractName = String(contractInfo.label).trim();



            }



          }



        } catch (_) {}







        // 2. Query CW20 token_info smart query: {"token_info": {}}



        try {



          const qB64 = btoa(JSON.stringify({ token_info: {} }));



          const tRes = await fetch(



            `${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/contract/${encodeURIComponent(contractAddr)}/smart/${qB64}`,



            { cache: "no-store" }



          );



          if (tRes.ok) {



            const tJson = await tRes.json();



            const tData = tJson?.data !== undefined ? tJson.data : tJson;



            if (tData?.symbol) {



              contractSymbol = String(tData.symbol).toUpperCase();



              if (tData.name) contractName = String(tData.name);



              if (Number.isInteger(tData.decimals)) contractDecimals = tData.decimals;



              if (tData.total_supply) totalSupply = String(tData.total_supply);



            }



          }



        } catch (_) {}







        // 3. Fallback: Native LUXA Lang queries (get_name, get_symbol, get_decimals)



        if (!contractSymbol) {



          try {



            const qName = btoa(JSON.stringify({ get_name: {} }));



            const qSym = btoa(JSON.stringify({ get_symbol: {} }));



            const qDec = btoa(JSON.stringify({ get_decimals: {} }));



            const [resN, resS, resD] = await Promise.all([



              fetch(`${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/contract/${encodeURIComponent(contractAddr)}/smart/${qName}`).catch(() => null),



              fetch(`${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/contract/${encodeURIComponent(contractAddr)}/smart/${qSym}`).catch(() => null),



              fetch(`${LIVE_COSMOS_REST}/cosmwasm/wasm/v1/contract/${encodeURIComponent(contractAddr)}/smart/${qDec}`).catch(() => null)



            ]);



            if (resS && resS.ok) {



              const sJson = await resS.json();



              contractSymbol = String(sJson?.data ?? sJson).toUpperCase();



            }



            if (resN && resN.ok) {



              const nJson = await resN.json();



              contractName = String(nJson?.data ?? nJson);



            }



            if (resD && resD.ok) {



              const dJson = await resD.json();



              const d = Number(dJson?.data ?? dJson);



              if (Number.isInteger(d) && d >= 0) contractDecimals = d;



            }



          } catch (_) {}



        }







        // 4. Secondary fallback: compiler backend check



        if (!contractSymbol) {



          try {



            const res = await fetch(`${BACKEND_API}/testnet/contract/${encodeURIComponent(contractAddr)}`);



            if (res.ok) {



              const bData = await res.json();



              if (bData?.contract?.contractName) contractName = bData.contract.contractName;



            }



          } catch (_) {}



        }







        const userSymbol = inputSym?.value.trim().toUpperCase();



        const detectedSymbol = userSymbol || contractSymbol || (contractName ? contractName.replace(/token/i, "").trim().slice(0, 6).toUpperCase() : "CW20");



        const finalName = contractName || detectedSymbol;







        if (!/^[A-Z0-9][A-Z0-9._-]{0,11}$/.test(detectedSymbol)) {



          return LuxaUI.alert({



            title: "Invalid Symbol",



            desc: "Use up to 12 letters, numbers, dots, underscores, or hyphens.",



            icon: "⚠️"



          });



        }



        if (!Number.isInteger(contractDecimals) || contractDecimals < 0 || contractDecimals > 18) {



          return LuxaUI.alert({



            title: "Invalid Decimals",



            desc: "Decimals must be a whole number from 0 to 18.",



            icon: "⚠️"



          });



        }







        const storageKey = `custom_tokens_${currentVault.address}`;



        const stored = await new Promise((resolve) => chrome.storage.local.get([storageKey], resolve));



        const currentList = Array.isArray(stored[storageKey]) ? stored[storageKey] : [];



        if (currentList.some((token) => String(token.contract || "").toLowerCase() === contractAddr.toLowerCase())) {



          return LuxaUI.alert({



            title: "Already Added",



            desc: "This token is already tracked in your asset list.",



            icon: "ℹ️"



          });



        }







        // Query initial live user balance on this contract right away!



        const initialBalance = await fetchOnChainTokenBalance(contractAddr, currentVault.address, contractDecimals);



        const tokenLogo = await resolveCustomTokenLogo(contractAddr, detectedSymbol);







        currentList.push({



          contract: contractAddr,



          name: finalName,



          symbol: detectedSymbol,



          decimals: contractDecimals,



          icon: tokenLogo || "",



          balance: initialBalance,



          totalSupply,



          lastUpdated: Date.now()



        });



        await new Promise((resolve) => chrome.storage.local.set({ [storageKey]: currentList }, resolve));







        importModal.style.display = "none";



        LuxaUI.toast(`Token ${detectedSymbol} imported (${initialBalance} ${detectedSymbol})!`, "✓");



        renderTokensList(currentVault.address);



      } catch (err) {



        LuxaUI.alert({



          title: "Import Rejected",



          desc: err.message || "Failed to inspect contract specifications.",



          icon: "❌"



        });



      } finally {



        btnSubmitImport.disabled = false;



        btnSubmitImport.textContent = "Import";



      }



    };



  }







  document.getElementById("btn-toggle-activity").onclick = async () => {



    const list = document.getElementById("activity-list");



    const address = vaults[activeIndex].address;



    historyOpen = true;



    list.style.display = "block";







    if (historyOpen) {



      const netStorage = await new Promise((resolve) => chrome.storage.local.get(["active_network"], resolve));



      const isTestnet = netStorage.active_network === "testnet";







      if (isTestnet) {



        list.textContent = "";



        const loadingMsg = document.createElement("div");



        loadingMsg.className = "act-item empty-act";



        loadingMsg.textContent = "Syncing Sandbox Testnet history...";



        list.appendChild(loadingMsg);







        try {



          const res = await fetch(`${BACKEND_API}/testnet/transactions?address=${encodeURIComponent(address)}`);



          const data = await res.json();



          if (!res.ok || data.success === false) throw new Error("Testnet history request failed");



          const txs = Array.isArray(data.txs) ? data.txs : [];







          list.textContent = "";



          if (!txs.length) {



            const emptyMsg = document.createElement("div");



            emptyMsg.className = "act-item empty-act";



            emptyMsg.textContent = "No sandbox transactions found.";



            list.appendChild(emptyMsg);



            return;



          }







          const fragment = document.createDocumentFragment();



          for (const tx of txs) {



            const item = document.createElement("div");



            item.className = "act-item";



            item.style.cssText = "display:flex; justify-content:space-between; align-items:center; padding:8px; border-bottom:1px solid rgba(246,196,83,0.15);";







            const leftCol = document.createElement("div");



            leftCol.style.cssText = "display:flex; flex-direction:column;";







            const isRecv = tx.flow === "IN";



            const typeLabel = document.createElement("span");



            typeLabel.style.cssText = `font-weight:600; font-size:12px; color:${isRecv ? "#22c55e" : "#f59e0b"};`;



            typeLabel.textContent = `${isRecv ? "↓ Received" : "↑ Sent"}: ${tx.amount ?? "Transfer"}`;







            const heightSpan = document.createElement("span");



            heightSpan.style.cssText = "font-family:monospace; font-size:10px; color:#88a0bf;";



            heightSpan.textContent = `Block ${tx.height ?? "N/A"}`;







            leftCol.append(typeLabel, heightSpan);







            const rightCol = document.createElement("div");



            const copyBtn = document.createElement("button");



            const txHash = String(tx.hash || "");



            copyBtn.type = "button";



            copyBtn.style.cssText = "color:#f59e0b; background:none; border:1px solid rgba(246,196,83,0.3); border-radius:4px; font-size:10px; font-family:monospace; cursor:pointer; padding:2px 6px;";



            const shortHash = txHash.length > 14 ? `${txHash.slice(0, 8)}...` : (txHash || "Hash N/A");



            copyBtn.textContent = txHash ? `${shortHash} 📋` : shortHash;



            copyBtn.disabled = !txHash;



            copyBtn.onclick = () => {



              navigator.clipboard.writeText(txHash);



              LuxaUI.toast("Hash copied! 📋", "⚡");



            };



            rightCol.appendChild(copyBtn);







            item.append(leftCol, rightCol);



            fragment.appendChild(item);



          }



          list.appendChild(fragment);



        } catch (err) {



          list.textContent = "";



          const errorMsg = document.createElement("div");



          errorMsg.className = "act-item empty-act";



          errorMsg.textContent = "Error reading testnet history.";



          list.appendChild(errorMsg);



        }



        return;



      }







      list.textContent = "";



      const loadingMsg = document.createElement("div");



      loadingMsg.className = "act-item empty-act";



      loadingMsg.textContent = "Querying the CometBFT ledger on luxa-1...";



      list.appendChild(loadingMsg);







      try {



        const queryRecv = encodeURIComponent(`transfer.recipient='${address}'`);



        const querySend = encodeURIComponent(`transfer.sender='${address}'`);







        const [rpcRecvRes, rpcSendRes] = await Promise.all([



          fetch(`${RPC_ENDPOINT}/tx_search?query="${queryRecv}"&page=1&per_page=15&order_by="desc"`).then(r => r.json()).catch(() => null),



          fetch(`${RPC_ENDPOINT}/tx_search?query="${querySend}"&page=1&per_page=15&order_by="desc"`).then(r => r.json()).catch(() => null)



        ]);







        const combinedList = [];



        const seenHashes = new Set();



        const rawRpcTxs = [...(rpcRecvRes?.result?.txs || []), ...(rpcSendRes?.result?.txs || [])];







        for (const t of rawRpcTxs) {



          const hash = t.hash ? String(t.hash).toUpperCase() : "";



          if (!hash || seenHashes.has(hash)) continue;



          seenHashes.add(hash);







          let isReceiver = true;



          let amountStr = "";



          const events = t.tx_result?.events || [];







          for (const ev of events) {



            for (const attr of ev.attributes || []) {



              const k = decodeAttr(attr.key);



              const v = decodeAttr(attr.value);



              if (k === "sender" && v.toLowerCase() === address.toLowerCase()) isReceiver = false;



              if (k === "recipient" && v.toLowerCase() === address.toLowerCase()) isReceiver = true;



              if (k === "amount" && typeof v === "string" && !amountStr) {



                const parts = v.split(",");



                const coins = [];



                for (const p of parts) {



                  const m = p.trim().match(/^(\d+)(uluxa|ushard)$/);



                  if (m) {



                    const num = parseInt(m[1], 10) / 1000000;



                    const denom = m[2] === "ushard" ? "SHARD" : "LUXA";



                    coins.push(`${num.toFixed(m[2] === "ushard" ? 0 : 4)} ${denom}`);



                  }



                }



                if (coins.length > 0) amountStr = coins.join(" + ");



              }



            }



          }







          combinedList.push({



            hash,



            height: t.height || "N/A",



            isReceiver,



            amount: amountStr || "On-chain transfer",



            type: isReceiver ? "↓ In" : "↑ Out"



          });



        }







        const cachedNfts = window._walletNftsCache || [];



        for (const nft of cachedNfts) {



          const nftHash = nft.txHash ? String(nft.txHash).toUpperCase() : "";



          if (nftHash && !seenHashes.has(nftHash)) {



            seenHashes.add(nftHash);



            combinedList.unshift({



              hash: nftHash,



              height: nft.blockHeight || "—",



              isReceiver: true,



              amount: `${nft.name || "Genesis Relic"} (#${nft.id})`,



              type: "↓ NFT Anchor"



            });



          }



        }







        combinedList.sort((a, b) => (parseInt(b.height, 10) || 0) - (parseInt(a.height, 10) || 0));







        list.textContent = "";



        if (combinedList.length === 0) {



          const emptyMsg = document.createElement("div");



          emptyMsg.className = "act-item empty-act";



          emptyMsg.textContent = "No recent transactions found on the ledger.";



          list.appendChild(emptyMsg);



          return;



        }







        const fragment = document.createDocumentFragment();



        for (const tx of combinedList) {



          const item = document.createElement("div");



          item.className = "act-item";



          item.style.cssText = "display:flex; justify-content:space-between; align-items:center; padding:8px; border-bottom:1px solid rgba(255,255,255,0.06);";







          const leftCol = document.createElement("div");



          leftCol.style.cssText = "display:flex; flex-direction:column;";







          const typeLabel = document.createElement("span");



          typeLabel.style.cssText = `font-weight:600; font-size:12px; color:${tx.isReceiver ? "#00b386" : "#e5484d"};`;



          typeLabel.textContent = `${tx.type} (${tx.amount})`;







          const heightSpan = document.createElement("span");



          heightSpan.style.cssText = "font-family:monospace; font-size:10px; color:#88a0bf;";



          heightSpan.textContent = `Block #${tx.height}`;







          leftCol.append(typeLabel, heightSpan);







          const rightCol = document.createElement("div");



          const link = document.createElement("a");



          link.href = `https://luxaecosystem.xyz/explorer.html?tx=${encodeURIComponent(tx.hash)}`;



          link.style.cssText = "color:#00FFCC; text-decoration:none; font-size:11px; font-family:monospace; cursor:pointer;";



          const shortHash = tx.hash.length > 12 ? `${tx.hash.slice(0, 6)}...${tx.hash.slice(-4)}` : tx.hash;



          link.innerHTML = `${shortHash} 🔗`;



          link.onclick = (e) => {



            e.preventDefault();



            chrome.tabs.create({ url: link.href });



          };



          rightCol.appendChild(link);







          item.append(leftCol, rightCol);



          fragment.appendChild(item);



        }



        list.appendChild(fragment);







      } catch (err) {



        list.textContent = "";



        const errorMsg = document.createElement("div");



        errorMsg.className = "act-item empty-act";



        errorMsg.textContent = "Unable to retrieve ledger history.";



        list.appendChild(errorMsg);



      }



    }



  };








  function openBuyModal() {
    const modal = document.getElementById("buy-modal-overlay");
    if (!modal) {
      const url = "https://ldex.luxaecosystem.xyz/";
      if (window.chrome && chrome.tabs && chrome.tabs.create) { chrome.tabs.create({ url }); } else { window.open(url, "_blank"); }
      return;
    }
    modal.style.display = "flex";

    const closeBtn = document.getElementById("btn-close-buy-modal");
    if (closeBtn) closeBtn.onclick = () => { modal.style.display = "none"; };

    const openTerminalBtn = document.getElementById("btn-open-ldex-terminal");
    if (openTerminalBtn) {
      openTerminalBtn.onclick = () => {
        modal.style.display = "none";
        const url = "https://ldex.luxaecosystem.xyz/";
        if (window.chrome && chrome.tabs && chrome.tabs.create) { chrome.tabs.create({ url }); } else { window.open(url, "_blank"); }
      };
    }

    const items = modal.querySelectorAll(".buy-token-item");
    items.forEach(item => {
      item.onclick = () => {
        const sym = item.getAttribute("data-symbol") || "LUXA";
        modal.style.display = "none";
        const targetPair = sym === "LUXA" ? "" : `?pair=${encodeURIComponent(sym)}/LUXA`;
        const url = `https://ldex.luxaecosystem.xyz/${targetPair}`;
        LuxaUI.toast(`Opening LDEX to buy ${sym}... ⚡`, "🛒");
        if (window.chrome && chrome.tabs && chrome.tabs.create) { chrome.tabs.create({ url }); } else { window.open(url, "_blank"); }
      };
    });
  }

      function drawLogoOnQrCanvas(canvas, logoSrc) {
    return new Promise((resolve) => {
      if (!canvas || !logoSrc) return resolve();
      const ctx = canvas.getContext("2d");
      if (!ctx) return resolve();

      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        try {
          const qrSize = canvas.width || 176;
          const center = qrSize / 2;
          const badgeSize = Math.round(qrSize * 0.23);
          const radius = badgeSize / 2;

          ctx.save();

          // 1. Circular white badge background
          ctx.beginPath();
          ctx.arc(center, center, radius + 3, 0, Math.PI * 2);
          ctx.fillStyle = "#ffffff";
          ctx.shadowColor = "rgba(0, 0, 0, 0.35)";
          ctx.shadowBlur = 5;
          ctx.fill();

          // 2. Neon cyan accent ring around badge
          ctx.beginPath();
          ctx.arc(center, center, radius + 3, 0, Math.PI * 2);
          ctx.lineWidth = 2;
          ctx.strokeStyle = "#00FFCC";
          ctx.stroke();

          // 3. Clip circular region for the coin logo
          ctx.beginPath();
          ctx.arc(center, center, radius, 0, Math.PI * 2);
          ctx.clip();

          // White background inside clip
          ctx.fillStyle = "#ffffff";
          ctx.fill();

          // 4. Draw image inside badge
          ctx.drawImage(img, center - radius, center - radius, badgeSize, badgeSize);

          ctx.restore();
        } catch (e) {
          console.warn("[QR] Failed overlaying logo:", e);
        }
        resolve();
      };
      img.onerror = () => {
        resolve();
      };
      img.src = logoSrc;
    });
  }

  async function openReceiveModal(address, token = null) {
    const modal = document.getElementById("receive-modal-overlay");
    const canvas = document.getElementById("receive-qr-canvas");
    const addrEl = document.getElementById("receive-modal-address");
    const copyBtn = document.getElementById("btn-copy-receive");
    const closeBtn = document.getElementById("btn-close-receive");
    const indicatorEl = document.getElementById("receive-chain-indicator");
    const tabsContainer = document.getElementById("receive-chain-tabs");

    if (!modal || !canvas || !addrEl || !copyBtn || !closeBtn) return;

    modal.style.display = "flex";
    closeBtn.onclick = () => { modal.style.display = "none"; };

    let currentPrefix = "luxa";
    let currentChainName = "LUXA (luxa-1)";

    if (token && IBC_ASSETS_MAP[token.symbol]) {
      currentPrefix = IBC_ASSETS_MAP[token.symbol].prefix;
      currentChainName = `${IBC_ASSETS_MAP[token.symbol].chain} (${currentPrefix})`;
    }

    async function setReceiveChain(prefix, name) {
      currentPrefix = prefix;
      currentChainName = name;

      if (indicatorEl) indicatorEl.textContent = `CHAIN: ${name}`;

      const targetAddr = prefix === "luxa" ? address : convertCosmosAddress(address, prefix);
      addrEl.textContent = targetAddr;

      if (tabsContainer) {
        tabsContainer.querySelectorAll(".receive-chain-tab").forEach(tab => {
          tab.classList.toggle("active", tab.getAttribute("data-prefix") === prefix);
        });
      }

      const chainLogoMap = {
        luxa: "../icons/logoluxa.png",
        celestia: "../icons/celestia.png",
        cosmos: "../icons/atom.png",
        osmo: "../icons/osmo.png",
        noble: "../icons/noble.png"
      };

      let coinLogoSrc = chainLogoMap[prefix] || "../icons/logoluxa.png";
      if (prefix === "luxa" && token && token.symbol === "SHARD") {
        coinLogoSrc = "../icons/shard128.png";
      } else if (prefix === "noble" && token && token.symbol === "USDC") {
        coinLogoSrc = "../icons/usdc.png";
      }

      try {
        if (window.QRCode && typeof window.QRCode.toCanvas === "function") {
          await window.QRCode.toCanvas(canvas, targetAddr, {
            width: 176,
            margin: 2,
            errorCorrectionLevel: "H",
            color: { dark: "#070913", light: "#ffffff" }
          });
          await drawLogoOnQrCanvas(canvas, coinLogoSrc);
        }
      } catch (err) {
        console.error("QR render error:", err);
      }
    }

    if (tabsContainer) {
      tabsContainer.querySelectorAll(".receive-chain-tab").forEach(tab => {
        tab.onclick = () => {
          const prefix = tab.getAttribute("data-prefix");
          const name = tab.getAttribute("data-name");
          setReceiveChain(prefix, name);
        };
      });
    }

    copyBtn.onclick = () => {
      const txt = addrEl.textContent.trim();
      navigator.clipboard.writeText(txt).then(() => {
        const orig = copyBtn.textContent;
        copyBtn.textContent = "Copied! ✓";
        setTimeout(() => { copyBtn.textContent = orig; }, 1500);
      });
    };

    setReceiveChain(currentPrefix, currentChainName);
  }

  
  async function fetchWithFallback(urls, signal) {
    for (const u of urls) {
      try {
        const res = await fetch(u, { signal });
        if (res.ok) return await res.json();
      } catch (_) {}
    }
    return null;
  }

  async function refreshAllChainBalances(address) {
    if (!address || !address.startsWith("luxa1")) return;

    // Check if wallet is still the currently active wallet
    if (vaults[activeIndex]?.address !== address) return;

    // 1. Trigger live price fetch concurrently (non-blocking) so on-chain balances load immediately
    fetchLiveCoinGeckoPrices().then(() => {
      updatePortfolioTotalUI();
    }).catch(() => {});

    const celestiaAddr = convertCosmosAddress(address, "celestia");
    const cosmosAddr = convertCosmosAddress(address, "cosmos");
    const osmoAddr = convertCosmosAddress(address, "osmo");
    const nobleAddr = convertCosmosAddress(address, "noble");

    // Fresh zero-initialized balances for THIS specific wallet address
    const targetBalances = getFreshVaultBalances();
    const targetHoldings = getFreshMultiChainHoldings();

    const fetches = [
      // 1. Native & IBC Vouchers on LUXA L1 (Primary: Sovereign REST node, Fallback: Backend Public Balances API)
      fetchWithFallback([
        `${LIVE_COSMOS_REST}/cosmos/bank/v1beta1/balances/${encodeURIComponent(address)}`,
        `${BACKEND_API}/ecosystem/chain/balances-public/${encodeURIComponent(address)}`
      ], AbortSignal.timeout(6000))
        .then(data => {
          if (data?.balances) {
            if (Array.isArray(data.balances)) {
              for (const b of data.balances) {
                const den = (b.denom || "").toLowerCase();
                const amtNum = parseFloat(b.amount || "0") / 1e6;
                const amtStr = amtNum.toFixed(6);
                if (den === "uluxa") {
                  targetBalances.luxa = amtNum.toFixed(2);
                } else if (den === "ushard") {
                  targetBalances.shards = amtNum.toFixed(2);
                } else if (den.includes("9117a26ba81e29fa4f78f57dc2bd90cd3d26848101ba880445f119b22a1e254e")) {
                  targetBalances.atom = amtStr;
                } else if (den.includes("bf28d9c17e0306b194d50f51c3b2590bead15e04e03add34c3a26e62d85c9676")) {
                  targetBalances.tia = amtStr;
                } else if (den.includes("0471f1c4e7afd3f07702bef6dc365268d64570f7c1fdc98ea6098dd6de59817b")) {
                  targetBalances.osmo = amtStr;
                } else if (den.includes("bff0d3805b50d93e2fa5c0b2ddf7e0b30a631076cd80bc12a48c0e95404b4a41")) {
                  targetBalances.usdc = amtStr;
                }
              }
            } else if (typeof data.balances === "object") {
              const lVal = parseFloat(data.balances.luxa || 0);
              const sVal = parseFloat(data.balances.shards || 0);
              targetBalances.luxa = lVal.toFixed(2);
              targetBalances.shards = String(Math.round(sVal));
            }
          }
        }).catch(err => console.warn("LUXA L1 balance fetch error:", err)),

      // 2. Celestia (Native TIA)
      fetchWithFallback([
        `https://rest.cosmos.directory/celestia/cosmos/bank/v1beta1/balances/${celestiaAddr}`,
        `https://celestia-api.polkachu.com/cosmos/bank/v1beta1/balances/${celestiaAddr}`
      ], AbortSignal.timeout(6000))
        .then(res => {
          if (res?.balances && Array.isArray(res.balances)) {
            for (const b of res.balances) {
              const den = (b.denom || "").toLowerCase();
              const amt = (parseFloat(b.amount || "0") / 1e6).toFixed(6);
              if (den === "utia") {
                targetHoldings.external_natives.tia = amt;
                targetBalances.tia_ext = amt;
              } else if (den.startsWith("ibc/")) {
                targetHoldings.luxa_external.celestia = amt;
              }
            }
          }
        }).catch(() => {}),

      // 3. Cosmos Hub (Native ATOM)
      fetchWithFallback([
        `https://rest.cosmos.directory/cosmoshub/cosmos/bank/v1beta1/balances/${cosmosAddr}`,
        `https://cosmos-rest.publicnode.com/cosmos/bank/v1beta1/balances/${cosmosAddr}`
      ], AbortSignal.timeout(6000))
        .then(res => {
          if (res?.balances && Array.isArray(res.balances)) {
            for (const b of res.balances) {
              const den = (b.denom || "").toLowerCase();
              const amt = (parseFloat(b.amount || "0") / 1e6).toFixed(6);
              if (den === "uatom") {
                targetHoldings.external_natives.atom = amt;
                targetBalances.atom_ext = amt;
              } else if (den.startsWith("ibc/")) {
                targetHoldings.luxa_external.cosmoshub = amt;
              }
            }
          }
        }).catch(() => {}),

      // 4. Osmosis (Native OSMO)
      fetchWithFallback([
        `https://rest.cosmos.directory/osmosis/cosmos/bank/v1beta1/balances/${osmoAddr}`,
        `https://osmosis-rest.publicnode.com/cosmos/bank/v1beta1/balances/${osmoAddr}`
      ], AbortSignal.timeout(6000))
        .then(res => {
          if (res?.balances && Array.isArray(res.balances)) {
            for (const b of res.balances) {
              const den = (b.denom || "").toLowerCase();
              const amt = (parseFloat(b.amount || "0") / 1e6).toFixed(6);
              if (den === "uosmo") {
                targetHoldings.external_natives.osmo = amt;
                targetBalances.osmo_ext = amt;
              } else if (den.startsWith("ibc/")) {
                targetHoldings.luxa_external.osmosis = amt;
              }
            }
          }
        }).catch(() => {}),

      // 5. Noble (Native USDC)
      fetchWithFallback([
        `https://rest.cosmos.directory/noble/cosmos/bank/v1beta1/balances/${nobleAddr}`,
        `https://noble-api.polkachu.com/cosmos/bank/v1beta1/balances/${nobleAddr}`
      ], AbortSignal.timeout(6000))
        .then(res => {
          if (res?.balances && Array.isArray(res.balances)) {
            for (const b of res.balances) {
              const den = (b.denom || "").toLowerCase();
              const amt = (parseFloat(b.amount || "0") / 1e6).toFixed(6);
              if (den === "uusdc") {
                targetHoldings.external_natives.usdc = amt;
                targetBalances.usdc_ext = amt;
              } else if (den.startsWith("ibc/")) {
                targetHoldings.luxa_external.noble = amt;
              }
            }
          }
        }).catch(() => {})
    ];

    await Promise.allSettled(fetches);

    // If active wallet changed during in-flight fetches, discard to avoid race condition!
    if (vaults[activeIndex]?.address !== address) return;

    const totalLuxa = (
      parseFloat(targetBalances.luxa || 0) +
      parseFloat(targetHoldings.luxa_external.celestia || 0) +
      parseFloat(targetHoldings.luxa_external.cosmoshub || 0) +
      parseFloat(targetHoldings.luxa_external.noble || 0) +
      parseFloat(targetHoldings.luxa_external.osmosis || 0)
    ).toFixed(2);
    targetHoldings.luxa_total = totalLuxa;

    // Apply verified target balances to state
    vaultBalances = targetBalances;
    multiChainHoldings = targetHoldings;

    // Cache per-wallet balances in storage
    try {
      chrome.storage.local.set({
        [`cached_balances_${address}`]: {
          vaultBalances: targetBalances,
          multiChainHoldings: targetHoldings,
          updatedAt: Date.now()
        }
      });
    } catch (_) {}

    updatePortfolioTotalUI();
    await renderTokensList(address);
  }

  function showDashboard() {



    hideAllViews();







    // Safety deduplication



    if (vaults.length > 1) {



      const seen = new Set();



      const unique = [];



      let dup = false;



      for (const v of vaults) {



        const a = String(v?.address || "").trim().toLowerCase();



        if (a && seen.has(a)) {



          dup = true;



        } else if (a) {



          seen.add(a);



          unique.push(v);



        }



      }



      if (dup) {



        vaults = unique;



        if (activeIndex >= vaults.length) activeIndex = 0;



        chrome.storage.local.set({



          luxa_vaults: vaults,



          luxa_vault: vaults[activeIndex],



          active_wallet_idx: activeIndex



        });



      }



    }







    const cur = vaults[activeIndex];

    if (!cur) return showNoWalletScreen();

    chrome.storage.local.set({ luxa_vault: cur, active_wallet_idx: activeIndex });

    // Load cached balances for cur.address immediately (prevents old wallet numbers from sticking)
    const cachedKey = `cached_balances_${cur.address}`;
    chrome.storage.local.get([cachedKey], (stored) => {
      if (vaults[activeIndex]?.address !== cur.address) return;
      if (stored && stored[cachedKey]) {
        vaultBalances = stored[cachedKey].vaultBalances || getFreshVaultBalances();
        multiChainHoldings = stored[cachedKey].multiChainHoldings || getFreshMultiChainHoldings();
      } else {
        vaultBalances = getFreshVaultBalances();
        multiChainHoldings = getFreshMultiChainHoldings();
      }
      updatePortfolioTotalUI();
      renderTokensList(cur.address);
    });



    if (vaultTopBar) vaultTopBar.style.display = "flex";



    if (networkToggleStrip) networkToggleStrip.style.display = "flex";



    viewDashboard.style.display = "block";



    chrome.storage.local.get(["active_network"], (data) => {



      updateNetworkUI(data.active_network || "testnet");



    });



    switchTab("tokens");



    historyOpen = false;



    const activityList = document.getElementById("activity-list");



    if (activityList) activityList.style.display = "none";



    renderTokensList(cur.address);
    refreshAllChainBalances(cur.address);



    checkCurrentTabConnection();







    walletSelector.replaceChildren();



    vaults.forEach((v, idx) => {



      const opt = document.createElement("option");



      opt.value = idx;



      const short = v.address.slice(0, 8) + "..." + v.address.slice(-4);



      opt.textContent = `${v.name || `Wallet ${idx + 1}`} (${short})`;



      if (idx === activeIndex) opt.selected = true;



      walletSelector.appendChild(opt);



    });







    document.getElementById("full-address-text").textContent = cur.address;



    document.getElementById("display-address").onclick = () => {



      navigator.clipboard.writeText(cur.address);



      LuxaUI.toast("Address copied! 📋", "⚡");



    };







    const imgEl = document.getElementById("user-avatar-img");



    const fallbackEl = document.getElementById("user-avatar-fallback");



    const nameEl = document.getElementById("user-display-name");



    const tagEl = document.getElementById("user-display-tag");







    fetch(`${BACKEND_API}/ecosystem/wallet/profile/${encodeURIComponent(cur.address)}`)



      .then(r => r.json())



      .then(d => {



        if (d.success && d.user) {



          if (d.user.photoUrl) {



            imgEl.src = d.user.photoUrl;



            imgEl.style.display = "block";



            fallbackEl.style.display = "none";



          } else {



            imgEl.style.display = "none";



            fallbackEl.style.display = "block";



            fallbackEl.textContent = (d.user.username || cur.name || "M")[0].toUpperCase();



          }



          nameEl.textContent = d.user.username ? `@${d.user.username}` : (d.user.fullName || cur.name || "LUXA Miner");



          tagEl.textContent = d.user.telegramId ? `ID: ${d.user.telegramId}` : "luxa-1";



        } else {



          chrome.storage.local.get(["google_account"], (gd) => {



            if (gd.google_account?.picture) {



              imgEl.src = gd.google_account.picture;



              imgEl.style.display = "block";



              fallbackEl.style.display = "none";



              nameEl.textContent = gd.google_account.name || cur.name || "LUXA Miner";



              tagEl.textContent = "luxa-1";



            }



          });



        }



      })



      .catch(() => {});







    chrome.storage.local.get(["active_network"], async (netData) => {



      const isTestnet = netData.active_network === "testnet";



      renderNetworkMetrics(isTestnet);







      if (isTestnet) {



        try {



          const res = await fetch(`${BACKEND_API}/testnet/balances/${encodeURIComponent(cur.address)}`);



          const d = await res.json();



          if (d.success && d.balances) {



            const lVal = parseFloat(d.balances.luxa || 0);



            const sVal = parseFloat(d.balances.shards || 0);



            vaultBalances.luxa = lVal.toFixed(4);



            vaultBalances.shards = String(Math.round(sVal));







            const balanceEl = document.getElementById("main-luxa-balance");



            if (balanceEl) {



              balanceEl.textContent = `${lVal.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} tLUXA`;
              updatePortfolioTotalUI();



              balanceEl.title = `${lVal.toLocaleString("en-US")} tLUXA`;



            }



            document.getElementById("onchain-raw-micro").textContent = (Math.round(lVal * 1000000)).toLocaleString();



            document.getElementById("onchain-shards-val").textContent = `${Math.round(sVal).toLocaleString()} tSHARDS`;



            renderTokensList(cur.address);



          }



        } catch (e) {



          console.warn("[Testnet Balance Error]:", e);



        }



      } else {

        // Mainnet/Production balances are unified and authoritatively managed by refreshAllChainBalances
        // ensuring instant wallet isolation without duplicate race conditions.

      }



    });







    loadWalletNfts(cur.address);



    loadWalletLpPositions(cur.address);







    document.getElementById("btn-send").onclick = () => {



      viewDashboard.style.display = "none";



      viewSend.style.display = "block";



      document.getElementById("extRecipientInput").value = "";



      document.getElementById("extAmountInput").value = "";



      switchVaultToken(pendingSendToken || "luxa");



      pendingSendToken = null;



    };







    const btnBuy = document.getElementById("btn-buy");
    if (btnBuy) {
      btnBuy.classList.remove("is-disabled");
      btnBuy.removeAttribute("disabled");
      btnBuy.title = "Buy & Trade on LDEX Sovereign DEX";
      const soonBadge = btnBuy.querySelector(".mm-soon-badge");
      if (soonBadge) soonBadge.style.display = "none";
      btnBuy.onclick = openBuyModal;
    }

    const btnSwap = document.getElementById("btn-swap");



    if (btnSwap) {



      btnSwap.onclick = openInAppSwap;



    }







    document.getElementById("btn-words").onclick = async () => {



      const pin = await LuxaUI.prompt({



        title: "Security Check",



        desc: "Enter your PIN to view the 24 secret words:",



        placeholder: "4-digit PIN",



        icon: "🔒",



        isPassword: true,



        rows: 1



      });



      if (!pin) return;



      try {



        const words = await decryptMnemonic(cur.encrypted, pin);



        await LuxaUI.alert({



          title: "Recovery Phrase",



          desc: `<div style="text-align:left; font-family:monospace; background:#f4f6f8; padding:12px; border-radius:10px; color:#0b1220; font-size:11px; line-height:1.7;">${words}</div>`,



          icon: "🔑",



          btnText: "I Saved the Words"



        });



      } catch (err) { LuxaUI.toast(err.message, "❌"); }



    };







    document.getElementById("btn-receive").onclick = () => {



      if (cur.address) openReceiveModal(cur.address);



    };



  }







  walletSelector.onchange = (e) => {

    activeIndex = parseInt(e.target.value, 10);

    const selected = vaults[activeIndex];
    if (!selected) return;

    // Immediately reset global state to zeroes so previous wallet values vanish instantly
    vaultBalances = getFreshVaultBalances();
    multiChainHoldings = getFreshMultiChainHoldings();

    // Immediately wipe DOM to prevent old wallet values from lingering
    const balEl = document.getElementById("main-luxa-balance");
    if (balEl) balEl.textContent = "0.00 LUXA";
    const totEl = document.getElementById("main-portfolio-total-usd");
    if (totEl) totEl.textContent = "$0.00";
    const pnlEl = document.getElementById("portfolio-pnl-value");
    if (pnlEl) {
      pnlEl.className = "portfolio-pnl-value pnl-neutral";
      pnlEl.textContent = "+$0.00 (+0.00%)";
    }
    const rawMicro = document.getElementById("onchain-raw-micro");
    if (rawMicro) rawMicro.textContent = "0";
    const shardsVal = document.getElementById("onchain-shards-val");
    if (shardsVal) shardsVal.textContent = "0";
    const fullAddr = document.getElementById("full-address-text");
    if (fullAddr) fullAddr.textContent = selected.address;

    updatePortfolioTotalUI();
    renderTokensList(selected.address);

    chrome.storage.local.set({ active_wallet_idx: activeIndex, luxa_vault: selected }, () => {

      broadcastVaultState("BROADCAST_VAULT_UNLOCKED", selected.address);

      broadcastVaultState("VAULT_READY_BROADCAST", selected.address);

      LuxaUI.toast(`Selected: ${selected.name}`, "⚡");

      showDashboard();

    });

  };







  const pillLuxa = document.getElementById("extPillLuxa");



  const pillShards = document.getElementById("extPillShards");



  document.querySelectorAll(".pill-container .pill").forEach(pill => {
    pill.onclick = () => {
      const tok = pill.getAttribute("data-token");
      if (tok) switchVaultToken(tok);
    };
  });



  const btnAssetTrigger = document.getElementById("btn-asset-select-trigger");
  if (btnAssetTrigger) btnAssetTrigger.onclick = openAssetSelectorModal;

  const btnAssetQuick = document.getElementById("btn-select-asset-quick");
  if (btnAssetQuick) btnAssetQuick.onclick = openAssetSelectorModal;

  const btnMax = document.getElementById("extBtnMax");



  if (btnMax) btnMax.onclick = handleMaxClick;







  document.getElementById("extBtnSubmitSend").onclick = async () => {



    const cur = vaults[activeIndex];



    const recipient = document.getElementById("extRecipientInput").value.trim();



    const amountStr = document.getElementById("extAmountInput").value.trim();



    const pin = await LuxaUI.prompt({



      title: "Sign Transaction",



      desc: "Enter your PIN to sign and broadcast the transaction:",



      placeholder: "4-digit PIN",



      icon: "🔒",



      isPassword: true,



      rows: 1



    });



    if (!pin) return;







    let mnemonic = "";



    try { mnemonic = await decryptMnemonic(cur.encrypted, pin); }



    catch (err) { return LuxaUI.alert({ title: "Access Denied", desc: err.message, icon: "❌" }); }







    const confirmBtn = document.getElementById("extBtnSubmitSend");



    let fromChain = "luxa";
    const chLower = String(currentSelectedChain || "").toLowerCase();
    if (chLower.includes("cosmos")) fromChain = "cosmoshub";
    else if (chLower.includes("celestia")) fromChain = "celestia";
    else if (chLower.includes("osmosis")) fromChain = "osmosis";
    else if (chLower.includes("noble")) fromChain = "noble";

    confirmBtn.disabled = true;
    confirmBtn.textContent = fromChain !== "luxa" ? "Bridging IBC... ⏳" : "Signing... ⏳";

    chrome.runtime.sendMessage(
      {
        action: "SEND_TRANSACTION",
        mnemonic,
        recipient,
        amount: parseFloat(amountStr),
        fromChain,
        denom: fromChain === "cosmoshub" ? "uatom" : (
          fromChain === "celestia" ? "utia" :
          fromChain === "osmosis" ? "uosmo" :
          fromChain === "noble" ? "uusdc" : (
            currentSelectedToken === "tia" ? "ibc/BF28D9C17E0306B194D50F51C3B2590BEAD15E04E03ADD34C3A26E62D85C9676" :
            currentSelectedToken === "usdc" ? "ibc/BFF0D3805B50D93E2FA5C0B2DDF7E0B30A631076CD80BC12A48C0E95404B4A41" :
            currentSelectedToken === "atom" ? "ibc/9117A26BA81E29FA4F78F57DC2BD90CD3D26848101BA880445F119B22A1E254E" :
            currentSelectedToken === "osmo" ? "ibc/0471F1C4E7AFD3F07702BEF6DC365268D64570F7C1FDC98EA6098DD6DE59817B" :
            (currentSelectedToken === "shards" || currentSelectedToken === "shard" ? "ushard" : "uluxa")
          )
        )
      },
      async (res) => {
        confirmBtn.disabled = false;
        confirmBtn.textContent = "Sign & Send";

        if (res?.error) return LuxaUI.alert({ title: "Transaction Failed", desc: res.error, icon: "❌" });

        if (res?.result?.network && res.result.network !== "luxa-testnet" && res.result.network !== "luxa-1") {
          await LuxaUI.alert({
            title: "IBC Transfer Broadcasted! ⚡",
            desc: `Successfully sent <b>${res.result.amount} ${currentSelectedToken.toUpperCase()}</b> from <b>${res.result.network}</b> to LUXA Network!<br><br><span style="font-family:monospace; font-size:10px; color:#94a3b8;">Tx Hash: ${res.result.txHash}</span><br><br><span style="color:#00FFCC; font-size:11px;">Tokens will arrive in your LUXA wallet in ~20-30 seconds via IBC Relayer.</span>`,
            icon: "⚡",
            btnText: "Back to Dashboard"
          });
          showDashboard();
          return;
        }







        await LuxaUI.alert({



          title: "Broadcast on luxa-1! 🚀",



          desc: `Transaction recorded in block <b>#${res.result.height}</b>.<br><br><span style="font-family:monospace; font-size:10px; color:#94a3b8;">Hash: ${res.result.txHash}</span>`,



          icon: "⚡",



          btnText: "Back to Dashboard"



        });



        showDashboard();



      }



    );



  };







  document.getElementById("extBtnCancel").onclick = () => showDashboard();



  document.getElementById("btn-back-home").onclick = () => showDashboard();







  // ---------- QR CODE SCANNER (Camera & Image) ----------



  let qrStream = null;



  let qrScanActive = false;



  let qrAnimFrameId = null;







  function handleScannedAddress(raw) {



    if (!raw) return false;



    const trimmed = String(raw).trim();



    const match = trimmed.match(/luxa1[a-z0-9]{38,65}/i);



    let addr = '';



    if (match) {



      addr = match[0].toLowerCase();



    } else {



      addr = trimmed.replace(/^[a-z0-9+.-]+:/i, '').trim().toLowerCase().replace(/[^a-z0-9]/g, '');



    }







    if (addr && addr.startsWith('luxa1')) {



      const recipientInput = document.getElementById("extRecipientInput");



      if (recipientInput) recipientInput.value = addr;



      closeQrScanner();



      if (navigator.vibrate) try { navigator.vibrate(50); } catch (_) {}



      LuxaUI.toast(`Scanned: ${addr.slice(0, 10)}...${addr.slice(-6)}`, "⚡");



      return true;



    }



    return false;



  }







  async function openQrScanner() {



    const modal = document.getElementById("modal-qr-scanner");



    const video = document.getElementById("qr-video-feed");



    const status = document.getElementById("qr-scan-status");



    if (!modal || !video) return;







    modal.style.display = "flex";



    if (status) status.textContent = "Starting camera...";







    try {



      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {



        qrStream = await navigator.mediaDevices.getUserMedia({



          video: { facingMode: { ideal: "environment" } }



        });



        video.srcObject = qrStream;



        await video.play();



        qrScanActive = true;



        if (status) status.textContent = "Align QR code inside box";



        startQrScanningLoop();



      } else {



        throw new Error("Camera not accessible on this device.");



      }



    } catch (err) {



      console.warn("[QR Scanner] Camera error:", err);



      if (status) status.textContent = "Camera unavailable. Pick an image below.";



    }



  }







  function startQrScanningLoop() {



    const video = document.getElementById("qr-video-feed");



    const canvas = document.getElementById("qr-scan-canvas");



    const ctx = canvas ? canvas.getContext("2d", { willReadFrequently: true }) : null;







    let hasBarcodeDetector = typeof window.BarcodeDetector !== "undefined";



    let barcodeDetector = null;



    if (hasBarcodeDetector) {



      try {



        barcodeDetector = new BarcodeDetector({ formats: ["qr_code"] });



      } catch (_) {



        barcodeDetector = null;



      }



    }







    const tick = async () => {



      if (!qrScanActive) return;







      if (video && video.readyState === video.HAVE_ENOUGH_DATA) {



        if (barcodeDetector) {



          try {



            const codes = await barcodeDetector.detect(video);



            if (codes && codes.length > 0 && codes[0].rawValue) {



              if (handleScannedAddress(codes[0].rawValue)) return;



            }



          } catch (_) {}



        }







        if (typeof window.jsQR !== "undefined" && canvas && ctx) {



          canvas.width = video.videoWidth;



          canvas.height = video.videoHeight;



          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);



          const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);



          const code = window.jsQR(imgData.data, imgData.width, imgData.height, {



            inversionAttempts: "dontInvert"



          });



          if (code && code.data) {



            if (handleScannedAddress(code.data)) return;



          }



        }



      }







      if (qrScanActive) {



        qrAnimFrameId = requestAnimationFrame(tick);



      }



    };







    qrAnimFrameId = requestAnimationFrame(tick);



  }







  function closeQrScanner() {



    qrScanActive = false;



    if (qrAnimFrameId) {



      cancelAnimationFrame(qrAnimFrameId);



      qrAnimFrameId = null;



    }



    if (qrStream) {



      qrStream.getTracks().forEach((track) => track.stop());



      qrStream = null;



    }



    const video = document.getElementById("qr-video-feed");



    if (video) video.srcObject = null;



    const modal = document.getElementById("modal-qr-scanner");



    if (modal) modal.style.display = "none";



  }







  function handleQrFileInput(e) {



    const file = e.target.files && e.target.files[0];



    if (!file) return;







    const reader = new FileReader();



    reader.onload = function(evt) {



      const img = new Image();



      img.onload = async function() {



        const canvas = document.createElement("canvas");



        canvas.width = img.width;



        canvas.height = img.height;



        const ctx = canvas.getContext("2d");



        ctx.drawImage(img, 0, 0);







        if (typeof window.BarcodeDetector !== "undefined") {



          try {



            const detector = new BarcodeDetector({ formats: ["qr_code"] });



            const codes = await detector.detect(canvas);



            if (codes && codes.length > 0 && codes[0].rawValue) {



              if (handleScannedAddress(codes[0].rawValue)) return;



            }



          } catch (_) {}



        }







        if (typeof window.jsQR !== "undefined") {



          const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);



          const code = window.jsQR(imgData.data, imgData.width, imgData.height);



          if (code && code.data) {



            if (handleScannedAddress(code.data)) return;



          }



        }







        LuxaUI.toast("No valid LUXA address found in image.", "⚠️");



      };



      img.src = evt.target.result;



    };



    reader.readAsDataURL(file);



  }







  const btnOpenScanner = document.getElementById("btn-open-recipient-scanner");



  if (btnOpenScanner) btnOpenScanner.onclick = openQrScanner;







  const btnOpenScannerInline = document.getElementById("btn-open-recipient-scanner-inline");



  if (btnOpenScannerInline) btnOpenScannerInline.onclick = openQrScanner;







  const btnCloseScanner = document.getElementById("btn-close-qr-scanner");



  if (btnCloseScanner) btnCloseScanner.onclick = closeQrScanner;







  const btnDismissScanner = document.getElementById("btn-dismiss-qr-scanner");



  if (btnDismissScanner) btnDismissScanner.onclick = closeQrScanner;







  const filePickerScanner = document.getElementById("qr-file-picker");



  if (filePickerScanner) filePickerScanner.onchange = handleQrFileInput;







  document.getElementById("btn-disconnect").onclick = () => {



    chrome.storage.local.set({ is_unlocked: false }, () => {



      broadcastVaultState("BROADCAST_VAULT_LOCKED");



      LuxaUI.toast("Vault locked", "🔒");



      showUnlockScreen();



    });



  };







  // --- DAPP CONNECTION AUTHORIZATION (WEB & MOBILE) ---



  window.handleLuxaConnectRequest = function(req) {



    if (!req) return;



    chrome.storage.local.get(["is_unlocked", "luxa_vault", "luxa_vaults", "active_wallet_idx", "connected_sites"], (data) => {



      const allVaults = data.luxa_vaults || (data.luxa_vault ? [data.luxa_vault] : []);



      if (!allVaults.length) {



        if (typeof LuxaUI !== "undefined" && LuxaUI.alert) {



          LuxaUI.alert({



            title: "No Vault Available",



            desc: "Please create or import a LUXA Vault before connecting.",



            icon: "⚠️"



          });



        }



        return;



      }







      if (!data.is_unlocked) {



        window._pendingConnectRequest = req;



        showUnlockScreen();



        const subtitle = document.querySelector("#view-unlock .vault-subtitle");



        if (subtitle && req.origin) {



          subtitle.innerHTML = `Unlock to authorize connection with <b style="color:var(--cyan);">${escapeHtml(req.origin)}</b>`;



        }



        return;



      }







      const idx = Number.isInteger(data.active_wallet_idx) && data.active_wallet_idx < allVaults.length ? data.active_wallet_idx : 0;



      const activeVault = allVaults[idx];







      showApproveConnectScreen(req.origin, activeVault.address);







      const btnApprove = document.getElementById("btn-auth-approve");



      const btnReject = document.getElementById("btn-auth-reject");







      if (btnReject) {



        btnReject.onclick = async () => {



          hideAllViews();



          showDashboard();



          if (req.reqId && !window.Capacitor?.isNativePlatform?.()) {



            chrome.runtime.sendMessage({ action: "RESOLVE_CONNECT_REQUEST", reqId: req.reqId, approved: false }, () => {



              if (typeof window.close === "function") window.close();



            });



          }



          if (req.callback) {



            try {



              const u = new URL(req.callback);



              u.searchParams.set("luxa_status", "rejected");



              u.searchParams.set("luxa_error", "Connection rejected by user");







              if (window.CapacitorBrowser) {



                try { await window.CapacitorBrowser.close(); } catch (_) {}



              }







              let openedExternal = false;



              if (window.LuxaNativeNav && typeof window.LuxaNativeNav.openExternalUrl === "function") {



                openedExternal = await window.LuxaNativeNav.openExternalUrl(u.toString());



              }







              if (!openedExternal) {



                try {



                  window.open(u.toString(), "_system");



                } catch (_) {



                  if (chrome.tabs && chrome.tabs.create) {



                    chrome.tabs.create({ url: u.toString() });



                  }



                }



              }







              if (window.CapacitorApp && typeof window.CapacitorApp.minimizeApp === "function") {



                setTimeout(() => {



                  try { window.CapacitorApp.minimizeApp(); } catch (_) {}



                }, 350);



              }



            } catch (_) {}



          }



        };



      }







      if (btnApprove) {



        btnApprove.onclick = async () => {



          const scopeRadio = document.querySelector('input[name="auth-scope-radio"]:checked');



          const isEcosystem = scopeRadio ? scopeRadio.value === "ecosystem" : true;







          const curConnected = Array.isArray(data.connected_sites) ? data.connected_sites : [];



          const curApproved = Array.isArray(data.approved_origins) ? data.approved_origins : [];



          let updatedConnected = [...curConnected];



          let updatedApproved = [...curApproved];







          if (isEcosystem) {



            const ecoDefaults = ["*.luxaecosystem.xyz", "https://luxaecosystem.xyz", "https://ldex.luxaecosystem.xyz", "https://studio.luxaecosystem.xyz", "https://explorer.luxaecosystem.xyz", "https://faucet.luxaecosystem.xyz"];



            ecoDefaults.forEach(e => {



              if (!updatedConnected.includes(e)) updatedConnected.push(e);



              if (!updatedApproved.includes(e)) updatedApproved.push(e);



            });



            if (req.origin) {



              if (!updatedConnected.includes(req.origin)) updatedConnected.push(req.origin);



              if (!updatedApproved.includes(req.origin)) updatedApproved.push(req.origin);



            }



            chrome.storage.local.set({



              connected_sites: updatedConnected,



              approved_origins: updatedApproved,



              white_card_authorized: true



            });



          } else {



            if (req.origin) {



              if (!updatedConnected.includes(req.origin)) updatedConnected.push(req.origin);



              if (!updatedApproved.includes(req.origin)) updatedApproved.push(req.origin);



            }



            chrome.storage.local.set({



              connected_sites: updatedConnected,



              approved_origins: updatedApproved



            });



          }







          hideAllViews();



          showDashboard();



          if (typeof LuxaUI !== "undefined" && LuxaUI.toast) {



            LuxaUI.toast(isEcosystem ? "Connected to LUXA Ecosystem (White Card)" : ("Connected to " + (req.origin || "DApp")), "✓");



          }







          if (req.reqId && !window.Capacitor?.isNativePlatform?.()) {



            chrome.runtime.sendMessage({ action: "RESOLVE_CONNECT_REQUEST", reqId: req.reqId, approved: true, scope: isEcosystem ? "wildcard" : "single" }, () => {



              if (typeof window.close === "function") window.close();



            });



          }







          if (req.callback) {



            try {



              const u = new URL(req.callback);



              u.searchParams.set("luxa_address", activeVault.address);



              u.searchParams.set("address", activeVault.address);



              u.searchParams.set("wallet", activeVault.address);



              u.searchParams.set("luxa_name", activeVault.name || "Main Vault");



              u.searchParams.set("luxa_status", "connected");



              u.searchParams.set("auth_scope", isEcosystem ? "wildcard" : "single");







              // 1. Close internal in-app browser view if any



              if (window.CapacitorBrowser) {



                try { await window.CapacitorBrowser.close(); } catch (_) {}



              }







              // 2. Open directly in external system browser (Chrome)



              let openedExternal = false;



              if (window.LuxaNativeNav && typeof window.LuxaNativeNav.openExternalUrl === "function") {



                openedExternal = await window.LuxaNativeNav.openExternalUrl(u.toString());



              }







              if (!openedExternal) {



                try {



                  window.open(u.toString(), "_system");



                } catch (_) {



                  if (chrome.tabs && chrome.tabs.create) {



                    chrome.tabs.create({ url: u.toString() });



                  }



                }



              }







              // 3. Minimize the Android app so Chrome comes directly to foreground



              if (window.CapacitorApp && typeof window.CapacitorApp.minimizeApp === "function") {



                setTimeout(() => {



                  try { window.CapacitorApp.minimizeApp(); } catch (_) {}



                }, 350);



              }



            } catch (e) {



              console.warn("[LUXA Vault] Failed to redirect to callback:", e);



            }



          }



        };



      }



    });



  };







  // --- INITIAL STATE LOADING ---



  if (isApproveMode && approveReqId) {



    window.handleLuxaConnectRequest({ origin: approveOrigin, reqId: approveReqId });







  } else if (isSignMode && signReqId) {



    chrome.runtime.sendMessage({ action: "GET_PENDING_SIGN_REQUEST", reqId: signReqId }, (res) => {



      const txData = res?.txData;



      if (!txData) {



        window.close();



        return;



      }



      showSignRequestScreen(txData);



    });







  } else {



    chrome.storage.local.get(["luxa_vault", "luxa_vaults", "active_wallet_idx", "luxa_currency"], (data) => {



      vaults = data.luxa_vaults || [];



      activeIndex = Number.isInteger(data.active_wallet_idx) ? data.active_wallet_idx : 0;



      activeCurrency = data.luxa_currency || "USD";







      // AUTOMATIC DEDUPLICATION CLEANUP:



      // If storage currently contains duplicate vaults with the exact same address, sanitize them immediately!



      if (vaults.length > 1) {



        const seenAddresses = new Set();



        const uniqueVaults = [];



        let hasDuplicates = false;







        for (const v of vaults) {



          if (!v || !v.address) continue;



          const cleanAddr = String(v.address).trim().toLowerCase();



          if (seenAddresses.has(cleanAddr)) {



            hasDuplicates = true;



          } else {



            seenAddresses.add(cleanAddr);



            uniqueVaults.push(v);



          }



        }







        if (hasDuplicates) {



          vaults = uniqueVaults;



          if (activeIndex >= vaults.length) activeIndex = 0;



          chrome.storage.local.set({



            luxa_vaults: vaults,



            luxa_vault: vaults[activeIndex],



            active_wallet_idx: activeIndex



          });



        }



      }







      if (!vaults.length && data.luxa_vault?.address) {



        vaults = [{



          name: "Founder Vault",



          address: data.luxa_vault.address,



          encrypted: data.luxa_vault.encrypted,



          createdAt: new Date().toISOString()



        }];



        activeIndex = 0;



        chrome.storage.local.set({ luxa_vaults: vaults, active_wallet_idx: 0 });



      }







      if (vaults.length === 0) {



        showNoWalletScreen();



      } else {



        if (activeIndex >= vaults.length) activeIndex = 0;



        chrome.storage.local.get(["is_unlocked"], (session) => {



          if (session?.is_unlocked) {



            if (window._pendingConnectRequest) {



              const req = window._pendingConnectRequest;



              window._pendingConnectRequest = null;



              window.handleLuxaConnectRequest(req);



            } else {



              showDashboard();



            }



          } else {



            showUnlockScreen();



          }



        });



      }



    });



  }



});