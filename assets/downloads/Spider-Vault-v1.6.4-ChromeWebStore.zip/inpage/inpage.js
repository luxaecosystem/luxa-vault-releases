// inpage/inpage.js — LUXA Autonomous Web3 Spider Engine
(function () {
  if (window.luxa && window.luxa.__SPIDER_ACTIVE__) return;

  const callbacks = new Map();
  const eventListeners = new Map();

  function emit(eventName, data) {
    const handlers = eventListeners.get(eventName);
    if (handlers) {
      handlers.forEach((fn) => {
        try { fn(data); } catch (err) {
          console.error(`[Spider-Provider] Error in listener '${eventName}':`, err);
        }
      });
    }
  }

  // Bidirectional listening from content script (RPC bridge)
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.data?.target !== "luxa-inpage") return;

    const { id, result, error, action, address } = event.data;

    // 1. RPC promise resolution
    if (id && callbacks.has(id)) {
      const { resolve, reject } = callbacks.get(id);
      callbacks.delete(id);
      if (error) reject(new Error(error));
      else resolve(result);
      return;
    }

    // 2. Async reactive ledger notifications
    if (action === "LUXA_ACCOUNT_READY" || action === "ACCOUNTS_CHANGED") {
      emit("accountsChanged", [address]);
      window.dispatchEvent(new CustomEvent("luxa#accountsChanged", { detail: { address } }));
      window.dispatchEvent(new CustomEvent("keplr_keystorechange"));
    }

    if (action === "VAULT_LOCKED" || action === "VAULT_DISCONNECTED") {
      emit("disconnect", { reason: action });
      window.dispatchEvent(new CustomEvent("luxa#disconnect"));
      window.dispatchEvent(new CustomEvent("keplr_keystorechange"));
    }
  });

  function postMsg(action, payload = {}) {
    return new Promise((resolve, reject) => {
      const id = "sp_" + Math.random().toString(36).slice(2) + Date.now().toString(36);
      const isSigningOp = [
        "SIGN_AND_BROADCAST",
        "EXECUTE_WASM_CONTRACT",
        "INSTANTIATE_WASM_CONTRACT",
        "UPLOAD_WASM_CONTRACT",
        "SEND_TRANSACTION",
        "CONNECT_SITE"
      ].includes(action);
      const timeoutMs = isSigningOp ? 180000 : 60000;

      const timer = setTimeout(() => {
        if (callbacks.has(id)) {
          callbacks.delete(id);
          reject(new Error("LUXA Spider request timed out."));
        }
      }, timeoutMs);

      callbacks.set(id, {
        resolve: (val) => { clearTimeout(timer); resolve(val); },
        reject: (err) => { clearTimeout(timer); reject(err); }
      });

      window.postMessage({ target: "luxa-contentscript", action, payload, id }, "*");
    });
  }

  const spiderProvider = {
    __SPIDER_ACTIVE__: true,
    isLuxa: true,
    name: "LUXA Vault — Spider's Nest",
    version: "2.2.0",
    chainId: "luxa-1",

    connect: async function () {
      return postMsg("CONNECT_SITE", { origin: window.location.origin });
    },

    enable: async function () {
      return this.connect();
    },

    getKey: async function (chainId = this.chainId) {
      return postMsg("GET_KEY", { chainId });
    },

    getAccounts: async function (chainId = this.chainId) {
      const key = await this.getKey(chainId);
      return key ? [key] : [];
    },

    getOfflineSigner: function (chainId = this.chainId) {
      const self = this;
      return {
        getAccounts: async () => self.getAccounts(chainId),
        signDirect: async (signerAddress, signDoc) => {
          return postMsg("SIGN_DIRECT", { signerAddress, signDoc, chainId });
        },
        signAmino: async (signerAddress, signDoc) => {
          return postMsg("SIGN_AMINO", { signerAddress, signDoc, chainId });
        }
      };
    },

    getOfflineSignerAuto: async function (chainId = this.chainId) {
      return this.getOfflineSigner(chainId);
    },

    signAndBroadcast: async function (tx) {
      return postMsg("SIGN_AND_BROADCAST", { tx, origin: window.location.origin });
    },

    executeContract: async function ({ contractAddress, msg, funds = [], fee }) {
      return postMsg("EXECUTE_WASM_CONTRACT", {
        contractAddress,
        msg,
        funds,
        fee,
        origin: window.location.origin
      });
    },

    instantiateContract: async function ({ codeId, label, msg, admin, funds = [], fee }) {
      return postMsg("INSTANTIATE_WASM_CONTRACT", {
        codeId,
        label,
        msg,
        admin,
        funds,
        fee,
        origin: window.location.origin
      });
    },

    uploadContract: async function ({ wasmByteCode, fee, memo }) {
      return postMsg("UPLOAD_WASM_CONTRACT", {
        wasmByteCode,
        fee,
        memo,
        origin: window.location.origin
      });
    },

    sendTx: async function ({ recipient, amount, denom = "uluxa", memo = "" }) {
      return postMsg("SEND_TRANSACTION", { recipient, amount, denom, memo });
    },

    getTestnetBalance: async function (targetAddress) {
      const key = await this.getKey(this.chainId);
      const addr = targetAddress || key?.address;
      if (!addr) throw new Error("Vault not connected");
      const res = await fetch(`https://luxaecosystem.alwaysdata.net/api/testnet/balances/${encodeURIComponent(addr)}`);
      return res.json();
    },

    requestTestnetFaucet: async function (targetAddress) {
      const key = await this.getKey(this.chainId);
      const addr = targetAddress || key?.address;
      if (!addr) throw new Error("Vault not connected");
      const res = await fetch(`https://luxaecosystem.alwaysdata.net/api/testnet/faucet`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ address: addr })
      });
      return res.json();
    },

    signArbitrary: async function (signer, data) {
      return postMsg("SIGN_ARBITRARY", { signer, data });
    },

    on: function (eventName, handler) {
      if (typeof handler !== "function") return;
      if (!eventListeners.has(eventName)) eventListeners.set(eventName, new Set());
      eventListeners.get(eventName).add(handler);
    },

    off: function (eventName, handler) {
      const handlers = eventListeners.get(eventName);
      if (handlers) {
        handlers.delete(handler);
        if (handlers.size === 0) eventListeners.delete(eventName);
      }
    },

    removeListener: function (eventName, handler) {
      this.off(eventName, handler);
    }
  };

  window.luxa = spiderProvider;
  window.dispatchEvent(new CustomEvent("luxa#initialized"));
})();