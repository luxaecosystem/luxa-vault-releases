# Chrome Web Store — Privacy Practices & Permission Justifications

## 1. Single Purpose Description (Descrizione del singolo scopo)
Spider Vault is a non-custodial Web3 wallet designed to manage cryptographic keys and execute transactions on the sovereign LUXA blockchain (luxa-1). Its single purpose is to enable users to securely generate and store local encrypted keystores (BIP-39 / AES-256-GCM), manage LUXA and CW20 tokens, execute decentralized AMM swaps, and sign smart contract transactions for connected decentralized applications.

---

## 2. Permission Justifications (Motivazione dell'autorizzazione)

### storage
The storage permission is required exclusively to save the user's encrypted wallet vault (ciphertext encrypted client-side using AES-256-GCM), local security preferences, network RPC endpoints, and token watchlists locally on the user's device via chrome.storage.local. No unencrypted private keys or seed phrases are ever saved.

### clipboardWrite
The clipboardWrite permission is used exclusively to allow users to copy their public wallet address (luxa1...), transaction IDs, and contract addresses to their clipboard with a single click, preventing manual copying errors during transfers.

### identity
The identity permission is used solely to authenticate with Google OAuth2 for the optional, zero-knowledge cloud backup feature. It allows users to backup and restore their client-side encrypted vault archives to their private, isolated Google Drive appDataFolder (which no external party or other application can access).

### Host Permissions (Motivazione per Autorizzazione host)
Host permissions are strictly restricted to the official infrastructure endpoints required for wallet operation:
1. https://*.luxaecosystem.xyz/* and https://luxaecosystem.xyz/*: Communicating directly with luxa-1 sovereign blockchain RPC, REST API, and CometBFT consensus nodes to broadcast transactions and query account balances.
2. https://luxaecosystem.alwaysdata.net/* and https://ailuxa.alwaysdata.net/*: High-speed relay endpoints for fee calculation and dual-asset price telemetry.
3. https://raw.githubusercontent.com/*: Fetching verified CW20 asset list and contract registry definitions.
4. https://frontend-studio-phi.vercel.app/*: Enabling Web3 DApp provider connection with the official LUXA DEX Studio.
5. https://www.googleapis.com/* and https://accounts.google.com/*: Processing the optional Google OAuth2 authentication flow for encrypted vault backups in Google Drive appDataFolder.
