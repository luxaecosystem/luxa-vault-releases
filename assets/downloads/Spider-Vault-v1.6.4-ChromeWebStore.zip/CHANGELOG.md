# LUXA Vault - Changelog

## Versione 1.5.0 - 16 ottobre 2026

### Nuove funzionalità
- Supporto completo agli smart contract CosmWasm su `luxa-1`: esecuzione (`execute`), instanziazione (`instantiate`) e caricamento codice (`upload`).
- Modulo di swap AMM decentralizzato direttamente nel popup della Vault basato su formule di prodotto costante ($x \cdot y = k$).
- Gestione token personalizzati CW20: importazione rapida, interrogazione saldo on-chain e visualizzazione dettagliata dello stato del pool di liquidità.
- Scanner QR integrato con mirino fotocamera per la lettura rapida degli indirizzi di destinazione.
- Localizzazione globale in lingua inglese standardizzata per tutti i testi dell'interfaccia, notifiche, modali di sicurezza e log.
- Provider Web3 esteso (`window.luxa`) con supporto a Keplr e standard Cosmos SDK per DApp e browser Web3.

## Versione 1.4.0 - 15 settembre 2026

### Nuove funzionalita

- Aggiunto il flusso di approvazione per le connessioni Web3.
- Le DApp non ancora autorizzate richiedono l'approvazione esplicita dell'utente in una finestra dedicata.
- Aggiunta la gestione delle origini autorizzate in `approved_origins`.
- Aggiunta la sezione **Connected DApps & Sites** nelle impostazioni.
- Aggiunta la barra di stato per mostrare il sito connesso nella dashboard.
- Possibilita di revocare rapidamente l'accesso del sito corrente.
- Possibilita di disconnettere singolarmente ogni sito autorizzato dalle impostazioni.

### Miglioramenti di sicurezza

- Una nuova origine non viene piu autorizzata automaticamente.
- Le richieste di connessione mostrano chiaramente l'account coinvolto e i permessi richiesti.
- PIN e Secret Recovery Phrase non vengono mai esposti al sito connesso.
- La revoca aggiorna immediatamente lo stato locale della connessione.

### Miglioramenti dell'interfaccia

- Nuova schermata di approvazione con stato dell'origine e indirizzo pubblico.
- Indicatore verde per il sito attualmente autorizzato.
- Lista dinamica dei siti connessi con hostname leggibile e azione di revoca.
- Messaggio dedicato quando non ci sono connessioni attive.

### Compatibilita

- Manifest V3.
- Compatibile con il flusso di connessione esistente tramite `window.luxa`.
- Le origini gia autorizzate continuano a connettersi senza interrompere l'esperienza dell'utente.

### Vantaggi della versione 1.4.0

- Maggiore controllo: ogni DApp deve essere autorizzata esplicitamente prima di accedere all'account pubblico.
- Revoca immediata: un sito disconnesso non puo piu usare `GET_KEY` o `GET_ACCOUNTS` finche non viene autorizzato di nuovo.
- Migliore trasparenza: dashboard e impostazioni mostrano sempre il sito attivo e le origini autorizzate.
- Recupero piu semplice: un Vault puo essere ripristinato dal backup Google Drive senza reinserire manualmente tutti i dati.
- Privacy del backup: Google Drive riceve solo i dati dei Vault gia cifrati localmente; il PIN e la Secret Recovery Phrase restano sul dispositivo dell'utente.
- Continuita operativa: il backup usa la cartella privata `appDataFolder`, non appare nella normale lista dei file di Google Drive e non viene condiviso con altri utenti.
- Compatibilita con la Mini App: importazione e creazione dei wallet usano lo stesso HD path `m/44'/118'/0'/0/0`.
- Sincronizzazione piu rapida: creazione, importazione e sblocco del Vault notificano subito le schede Web3 aperte.

### Nota importante sulle email e sui backup

- **Email di notifica del trasferimento:** viene usata l'email registrata dall'utente nella LUXA Telegram Mini App. Questa email serve esclusivamente per ricevere le notifiche delle transazioni.
- **Account Google nell'estensione Chrome:** viene usato per il profilo Google e per l'autenticazione ai servizi Google dell'estensione. Non sostituisce l'email registrata nella Telegram Mini App per le notifiche dei trasferimenti.
- **Google Drive:** viene usato per il backup e il ripristino dei Vault dell'estensione. Il backup contiene solo i dati gia cifrati localmente; PIN e Secret Recovery Phrase non vengono inviati in chiaro.

Questi sono tre servizi distinti: l'email Telegram gestisce le notifiche dei trasferimenti, l'account Google gestisce l'accesso ai servizi dell'estensione e Google Drive conserva il backup cifrato del wallet.

### Miglioramenti al trasferimento degli asset

- Nuovo form di invio ottimizzato per il popup dell'estensione.
- Aggiunto il selettore interattivo tra LUXA e SHARD.
- Aggiunte le icone degli asset e la visualizzazione del saldo disponibile per il token selezionato.
- Aggiunto il pulsante `MAX`, con riserva automatica di `0.005 LUXA` per la fee di rete.
- Aggiunto l'indicatore della fee di rete stimata.
- LUXA viene inviato con denom `uluxa`, mentre SHARD usa denom `ushard`.
- La notifica email del trasferimento usa la valuta realmente inviata, LUXA o SHARD.
- La cronologia raggruppa i record con lo stesso hash e mantiene la voce con l'altezza del blocco, evitando duplicati visivi.
- Il PIN viene richiesto tramite la schermata di sicurezza del Vault prima della firma.
