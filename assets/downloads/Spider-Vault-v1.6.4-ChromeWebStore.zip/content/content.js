// content/content.js
(function () {
  // 1. Prevent multiple or duplicate execution in the DOM
  if (window.__LUXA_CONTENT_SCRIPT_MOUNTED__) return;
  window.__LUXA_CONTENT_SCRIPT_MOUNTED__ = true;

  function isRuntimeAlive() {
    try {
      return Boolean(typeof chrome !== "undefined" && chrome?.runtime?.id);
    } catch (_) {
      return false;
    }
  }

  // 2. Controlled injection of inpage.js into page context
  if (isRuntimeAlive()) {
    try {
      const script = document.createElement("script");
      script.src = chrome.runtime.getURL("inpage/inpage.js");
      script.onload = function () {
        this.remove();
      };
      (document.head || document.documentElement).appendChild(script);
    } catch (_) {}
  }

  // 3. Page -> Background Bridge (Forward Web3 RPC calls)
  const messageHandler = (event) => {
    if (event.source !== window || event.data?.target !== "luxa-contentscript") return;

    const { action, payload, id } = event.data;

    // If extension reloaded or disabled, unhook listener and avoid crash
    if (!isRuntimeAlive()) {
      window.removeEventListener("message", messageHandler);
      window.postMessage(
        {
          target: "luxa-inpage",
          id,
          error: "Extension updated or reloaded. Please refresh the page."
        },
        "*"
      );
      return;
    }

    try {
      chrome.runtime.sendMessage({ action, ...payload }, (response) => {
        let errorMsg = null;
        try {
          if (chrome.runtime?.lastError) {
            errorMsg = chrome.runtime.lastError.message;
          }
        } catch (_) {
          errorMsg = "Extension context invalidated. Please refresh the page.";
        }

        let safeResult = null;
        if (response?.result != null) {
          try {
            safeResult = JSON.parse(
              JSON.stringify(response.result, (_, value) =>
                typeof value === "bigint" ? value.toString() : value
              )
            );
          } catch (_) {
            errorMsg = errorMsg || "The extension returned a result that could not be serialized.";
          }
        }

        window.postMessage(
          {
            target: "luxa-inpage",
            id,
            result: safeResult,
            error: errorMsg || response?.error
          },
          "*"
        );
      });
    } catch (err) {
      window.postMessage(
        {
          target: "luxa-inpage",
          id,
          error: "Extension context disconnected. Please refresh the page."
        },
        "*"
      );
    }
  };

  window.addEventListener("message", messageHandler);

  // 4. Background -> Page Bridge (Real-time Vault event synchronization)
  if (isRuntimeAlive()) {
    try {
      chrome.runtime.onMessage.addListener((msg) => {
        if (!msg || !msg.action) return;

        // Vault unlocked, created, or account changed
        if (msg.action === "ON_VAULT_UNLOCKED" || msg.action === "ON_VAULT_CHANGED") {
          window.postMessage(
            {
              target: "luxa-inpage",
              action: "LUXA_ACCOUNT_READY",
              address: msg.address
            },
            "*"
          );
        }

        // Vault locked manually or due to inactivity
        if (msg.action === "ON_VAULT_LOCKED") {
          window.postMessage(
            {
              target: "luxa-inpage",
              action: "VAULT_LOCKED"
            },
            "*"
          );
        }

        // DApp permissions revoked by user in HUD
        if (msg.action === "ON_VAULT_DISCONNECTED") {
          window.postMessage(
            {
              target: "luxa-inpage",
              action: "VAULT_DISCONNECTED"
            },
            "*"
          );
        }
      });
    } catch (_) {}
  }
})();